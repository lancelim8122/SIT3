﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace RIMS.Common.MQ.Models.CompositeEnquiry
{
    [XmlRoot(ElementName = "EAI")]
    public class RetriveLstOfAccInfoDetailReq:BaseEAIRequest
    {
        public RetriveLstOfAccInfoDetailReq_SubSvcRq SubSvcRq { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRq")]
    public class RetriveLstOfAccInfoDetailReq_SubSvcRq
    {
        public RetriveLstOfAccInfoDetailReq_SubSvc SubSvc { get; set; }
    }

    [XmlRoot(ElementName = "SubSvc")]
    public class RetriveLstOfAccInfoDetailReq_SubSvc
    {
        public RetriveLstOfAccInfoDetailReq_SubSvcRqHeader SubSvcRqHeader { get; set; }
        public RetriveLstOfAccInfoDetailReq_SubSvcRqDetail SubSvcRqDetail { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRqHeader")]
    public class RetriveLstOfAccInfoDetailReq_SubSvcRqHeader
    {
        public string SvcCode { get; set; }
        public string SubSvcSeq { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRqDetail")]
    public class RetriveLstOfAccInfoDetailReq_SubSvcRqDetail
    {
        public string AcctNo { get; set; }
        public string AcctCur { get; set; }
        public string AcctType { get; set; }
        public string TransactionDt { get; set; }
    }
}
