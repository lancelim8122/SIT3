﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace RIMS.Common.MQ.Models.CompositeEnquiry
{
    [XmlRoot(ElementName = "EAI")]
    public class RetriveLstOfAccInfoDetailRes: BaseEAIResponse
    {
        public RetriveLstOfAccInfoRes_SubSvcRs SubSvcRs { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRs")]
    public class RetriveLstOfAccInfoRes_SubSvcRs
    {
        public RetriveLstOfAccInfoDetailRes_SubSvcRsSub SubSvc { get; set; }
    }
    [XmlRoot(ElementName = "SubSvc")]
    public class RetriveLstOfAccInfoDetailRes_SubSvcRsSub
    {
        public RetriveLstOfAccInfoDetailRes_SubSvcRsHeader SubSvcRsHeader { get; set; }
        public RetriveLstOfAccInfoDetailRes_SubSvcRsDetail SubSvcRsDetail { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRsHeader")]
    public class RetriveLstOfAccInfoDetailRes_SubSvcRsHeader
    {
        public string SvcCode { get; set; }
        public string SubSvcSeq { get; set; }
        public string StatusCode { get; set; }
        public string ErrorHost { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorDesc { get; set; }
        public string EAIErrCode { get; set; }
        public string EAIErrDesc { get; set; }
        public string EAIErrInfo { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRsDetail")]
    public class RetriveLstOfAccInfoDetailRes_SubSvcRsDetail
    {
        public string AcctNo { get; set; }
        public string AcctType { get; set; }
        public string AcctCur { get; set; }
        public string CurDec { get; set; }
        public string IDType { get; set; }
        public string IDNo { get; set; }
        public string IDCountry { get; set; }
        public string ProdType { get; set; }
        public string Status { get; set; }
        public string Holds { get; set; }
        public string AcctBal { get; set; }
        public string SignCondition { get; set; }
    }
}
