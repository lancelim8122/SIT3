﻿using System.Xml.Serialization;

namespace RIMS.Common.MQ.Models.CompositeEnquiry
{
    [XmlRoot(ElementName = "EAI")]
    public class CreditCardInfoInqReq : BaseEAIRequest
    {
        public CreditCardInfoInqReqSubSvcRq SubSvcRq { get; set; }

    }
    [XmlRoot(ElementName = "SubSvcRq")]
    public class CreditCardInfoInqReqSubSvcRq
    {
        public CreditCardInfoInqReqSubSvc SubSvc { get; set; }
    }

    [XmlRoot(ElementName = "SubSvc")]
    public class CreditCardInfoInqReqSubSvc
    {
        public CreditCardInfoInqReq_SubSvcRqHeader SubSvcRqHeader { get; set; }
        public CreditCardInfoInqReq_SubSvcRqDetail SubSvcRqDetail { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRqHeader")]
    public class CreditCardInfoInqReq_SubSvcRqHeader
    {
        public string SvcCode { get; set; }
        public string SubSvcSeq { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRqDetail")]
    public class CreditCardInfoInqReq_SubSvcRqDetail
    {
        public string CardNum { get; set; }
        public string RegionalInd { get; set; }
    }
}
