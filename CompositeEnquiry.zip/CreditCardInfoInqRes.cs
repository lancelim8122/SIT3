﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace RIMS.Common.MQ.Models.CompositeEnquiry
{
    [XmlRoot(ElementName = "EAI")]
    public class CreditCardInfoInqRes : BaseEAIResponse
    {
        public CreditCardInfoInqResSubSvcRs SubSvcRs { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRs")]
    public class CreditCardInfoInqResSubSvcRs
    {
        public CreditCardInfoInqRes_SubSvcRsSub SubSvc { get; set; }
    }
    [XmlRoot(ElementName = "SubSvc")]
    public class CreditCardInfoInqRes_SubSvcRsSub
    {
        public CreditCardInfoInqRes_SubSvcRsHeader SubSvcRsHeader { get; set; }
        public CreditCardInfoInqRes_SubSvcRsDetail SubSvcRsDetail { get; set; }

    }
    [XmlRoot(ElementName = "SubSvcRsHeader")]
    public class CreditCardInfoInqRes_SubSvcRsHeader
    {
        public string SvcCode { get; set; }
        public string SubSvcSeq { get; set; }
        public string StatusCode { get; set; }
        public string ErrorHost { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorDesc { get; set; }
        public string EAIErrCode { get; set; }
        public string EAIErrDesc { get; set; }
        public string EAIErrInfo { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRsDetail")]
    public class CreditCardInfoInqRes_SubSvcRsDetail
    {

        public double StatementedBalance { get; set; }

        public double AmountDue { get; set; }

        public int DueDate { get; set; }

        public double ToDateBalance { get; set; }

        public int AvailableCredit { get; set; }

        public double LastPaymentAmount { get; set; }

        public int LastPaymentDate { get; set; }

        public int UNIAmt { get; set; }

        public int UNIExpireDate { get; set; }

        public string OverdueFlag { get; set; }

        public int KrisFlyerFlag { get; set; }

        public string EmbossedName { get; set; }

        public int CreditLimit { get; set; }

        public object BlockCode { get; set; }

        public object ShortName { get; set; }

        public object CIFNo { get; set; }

        public object CardExpiryDate { get; set; }

        public List<CreditCardInfoInqRes_CcBalInfo> CcBalInfo { get; set; }
    }


    public class CreditCardInfoInqRes_CcBalInfo
    {

        public int AcctNum { get; set; }

        public double CrBalance { get; set; }

        public object CrBalanceLStmt { get; set; }

        public object CrEarned { get; set; }

        public object CrRedLStmt { get; set; }

        public object CrAdjLStmt { get; set; }
    }


}
