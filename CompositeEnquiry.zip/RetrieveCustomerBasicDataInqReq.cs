﻿using System.Xml.Serialization;

namespace RIMS.Common.MQ.Models.CompositeEnquiry
{
    [XmlRoot(ElementName = "EAI")]
    public class RetrieveCustomerBasicDataInqReq : BaseEAIRequest
    {
        public RetrieveCustomerBasicDataInqReqSubSvcRq SubSvcRq { get; set; }

    }
    [XmlRoot(ElementName = "SubSvcRq")]
    public class RetrieveCustomerBasicDataInqReqSubSvcRq
    {
        public RetrieveCustomerBasicDataInqReqSubSvc SubSvc { get; set; }
    }

    [XmlRoot(ElementName = "SubSvc")]
    public class RetrieveCustomerBasicDataInqReqSubSvc
    {
        public RetrieveCustomerBasicDataInqReq_SubSvcRqHeader SubSvcRqHeader { get; set; }
        public RetrieveCustomerBasicDataInqReq_SubSvcRqDetail SubSvcRqDetail { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRqHeader")]
    public class RetrieveCustomerBasicDataInqReq_SubSvcRqHeader
    {
        public string SvcCode { get; set; }
        public string SubSvcSeq { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRqDetail")]
    public class RetrieveCustomerBasicDataInqReq_SubSvcRqDetail
    {
        [XmlElement(ElementName = "CIFNo")]
        public string CIFNo { get; set; }

        [XmlElement(ElementName = "IDNo")]
        public string IDNo { get; set; }

        [XmlElement(ElementName = "IDType")]
        public string IDType { get; set; }

        [XmlElement(ElementName = "IDCountry")]
        public string IDCountry { get; set; }

        [XmlElement(ElementName = "ViewType")]
        public string ViewType { get; set; }

        [XmlElement(ElementName = "AddressSeqNo")]
        public string AddressSeqNo { get; set; }
    }
}
