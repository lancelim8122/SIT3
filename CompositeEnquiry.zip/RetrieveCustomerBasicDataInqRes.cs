﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace RIMS.Common.MQ.Models.CompositeEnquiry
{
    [XmlRoot(ElementName = "EAI")]
    public class RetrieveCustomerBasicDataInqRes : BaseEAIResponse
    {
        public RetrieveCustomerBasicDataInqResSubSvcRs SubSvcRs { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRs")]
    public class RetrieveCustomerBasicDataInqResSubSvcRs
    {
        public RetrieveCustomerBasicDataInqRes_SubSvcRsSub SubSvc { get; set; }
    }
    [XmlRoot(ElementName = "SubSvc")]
    public class RetrieveCustomerBasicDataInqRes_SubSvcRsSub
    {
        public RetrieveCustomerBasicDataInqRes_SubSvcRsHeader SubSvcRsHeader { get; set; }
        public RetrieveCustomerBasicDataInqRes_SubSvcRsDetail SubSvcRsDetail { get; set; }

    }
    [XmlRoot(ElementName = "SubSvcRsHeader")]
    public class RetrieveCustomerBasicDataInqRes_SubSvcRsHeader
    {
        public string SvcCode { get; set; }
        public string SubSvcSeq { get; set; }
        public string StatusCode { get; set; }
        public string ErrorHost { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorDesc { get; set; }
        public string EAIErrCode { get; set; }
        public string EAIErrDesc { get; set; }
        public string EAIErrInfo { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRsDetail")]
    public class RetrieveCustomerBasicDataInqRes_SubSvcRsDetail
    {
        [XmlElement(ElementName = "CustBasicInfoRs")]
        public CustBasicInfoRs CustBasicInfoRs { get; set; }
    }


    [XmlRoot(ElementName = "CustBasicInfoRs")]
    public class CustBasicInfoRs
    {

        [XmlElement(ElementName = "CustBasicInfo")]
        public CustBasicInfo CustBasicInfo { get; set; }
    }


    [XmlRoot(ElementName = "CustBasicInfo")]
    public class CustBasicInfo
    {

        [XmlElement(ElementName = "CIFNo")]
        public object CIFNo { get; set; }

        [XmlElement(ElementName = "IDNo")]
        public object IDNo { get; set; }

        [XmlElement(ElementName = "IDType")]
        public object IDType { get; set; }

        [XmlElement(ElementName = "IDCountry")]
        public object IDCountry { get; set; }

        [XmlElement(ElementName = "Salutation")]
        public object Salutation { get; set; }

        [XmlElement(ElementName = "CustomerName1")]
        public object CustomerName1 { get; set; }

        [XmlElement(ElementName = "CustomerName2")]
        public object CustomerName2 { get; set; }

        [XmlElement(ElementName = "CustomerType")]
        public object CustomerType { get; set; }

        [XmlElement(ElementName = "BlackListInd")]
        public object BlackListInd { get; set; }

        [XmlElement(ElementName = "BlackListReasonCode")]
        public object BlackListReasonCode { get; set; }

        [XmlElement(ElementName = "BlackListReasonDesc")]
        public object BlackListReasonDesc { get; set; }

        [XmlElement(ElementName = "AddressSeqNo")]
        public object AddressSeqNo { get; set; }

        [XmlElement(ElementName = "AddressType")]
        public object AddressType { get; set; }

        [XmlElement(ElementName = "AddressFormat")]
        public object AddressFormat { get; set; }

        [XmlElement(ElementName = "AddressLine1")]
        public object AddressLine1 { get; set; }

        [XmlElement(ElementName = "AddressLine2")]
        public object AddressLine2 { get; set; }

        [XmlElement(ElementName = "AddressLine3")]
        public object AddressLine3 { get; set; }

        [XmlElement(ElementName = "AddressLine4")]
        public object AddressLine4 { get; set; }

        [XmlElement(ElementName = "BlockNo")]
        public object BlockNo { get; set; }

        [XmlElement(ElementName = "Storey")]
        public object Storey { get; set; }

        [XmlElement(ElementName = "UnitNo")]
        public object UnitNo { get; set; }

        [XmlElement(ElementName = "StreetName")]
        public object StreetName { get; set; }

        [XmlElement(ElementName = "BuildingName")]
        public object BuildingName { get; set; }

        [XmlElement(ElementName = "POBox")]
        public object POBox { get; set; }

        [XmlElement(ElementName = "PostalCode")]
        public object PostalCode { get; set; }

        [XmlElement(ElementName = "City")]
        public object City { get; set; }

        [XmlElement(ElementName = "CountryCode")]
        public object CountryCode { get; set; }

        [XmlElement(ElementName = "VerifyAddrInd")]
        public object VerifyAddrInd { get; set; }

        [XmlElement(ElementName = "ListOfElectronicAddress")]
        public ListOfElectronicAddress ListOfElectronicAddress { get; set; }

        [XmlElement(ElementName = "BusTypeMASCode")]
        public object BusTypeMASCode { get; set; }

        [XmlElement(ElementName = "MASIndustrialCode")]
        public object MASIndustrialCode { get; set; }

        [XmlElement(ElementName = "CDPNo")]
        public object CDPNo { get; set; }

        [XmlElement(ElementName = "VIPCustomerCode")]
        public object VIPCustomerCode { get; set; }

        [XmlElement(ElementName = "HoldMailCode")]
        public object HoldMailCode { get; set; }

        [XmlElement(ElementName = "HoldPromoMailInd")]
        public object HoldPromoMailInd { get; set; }

        [XmlElement(ElementName = "ServiceRecoveryInd")]
        public object ServiceRecoveryInd { get; set; }

        [XmlElement(ElementName = "DeceasedDissolvedInd")]
        public object DeceasedDissolvedInd { get; set; }

        [XmlElement(ElementName = "DeceasedDissolvedDate")]
        public object DeceasedDissolvedDate { get; set; }

        [XmlElement(ElementName = "InsiderCode")]
        public object InsiderCode { get; set; }

        [XmlElement(ElementName = "CombinedCycle")]
        public object CombinedCycle { get; set; }

        [XmlElement(ElementName = "Birth-IncorporationDate")]
        public object BirthIncorporationDate { get; set; }

        [XmlElement(ElementName = "Citizen-IncorporationCountry")]
        public object CitizenIncorporationCountry { get; set; }

        [XmlElement(ElementName = "Residence-BizOpsCountry")]
        public object ResidenceBizOpsCountry { get; set; }

        [XmlElement(ElementName = "PR-OwnershipStatus")]
        public object PROwnershipStatus { get; set; }

        [XmlElement(ElementName = "LastMaintenanceDate")]
        public object LastMaintenanceDate { get; set; }

        [XmlElement(ElementName = "LastMaintenanceTime")]
        public object LastMaintenanceTime { get; set; }

        [XmlElement(ElementName = "SexCode")]
        public object SexCode { get; set; }

        [XmlElement(ElementName = "MaritalStatus")]
        public object MaritalStatus { get; set; }

        [XmlElement(ElementName = "RaceCode")]
        public object RaceCode { get; set; }

        [XmlElement(ElementName = "CompanyID")]
        public object CompanyID { get; set; }

        [XmlElement(ElementName = "StaffDept")]
        public object StaffDept { get; set; }

        [XmlElement(ElementName = "EmployeeID")]
        public object EmployeeID { get; set; }

        [XmlElement(ElementName = "CPFNo")]
        public object CPFNo { get; set; }

        [XmlElement(ElementName = "BankerID")]
        public object BankerID { get; set; }

        [XmlElement(ElementName = "IndustrialRiskCode")]
        public object IndustrialRiskCode { get; set; }

        [XmlElement(ElementName = "DecodedCustName1")]
        public object DecodedCustName1 { get; set; }

        [XmlElement(ElementName = "DecodedCustName2")]
        public object DecodedCustName2 { get; set; }

        [XmlElement(ElementName = "DecodedAddressLine1")]
        public object DecodedAddressLine1 { get; set; }

        [XmlElement(ElementName = "DecodedAddressLine2")]
        public object DecodedAddressLine2 { get; set; }

        [XmlElement(ElementName = "DecodedAddressLine3")]
        public object DecodedAddressLine3 { get; set; }

        [XmlElement(ElementName = "DecodedAddressLine4")]
        public object DecodedAddressLine4 { get; set; }

        [XmlElement(ElementName = "UICCode1")]
        public object UICCode1 { get; set; }

        [XmlElement(ElementName = "UICCode2")]
        public object UICCode2 { get; set; }

        [XmlElement(ElementName = "UICCode3")]
        public object UICCode3 { get; set; }

        [XmlElement(ElementName = "UICCode4")]
        public object UICCode4 { get; set; }

        [XmlElement(ElementName = "UICCode5")]
        public object UICCode5 { get; set; }

        [XmlElement(ElementName = "UICCode6")]
        public object UICCode6 { get; set; }

        [XmlElement(ElementName = "UICCode7")]
        public object UICCode7 { get; set; }

        [XmlElement(ElementName = "UICCode8")]
        public object UICCode8 { get; set; }

        [XmlElement(ElementName = "PlaceOfBirth")]
        public object PlaceOfBirth { get; set; }
    }


    [XmlRoot(ElementName = "ListOfElectronicAddress")]
    public class ListOfElectronicAddress
    {

        [XmlElement(ElementName = "ElectronicAddress")]
        public List<ElectronicAddress> ElectronicAddress { get; set; }
    }


    [XmlRoot(ElementName = "ElectronicAddress")]
    public class ElectronicAddress
    {

        [XmlElement(ElementName = "ElectronicAddressSeqNo")]
        public int ElectronicAddressSeqNo { get; set; }

        [XmlElement(ElementName = "ElectronicAddressType")]
        public string ElectronicAddressType { get; set; }

        [XmlElement(ElementName = "ElectronicAddressDesc")]
        public int ElectronicAddressDesc { get; set; }
    }

}
