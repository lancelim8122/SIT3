﻿using System;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using Elsa;
using Elsa.Activities.Http.Models;
using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using RIMS.SPVWorkflow.SPVWorkflow.Models.Product;
using RIMS.SPVWorkflow.SPVWorkflow.Utilities;

//using NLog.Web;

namespace RIMS.SPVWorkflow.Activities
{
    [Action(
Category = "MWPCreation",
DisplayName = "Create_Mwp",
Description = "Create_Mwp",
Outcomes = new[] { OutcomeNames.Done, "Faulted" }
)]
    public class Create_Mwp : Activity
    {
        public Create_Mwp()
        { }
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {
            IFormatProvider culture = new CultureInfo("en-GB", true);
            try
            {
                HttpRequestModel ReqModel = JsonSerializer.Deserialize<HttpRequestModel>(JsonSerializer.Serialize(context.Input));
                SPVWorkflow.Models.Product.SPVRequest.SPVCreationBasicDetailRequest Request = System.Text.Json.JsonSerializer.Deserialize<SPVWorkflow.Models.Product.SPVRequest.SPVCreationBasicDetailRequest>(ReqModel.Body.ToString());

                SPVWorkflow.Entities.SPVRequest spvRequestData = new SPVWorkflow.Entities.SPVRequest();
                using (var dbContext = new SPVContext())
                {

                    var mwpRequest = dbContext.MWPRequest
                        .AsQueryable().FirstOrDefault(x =>
                            x.MWPId == Request.RequestDetails.MWPSessionId);

                    var mwpCustomer = dbContext.MWPCustomer
                        .AsQueryable().Where(x =>
                            x.MWPId == Request.RequestDetails.MWPSessionId).ToList();


                    var api2ComeFirst = (mwpCustomer.ToList().Count > 0 && mwpRequest != null);
                    context.SetVariable("API2ComeFirst", api2ComeFirst);
                    context.SetVariable("TotalSPVRequestOrder", Request.RequestDetails.Order.Count);
                    if (api2ComeFirst)
                    {

                        string userId = GetUserId(Request.RequestDetails.SSOReferenceNumber);
                        Request.RequestHeader.RequesterContext.RequestID = GenMWPRefNo(userId);


                        var existingMwpRequest = mwpRequest;

                        var sameSessionSPVRequest = dbContext.SPVRequest
                            .AsQueryable().FirstOrDefault(x => x.MWPSessionId == Request.RequestDetails.MWPSessionId);

                        if (sameSessionSPVRequest == null)
                        {
                            var newOrder = new SPVWorkflow.Entities.SPVRequest
                            {
                                RequestID = Request.RequestHeader.RequesterContext.RequestID,
                                MWPSessionId = existingMwpRequest.MWPId,
                                MWPMinor = existingMwpRequest.MWPMinor,
                                MWPGen = existingMwpRequest.MWPGen,
                                EntityNo = existingMwpRequest.EntityNo,
                                ValidityEndDate = existingMwpRequest.ValidityEndDate,
                                Status = existingMwpRequest.Status,
                                StatusDesc = existingMwpRequest.StatusDesc,
                                StatusUpdateTime = existingMwpRequest.StatusUpdateTime
                            };
                            dbContext.SPVRequest.Add(newOrder);
                            dbContext.SaveChanges();


                            foreach (var existingCustomer in mwpCustomer)
                            {
                                var newCustomer = new SPVRequestCustomer
                                {
                                    RequestID = Request.RequestHeader.RequesterContext.RequestID,
                                    CIFNo = existingCustomer.CIFNo,
                                    CustomerName1 = existingCustomer.CustomerName1,
                                    CustomerName2 = existingCustomer.CustomerName2,
                                    NominatedParty = existingCustomer.NominatedParty,
                                    Email = existingCustomer.Email,
                                    ContactNumber = existingCustomer.ContactNumber,
                                    CreatedBy = "tmp1rd",
                                    CreatedTime = DateTime.Now,
                                };
                                dbContext.SPVRequestCustomer.Add(newCustomer);
                                dbContext.SaveChanges();
                            }


                            //= api2ComeFirst

                            HttpRequestModel OutputModel = new HttpRequestModel(ReqModel.Path, ReqModel.Method,
                                ReqModel.QueryString, ReqModel.Headers,
                                Request, JsonSerializer.Serialize(Request));
                            context.Output = OutputModel;
                            return Done();
                        }
                        else
                        {

                            throw new Exception("Clone SPV error: MWP already cloned to SPV");

                        }





                    }
                    else
                    {
                        SPVWorkflow.Entities.SPVRequest sPVRequest = dbContext.SPVRequest
                       .AsQueryable().FirstOrDefault(x => x.MWPSessionId == Request.RequestDetails.MWPSessionId);
                        if (sPVRequest == null)
                        {
                            //Get UserId from SPOSSOSession table using SSOReferenceNumber
                            //Lance comment===Begin

                            string userId = GetUserId(Request.RequestDetails.SSOReferenceNumber);
                            spvRequestData.RequestID = GenMWPRefNo(userId);
                            //Lance comment===End
                            //spvRequestData.RequestID = "REQUESTID001";
                            Request.RequestHeader.RequesterContext.RequestID = spvRequestData.RequestID;
                            spvRequestData.RequestType = Request.RequestDetails.RequestType;
                            spvRequestData.MWPSessionId = Request.RequestDetails.MWPSessionId;
                            spvRequestData.MWPMinor = Request.RequestDetails.MWPMinor;
                            spvRequestData.MWPGen = Request.RequestDetails.MWPGen;
                            spvRequestData.EntityNo = Request.RequestDetails.EntityNumber;
                            spvRequestData.SignDate = Request.RequestDetails.SignDate;
                            spvRequestData.ValidityEndDate = Request.RequestDetails.ValidityEndDate;
                            spvRequestData.Status = Request.RequestDetails.Status;
                            spvRequestData.StatusDesc = Request.RequestDetails.StatusDesc;
                            spvRequestData.StatusUpdateTime = Request.RequestDetails.StatusUpdateTime;
                            spvRequestData.OrderStatus = Request.RequestDetails.OrderStatus;
                            spvRequestData.CreatedBy = Request.RequestDetails.CreatedBy;
                            spvRequestData.CreatedTime = Request.RequestDetails.CreatedTime;
                            spvRequestData.UpdatedBy = Request.RequestDetails.UpdatedBy;
                            spvRequestData.UpdatedTime = Request.RequestDetails.UpdatedTime;
                            spvRequestData.WorkflowInd = Request.RequestDetails.WorkflowInd;
                            spvRequestData.UTAccountNo = Request.RequestDetails.UTAccountNo;
                            spvRequestData.SigningCondition = Request.RequestDetails.SigningCondition;
                            spvRequestData.FormId = Request.RequestDetails.FormId;
                            spvRequestData.OptInIndicator = Request.RequestDetails.OptInIndicator;
                            spvRequestData.USEAADeclarationDate = Request.RequestDetails.USEAADeclarationDate;
                            spvRequestData.SignFormMode = Request.RequestDetails.SignFormMode;
                            spvRequestData.DropCIFIndicator = Request.RequestDetails.DropCIFIndicator;
                            CreateCustomer(Request);
                            dbContext.SPVRequest.Add(spvRequestData);
                            dbContext.SaveChanges();
                            //SaveOrderDetails(Request, spvRequestData.RequestID);
                            HttpRequestModel OutputModel = new HttpRequestModel(ReqModel.Path, ReqModel.Method,
                                                                                    ReqModel.QueryString, ReqModel.Headers,
                                                                                    Request, JsonSerializer.Serialize(Request));
                            context.Output = OutputModel;

                            return Done();
                        }
                        else
                        {
                            AuditLogger.Info("CreateMWP : MWPID is already exist");

                            throw new Exception("CreateMWP : MWPID is already exist");

                            //context.WorkflowExecutionContext.WorkflowContext = new MWPCreationException(MWPCreationError.PS00101.GetEnumDescription());


                            //HttpRequestModel OutputModel = new HttpRequestModel(ReqModel.Path, ReqModel.Method,
                            //                                                        ReqModel.QueryString, ReqModel.Headers,
                            //                                                        Request, JsonSerializer.Serialize(Request));
                            //context.Output = OutputModel;

                            //return Outcome("Faulted", context.WorkflowExecutionContext.WorkflowContext);
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                var output = new SSOResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ErrorCode = MWPCreationError.PS00100.GetEnumDescription(),
                        ErrorDesc = ex.Message,
                        ErrorHost = "MWPWorkFlow",
                        ResponseStatus = "Faulted"
                    },

                };

                AuditLogger.Info("CreateMWP Activity: " + ex.Message);
                //var output = JsonSerializer.Serialize(
                //    new MWPCreationException(MWPCreationError.PS00100.GetEnumDescription()) + " : " + ex.Message);
                context.SetWorkflowContext(JsonSerializer.Serialize(output));
                return Outcome("Faulted", context.WorkflowExecutionContext.WorkflowContext);
            }
        }

        private void CreateCustomer(SPVWorkflow.Models.Product.SPVRequest.SPVCreationBasicDetailRequest Request)
        {
            SPVRequestCustomer mWPCustomer;
            try
            {
                if (Request.RequestDetails.Customer == null)
                {
                    mWPCustomer = null;
                }
                else
                {

                    foreach (var item in Request.RequestDetails.Customer)
                    {
                        using (var dbContext = new SPVContext())
                        {
                            mWPCustomer = new SPVRequestCustomer()
                            {
                                //MWPId = Request.RequestDetails.MWPSessionId,
                                //MWPMinor = Request.RequestDetails.MWPMinor,
                                //MWPGen = Request.RequestDetails.MWPGen,
                                //EntityNo = Request.RequestDetails.EntityNumber,
                                RequestID = Request.RequestHeader.RequesterContext.RequestID,
                                CIFNo = item.CIFNo,
                                CustomerName1 = item.CustomerName1,
                                CustomerName2 = item.CustomerName2,
                                NominatedParty = item.NominatedParty,
                                Email = item.Email,
                                RiskScore = item.RiskScore,
                                RiskReviewDate = item.RiskReviewDate,
                                RiskSource = item.RiskSource,
                                CreatedBy = "tmp6nq",
                                CreatedTime = DateTime.Now
                            };
                            dbContext.SPVRequestCustomer.Add(mWPCustomer);
                            dbContext.SaveChanges();
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                var errorMessage = "Create Customer" + ex.Message;
                AuditLogger.Info(errorMessage);
                throw new Exception(errorMessage);
            }
        }
        private static string ConvertDateTimeToJulian(DateTime? date)
        {
            string result = "";

            if (null != date)
            {
                DateTime dt = date.Value;
                TimeSpan diff = dt.Subtract(new DateTime(dt.Year - 1, 12, 31));
                Decimal jDay = Decimal.Truncate((Decimal)diff.TotalDays);
                result = dt.Year.ToString() + jDay.ToString().PadLeft(3, '0');
            }

            return result;
        }
        private string GenMWPRefNo(string userId)
        {
            using (SPVContext ctx = new SPVContext())
            {
                var p = new SqlParameter("@resultSeq", System.Data.SqlDbType.Int);
                p.Direction = System.Data.ParameterDirection.Output;
                ctx.Database.ExecuteSqlRaw("set @resultSeq = next value for MWPRefNoSeq", p);
                int nextVal = (int)p.Value;
                string seq = nextVal.ToString().PadLeft(6, '0');
                string prefix = "UT";

                return prefix + userId.Substring(0, 6).ToUpper() + ConvertDateTimeToJulian(DateTime.Now) + seq;
                //return "UTTMP6NQ2022164001743";
            }
        }
        private string GetUserId(string ssoRefNumber)
        {
            using (SPVContext ctx = new SPVContext())
            {
                // TODO Need to check which will be SSORefNumber in SPVSSOSession table
                string userId = ctx.SPVSSOSession.AsQueryable()
                            .Where(x => x.EntityNumber == ssoRefNumber).Select(y => y.UserId).FirstOrDefault();
                //return userId;
                return "tmp6nq";
            }
        }
        private void SaveOrderDetails(SPVWorkflow.Models.Product.SPVRequest.SPVCreationBasicDetailRequest Request, string requestID)
        {

            foreach (var order in Request.RequestDetails.Order)
            {
                SPVWorkflow.Entities.SPVRequestOrder spvRequestOrder = new SPVWorkflow.Entities.SPVRequestOrder();
                using (var dbContext = new SPVContext())
                {
                    SPVWorkflow.Entities.SPVRequestOrder sPVRequestOrderData = dbContext.SPVRequestOrder.AsQueryable()
                                                .Where(x => x.RequestID == order.RequestID).FirstOrDefault();
                    //if (sPVRequestOrderData == null)
                    if (true)
                    {
                        spvRequestOrder.RequestID = requestID;
                        spvRequestOrder.ChannelRefId = order.ChannelRefId;
                        spvRequestOrder.OrderTransactionRefNo = GenOrderRefNo(order.OrderType, "BBB");
                        //spvRequestOrder.OrderTransactionRefNo = "SBBBB202216401708";
                        spvRequestOrder.SPVOrderStatus = order.SPVOrderStatus;
                        spvRequestOrder.OrderType = order.OrderType;
                        spvRequestOrder.FundCode = order.FundCode;
                        spvRequestOrder.FundCcy = order.FundCcy;
                        spvRequestOrder.OrgPaymentType = order.OrgPaymentType;
                        spvRequestOrder.PaymentType = order.PaymentType;
                        spvRequestOrder.InvestmentType = order.InvestmentType;
                        spvRequestOrder.OrgInvestmentAmount = order.OrgInvestmentAmount;
                        spvRequestOrder.InvestmentAmount = Convert.ToDecimal(order.InvestmentAmount);
                        spvRequestOrder.RISFrequency = order.RISFrequency;
                        spvRequestOrder.SwitchFromUnits = order.SwitchFromUnits;
                        spvRequestOrder.SwitchFromFundCode = order.SwitchFromFundCode;
                        spvRequestOrder.CreatedBy = order.CreatedBy;
                        spvRequestOrder.CreatedTime = Convert.ToDateTime("2019-01-06T17:16:40");
                        spvRequestOrder.UpdatedBy = order.UpdatedBy;
                        spvRequestOrder.UpdatedTime = Convert.ToDateTime("2019-01-06T17:16:40");
                        spvRequestOrder.WorkflowInd = order.WorkflowInd;
                        spvRequestOrder.BinIndicator = order.BinIndicator;
                        spvRequestOrder.CashAccountNo = order.CashAccountNo;
                        spvRequestOrder.CashAccountType = order.CashAccountType;
                        spvRequestOrder.CashAccountCurrency = order.CashAccountCurrency;
                        spvRequestOrder.CashAccountSignCondition = order.CashAccountSignCondition;
                        spvRequestOrder.IndicativeNAV = order.IndicativeNAV;
                        //spvRequestOrder.IndicativeNAVDate = order.IndicativeNAVDate;
                        spvRequestOrder.CardNumber = order.CardNumber;
                        spvRequestOrder.CPFApprovedBank = order.CPFApprovedBank;
                        spvRequestOrder.CPFInvestmentAccount = order.CPFInvestmentAccount;
                        spvRequestOrder.CPFAccount = order.CPFAccount;
                        spvRequestOrder.DividendInstruction = order.DividendInstruction;
                        spvRequestOrder.DividendCreditingAcct = order.DividendCreditingAcct;
                        spvRequestOrder.SalesCharge = order.SalesCharge;
                        spvRequestOrder.Remarks = order.Remarks;
                        spvRequestOrder.SAQIndicator = order.SAQIndicator;
                        spvRequestOrder.SRSOperator = order.SRSOperator;
                        spvRequestOrder.SRSAccount = order.SRSAccount;
                        spvRequestOrder.CreditingAcct = order.CreditingAcct;
                        spvRequestOrder.RISRecurringPeriod = order.RISRecurringPeriod;
                        //spvRequestOrder.RISStartDate = order.RISStartDate;
                        //spvRequestOrder.RISEndDate = order.RISEndDate;
                        spvRequestOrder.RISDividendInstruction = order.RISDividendInstruction;
                        spvRequestOrder.SwitchIndicativeAmount = order.SwitchIndicativeAmount;
                        //spvRequestOrder.OrderStatusIndicator = "false";
                        dbContext.SPVRequestOrder.Add(spvRequestOrder);
                        dbContext.SaveChanges();
                    }
                }
            }


        }

        private string GenOrderRefNo(string orderType, String branch)
        {
            using (SPVContext ctx = new SPVContext())
            {
                var p = new SqlParameter("@result", System.Data.SqlDbType.Int);
                p.Direction = System.Data.ParameterDirection.Output;
                //ctx.Database.ExecuteSqlRaw("set @result = next value FOR OrderRefNoSeq", p);
                int nextVal = (int)p.Value;
                string seq = nextVal.ToString().PadLeft(5, '0');

                string prefix = orderType;
                if (orderType == "RS")
                {
                    prefix = "RSP";
                }

                return prefix + branch + ConvertDateTimeToJulian(DateTime.Now) + seq;
            }
        }

    }

    public class SSOResponse : Response
    {

    }
}

