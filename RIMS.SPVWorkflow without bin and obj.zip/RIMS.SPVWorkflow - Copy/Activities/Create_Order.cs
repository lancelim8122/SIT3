﻿using System;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using Elsa;
using Elsa.Activities.Http.Models;
using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using RIMS.SPVWorkflow.SPVWorkflow.Utilities;

namespace RIMS.SPVWorkflow.Activities
{
    [Action(
Category = "OrderCreation",
DisplayName = "Create_Order",
Description = "Create_Order",
Outcomes = new[] { OutcomeNames.Done, "Faulted" }
)]
    public class Create_Order : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {
            IFormatProvider culture = new CultureInfo("en-GB", true);
            try
            {
                HttpRequestModel ReqModel = JsonSerializer.Deserialize<HttpRequestModel>(JsonSerializer.Serialize(context.Input));
                SPVRequestOrder order = JsonSerializer.Deserialize<SPVRequestOrder>(context.Input.ToString());
                SPVWorkflow.Entities.SPVRequestOrder spvRequestOrder = new SPVWorkflow.Entities.SPVRequestOrder();

                //Get Variable
                var CreatedSPVRequestOrder = Convert.ToInt32(context.GetVariable("CreatedSPVRequestOrder"));

                using (var dbContext = new SPVContext())
                {

                    var correlationId = context.CorrelationId;
                    SPVWorkflow.Entities.SPVRequestOrder sPVRequestOrderData = dbContext.SPVRequestOrder
                        .AsQueryable().FirstOrDefault(x =>
                            x.RequestID == correlationId
                            && x.ChannelRefId == order.ChannelRefId
                        );
                    if (sPVRequestOrderData == null)
                    //if (true)
                    {
                        spvRequestOrder.RequestID = correlationId;
                        if (order.ChannelRefId == null)
                        {
                            throw new Exception("order.ChannelRefId cannot be null");
                        }
                        spvRequestOrder.ChannelRefId = order.ChannelRefId;
                        spvRequestOrder.OrderTransactionRefNo = GenOrderRefNo(order.OrderType, "BBB");
                        //spvRequestOrder.OrderTransactionRefNo = "SBBBB202216401708";
                        spvRequestOrder.SPVOrderStatus = order.SPVOrderStatus;
                        spvRequestOrder.OrderType = order.OrderType;
                        spvRequestOrder.FundCode = order.FundCode;
                        spvRequestOrder.FundCcy = order.FundCcy;
                        spvRequestOrder.OrgPaymentType = order.OrgPaymentType;
                        spvRequestOrder.PaymentType = order.PaymentType;
                        spvRequestOrder.InvestmentType = order.InvestmentType;
                        spvRequestOrder.OrgInvestmentAmount = order.OrgInvestmentAmount;
                        spvRequestOrder.InvestmentAmount = Convert.ToDecimal(order.InvestmentAmount);
                        spvRequestOrder.RISFrequency = order.RISFrequency;
                        spvRequestOrder.SwitchFromUnits = order.SwitchFromUnits;
                        spvRequestOrder.SwitchFromFundCode = order.SwitchFromFundCode;
                        spvRequestOrder.CreatedBy = order.CreatedBy;
                        spvRequestOrder.CreatedTime = DateTime.Now;
                        spvRequestOrder.UpdatedBy = order.UpdatedBy;
                        spvRequestOrder.UpdatedTime = DateTime.Now;
                        spvRequestOrder.WorkflowInd = order.WorkflowInd;
                        spvRequestOrder.BinIndicator = order.BinIndicator;
                        spvRequestOrder.CashAccountNo = order.CashAccountNo;
                        spvRequestOrder.CashAccountType = order.CashAccountType;
                        spvRequestOrder.CashAccountCurrency = order.CashAccountCurrency;
                        spvRequestOrder.CashAccountSignCondition = order.CashAccountSignCondition;
                        spvRequestOrder.IndicativeNAV = order.IndicativeNAV;
                        //spvRequestOrder.IndicativeNAVDate = order.IndicativeNAVDate;
                        spvRequestOrder.CardNumber = order.CardNumber;
                        spvRequestOrder.CPFApprovedBank = order.CPFApprovedBank;
                        spvRequestOrder.CPFInvestmentAccount = order.CPFInvestmentAccount;
                        spvRequestOrder.CPFAccount = order.CPFAccount;
                        spvRequestOrder.DividendInstruction = order.DividendInstruction;
                        spvRequestOrder.DividendCreditingAcct = order.DividendCreditingAcct;
                        spvRequestOrder.SalesCharge = order.SalesCharge;
                        spvRequestOrder.Remarks = order.Remarks;
                        spvRequestOrder.SAQIndicator = order.SAQIndicator;
                        spvRequestOrder.SRSOperator = order.SRSOperator;
                        spvRequestOrder.SRSAccount = order.SRSAccount;
                        spvRequestOrder.CreditingAcct = order.CreditingAcct;
                        spvRequestOrder.RISRecurringPeriod = order.RISRecurringPeriod;
                        //spvRequestOrder.RISStartDate = order.RISStartDate;
                        //spvRequestOrder.RISEndDate = order.RISEndDate;
                        spvRequestOrder.RISDividendInstruction = order.RISDividendInstruction;
                        spvRequestOrder.SwitchIndicativeAmount = order.SwitchIndicativeAmount;
                        //Why set like this????
                        //order.OrderStatusIndicator = "false";
                        dbContext.SPVRequestOrder.Add(spvRequestOrder);
                        dbContext.SaveChanges();
                        HttpRequestModel OutputModel = new HttpRequestModel(ReqModel.Path, ReqModel.Method,
                                                                                ReqModel.QueryString, ReqModel.Headers,
                                                                                order, JsonSerializer.Serialize(order));
                        context.Output = OutputModel;
                        CreatedSPVRequestOrder++;

                    }
                    else
                    {
                        throw new Exception("Duplicated SPVRequestOrder detected. Nothing inserted.");
                    }

                    context.SetVariable("CreatedSPVRequestOrder", CreatedSPVRequestOrder);
                    return Done();
                }
            }
            catch (Exception ex)
            {
                AuditLogger.Info("CreateOrder" + ex.Message);
                context.WorkflowExecutionContext.WorkflowContext = new MWPCreationException(OrderCreationError.PS00200.GetEnumDescription()) + " : " + ex.Message;
                return Outcome("Faulted", context.WorkflowExecutionContext.WorkflowContext);
            }
        }


        private static string ConvertDateTimeToJulian(DateTime? date)
        {
            string result = "";

            if (null != date)
            {
                DateTime dt = date.Value;
                TimeSpan diff = dt.Subtract(new DateTime(dt.Year - 1, 12, 31));
                Decimal jDay = Decimal.Truncate((Decimal)diff.TotalDays);
                result = dt.Year.ToString() + jDay.ToString().PadLeft(3, '0');
            }

            return result;
        }
        private string GenOrderRefNo(string orderType, String branch)
        {
            using (SPVContext ctx = new SPVContext())
            {
                var p = new SqlParameter("@result", System.Data.SqlDbType.Int);
                p.Direction = System.Data.ParameterDirection.Output;
                ctx.Database.ExecuteSqlRaw("set @result = next value FOR OrderRefNoSeq", p);
                int nextVal = (int)p.Value;
                string seq = nextVal.ToString().PadLeft(5, '0');

                string prefix = orderType;
                if (orderType == "RS")
                {
                    prefix = "RSP";
                }

                return prefix + branch + ConvertDateTimeToJulian(DateTime.Now) + seq;
            }
        }

    }
}
