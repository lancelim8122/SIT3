﻿using System.ComponentModel;
// ReSharper disable All

namespace RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic
{
    public enum PTCValidationError
    {

        //RIMT01 - Payment type supported
        [Description("This validation is applicable for RIS execution")]
        RIMT01NA01,
        [Description("Payment type not supported")]
        RIMT01ERROR01,


        //RIMT03 - SAQ Status Flag
        [Description("This validation is not applicable for RIS execution")]
        RIMT03NA01,
        [Description("This validation is applicable only for the UT orders placed via RM-Assisted channel")]
        RIMT03NA02,
        [Description("This validation is applicable only for trades whose payment method is 'CPFSA'")]
        RIMT03NA03,
        [Description("SAQ declaration is required")]
        RIMT03ERROR01,

        //RIMT04 - Change of Order Amount
        [Description("This validation is not applicable for RIS execution")]
        RIMT04NA01,
        [Description("This validation is applicable only for the UT orders placed via RM-Assisted channel")]
        RIMT04NA02,
        [Description("Order amount exceeds the advisory amount entered in WMS")]
        RIMT04ERROR01,


        //RIMT05 - Insufficent Fund Check
        [Description("This validation is not applicable for RIS execution")]
        RIMT05NA01,
        [Description("This validation is applicable only for the UT orders placed via RM-Assisted channel")]
        RIMT05NA02,
        [Description("This validation is not applicable for orders using CPFOA, CPFSA, SRS or financing type (UTLF1, UTLF2 or PF) as payment methods")]
        RIMT05NA03,
        [Description("For RIS setup, this validation is applicable only for credit card payment type.")]
        RIMT05NA04,
        [Description("Insufficient funds in the debiting account. Please enter a lower amount")]
        RIMT05ERROR01,
        [Description("Credit card  limit is less than RIS amount. Please enter a lower amount")]
        RIMT05ERROR02,


        //RIMT06
        [Description("This validation is applicable for all 'Sell' transactions")]
        RIMT06NA01,
        [Description("This validation is applicable only for the 'Cash holdings' ")]
        RIMT06NA02,

        // RIMT06A - Sufficient holdings check
        [Description("This validation will be performed only for partial sell (redemption or switch-out)")]
        RIMT06ANA01,
        [Description("Insufficient holdings/Holdings does not exist to perform this redemption/switch")]
        RIMT06AERROR01,


        //RIMT06B - Balance units’ check 
        [Description("This validation will be performed only for the partial sell orders")]
        RIMT06BNA01,
        [Description("This validation is not applicable for orders using CPFOA, CPFSA, SRS or financing type (UTLF1, UTLF2 or PF) as payment type")]
        RIMT06BNA02,
        [Description("Remaining amount balance is lower than required minimum amount balance")]
        RIMT06BERROR01,

        //RIMT08 - Product Setup last updated
        [Description("This validation will be performed only for the partial sell orders")]
        RIMT08NA01,
        [Description("Some of the product parameters have been changed post the advisory session.Pls check the Product Risk Rating vs the Customer Risk Profile.If there is a mismatch (i.e.PRR > CRP), pls inform Customer before proceeding with the transaction.")]
        RIMT08ER01,



        //RIMT10 - Minimum Amount/Units check
        [Description("This validation is applicable for all the order types such as Subscription, Redemption, Switch, RIS Setup, RIS amendment and RIS Execution")]
        RIMT10NA01,
        [Description("Subscription amount is less than Initial subscription amount")]   //Scenario 1
        RIMT10ERROR01,
        [Description("Initial subscription amount for switch-in fund is not met")]  //Scenario 3
        RIMT10ERROR02,
        [Description("Subscription amount is less than minimum subsequent subscription amount")]  //Scenario 5
        RIMT10ERROR03,
        [Description("The RIS amount is less than minimum amount")]  //Scenario 8
        RIMT10ERROR04,
        [Description("The switch-out units in order is lower than the minimum redemption/switch-out unit. Please check")]  //Scenario 10
        RIMT10ERROR05,
        [Description("The indicative switch-out amount in order is lower than the minimum redemption/switch-out amount. Please check")]  //Scenario 11
        RIMT10ERROR06,
        [Description("The redemption units in order is lower than the minimum redemption/switch-out unit. Please check")]  //Scenario 13
        RIMT10ERROR07,
        [Description("The indicative redemption amount in order  is lower than the minimum redemption/switch-out amount. Please check")]  //Scenario 14
        RIMT10ERROR08,

        //RIMT12 - Duplicate RIS Check
        [Description("This validation is applicable for “Cash” and the “non-cash” RIS instructions")]
        RIMT12NA01,
        [Description("Active RIS already exists for the fund (same investment type) and UT account")]
        RIMT12ERROR01,

        //RIMT13 - RIS Start Date Check
        [Description("This is applicable only for the Cash RIS instructions")]
        RIMT13NA01,
        [Description("Start Date must not be less than or equal to Current Business Date")]
        RIMT13ERROR01,

        //RIMT14 - Switch Rules

        [Description("Cannot perform switch across different fund currency")]
        RIMT14ER01,
        [Description("Cannot perform switch across different fund umbrella")]
        RIMT14ER02,
        [Description("Cannot perform switch across different investment type")]
        RIMT14ER03,
        [Description("Cannot perform switch across different dealing frequency")]
        RIMT14ER04,
        [Description("Cannot perform switch into an inactive fund")]
        RIMT14ER05,
        [Description("cannot perform switch across different fund house")]
        RIMT14ER06,

        //RIMT15 - Switch Cooling Cancellation
        [Description("This validation is applicable for all the switch transactions whose investment type is “Cash”")]
        RIMT15NA01,
        [Description("This validation is applicable only for unpledged cash holdings")]
        RIMT15NA02,
        [Description("Switching is not allowed for switch-out funds purchased within the fund allowable cooling period")]
        RIMT15ERROR01,

        //RIMT16 - RIS Allowed Check
        [Description("This validation will be performed for New to UT or Existing to UT")]
        RIMT16NA01,
        [Description("RIS subscription flag is turn off")]
        RIMT16ERROR01,

        //RIMT17 - Cap Fee Validation
        [Description("This validation is applicable only for the UT orders placed via RM-Assisted channel")]
        RIMT17NA01,
        [Description("This validation is not applicable for RIS execution")]
        RIMT17NA02,
        [Description("Sales charge cannot be greater than the Cap fee allowed for the fund")]
        RIMT17ERROR01,  //Scenario 1
        [Description("Switching fee cannot be greater than the Cap fee allowed for the fund")]
        RIMT17ERROR02,  //Scenario 3

        //RIMT18 - Devidend Instruction Check
        [Description("This validation is applicable only for the UT orders placed via RM-Assisted channel")]
        RIMT18NA01,
        [Description("Dividend crediting account field must not be shown in the UI")]
        RIMT18ER02,
        [Description("Both the “Reinvest” and “Get a cash payout” bullet buttons will not be exposed/available for selection, since payout is not applicable.")]
        RIMT18ER04,

        //RIMT19 - Payment Type based on Customer Entity


        //Scenario 3
        [Description("Not allow customer to change the payment type to CPFOA or CPFSA or SRS for a joint entity")]
        RIMT19ER01,

        //Scenario 5
        [Description("Not allow customer to choose this payment type as credit card is allowed only for single entity")]
        RIMT19ER02,

        //Scenario 6
        [Description("Not allow customer to choose this payment type as credit card is allowed only for SGD denominated funds")]
        RIMT19ER03,


        //RIMA01B - Existing CASA without fund currency check

        [Description("Open a new CASA accont")]
        RIMA01BER01,

        //RIMA02 - Mail address check

        [Description("Account address is not deliverable and system will grey oyut this account or card in the SPV screen")]
        RIMA02ER01,
        [Description("Account address is undeliverable")]
        RIMA02ER02,

        //RIMA06 - Valid credit card check

        //Step c- scenario 1
        [Description("This credit card will not be listed.")]
        RIMA06ER01,

        //step d - scenario 1
        [Description("Credit card expiry date is less than or equal to current date")]
        RIMA06ER02,
        //step d - scenario 2
        [Description("Credit card limit is less than the RIS amount")]
        RIMA06ER03,
        //step d - scenario 3
        [Description("The credit card is blocked")]
        RIMA06ER04,


        //RIMC01 - US Person/ Fatca Check

        [Description("Customer is a US person")]
        RIMC01ER01,

        //RIMC02 - Nationality restriction check

        [Description("Customer is not allowed to buy this fund due to his nationality")]
        RIMC02ER01,


        //RIMC03 - Residency restriction check

        [Description("Customer is not allowed to buy this fund due to his residency")]
        RIMC03ER01,

        //RIMG09 - Residency restriction check

        [Description("UT Sale person code is not present for the RM")]
        RIMG09ER01,



    }

    public enum CASAAccountValidationError
    {
        [Description("No valid CASA account retrieved in the fund currency.")]
        PS00900 = 9000,
        [Description("Open a new CASA account.")]
        PS00901 = 9001,
        [Description("No records found.")]
        PS00902 = 9002,
    }

    public enum PIBAndTMRWAccessCheck
    {
        [Description("Customer doesn’t have PIB/TMRW access.")]
        PS01000 = 10001,

    }

    public enum PaymentTypeBasedOnCustomerEntityError
    {
        [Description("Change the payment type to “CPFOA” or “CPFSA” or “SRS” for a joint entity is not allowed.")]
        PS01100 = 11000,

        [Description("Payment type as credit card is allowed only for single entity.")]
        PS01101 = 11001,

        [Description("Payment type as credit card is allowed only for SGD denominated funds.")]
        PS01102 = 11002,

        [Description("Payment type as RIS is only allowed.")]
        PS01103 = 11003,
    }

    public enum ValidCreditCardCheck
    {
        [Description("No Active Credit Card Account")]
        PS01200 = 12000,

        [Description("No active credit card match RIS supported card")]
        PS01201 = 12001,

        [Description("Insufficient credit limit")]
        PS01202 = 12002,

        [Description("Credit card is blocked")]
        PS01203 = 12003,
    }

}