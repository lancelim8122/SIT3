﻿using System;

namespace RIMS.SPVWorkflow.Activities.Generic
{
    public class PTC_ActivityOutputResult
    {
        public Exception Exception { get; set; }
        public object Builder { get; set; }
    }
}