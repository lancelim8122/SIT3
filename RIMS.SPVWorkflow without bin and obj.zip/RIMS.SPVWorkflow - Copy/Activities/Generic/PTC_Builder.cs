﻿using Elsa.Activities.Http.Models;
using Elsa.Services.Models;
using RIMS.SPV.DataAccess.Entities;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace RIMS.SPVWorkflow.Activities.Generic
{
    public class PTC_Builder
    {
        private SPVContext _context { get; set; }



        protected internal HttpRequestModel ReqModel;
        protected internal WorkFlowPTCRequest Request;

        protected internal SPVRequestOrder Order;
        protected internal SPVRequestCustomer Customer;
        protected internal SPVRequest spvRequest;
        protected internal UTFundProduct Product;
        protected internal AccountRelationship UTRAccount;
        protected internal AccountRelationship ActiveAccountByEntityNo;

        private List<String> _applicationTypeList;
        private List<String> _channelList;

        public PTC_Builder(SPVContext _dbContext, ActivityExecutionContext context)
        {

            _context = _dbContext;


            ReqModel = JsonSerializer
                .Deserialize<HttpRequestModel>(JsonSerializer.Serialize(context.Input));

            Request = JsonSerializer
                .Deserialize<WorkFlowPTCRequest>(ReqModel.Body.ToString());

            Order = JsonSerializer
                .Deserialize<SPVRequestOrder>(JsonSerializer.Serialize(Request.RequestDetails));


            var entityNo = Request.RequestHeader.RequesterContext.EntityNo;

            using (_context)
            {



                spvRequest = _context.SPVRequest.SingleOrDefault(r =>
                    r.RequestID == Order.RequestID
                );

                var fundCode = Order.FundCode;

                //Switch In product
                if (Order.OrderType == SPV_Order_Type.Switch && !string.IsNullOrEmpty(Order.SwitchFromFundCode))
                    fundCode = Order.SwitchFromFundCode;

                #region Temproray disable

                //Product = _context.UTFundProduct.SingleOrDefault(p =>
                //                    p.FundCode == fundCode
                //                );
                //if (Product == null)
                //    throw new PTC_FaultedException("UTFundProduct not found!");

                //Customer = _context.SPVRequestCustomer.SingleOrDefault(p =>
                //    p.RequestID == Order.RequestID
                //);


                //UTRAccount = _context.AccountRelationship.SingleOrDefault(a =>
                //    a.EntityNumber == entityNo
                //    && a.AccountType == "UTR"
                //    && a.AccountStatus == "Active"
                //);

                //ActiveAccountByEntityNo = _context.AccountRelationship.SingleOrDefault(a =>
                //    a.EntityNumber == entityNo
                //    && a.AccountStatus == "Active"
                //);


                #endregion


            }


        }

        public void setUpInitialValidation(List<String> applicationTypeList, List<string> channelList
        )
        {
            _applicationTypeList = applicationTypeList;
            _channelList = channelList;

            applicationTypeChannelValidation();
        }

        public void applicationTypeChannelValidation()
        {
            if (_applicationTypeList.Count > 0 && !_applicationTypeList.Contains(Order.OrderType))
            {

                throw new PTC_NotApplicationException("Application Type not applicable");
            }

            if (_channelList.Count > 0 && !_channelList.Contains(Request.RequestHeader.RequesterContext.TargetSystem))
            {
                throw new PTC_NotApplicationException("Channel Type not applicable");
            }


        }

    }
}