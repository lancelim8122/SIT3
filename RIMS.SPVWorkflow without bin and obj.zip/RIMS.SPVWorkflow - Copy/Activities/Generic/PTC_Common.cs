﻿namespace RIMS.SPVWorkflow.Activities.Generic
{
    public class PTC_Common
    {



    }


    public static class SPV_Order_Type
    {
        public const string Subscription = "SB";
        public const string Switch = "SW";
        public const string RISSetup = "RS";
        public const string Dividendinstruction = "DI";
        public const string Redemption = "RD";
        public const string Cancellation = "RD";

        public const string RISExecution = "RE";
        public const string RISAmend = "RA";
        public const string RISTermination = "RT";
        public const string SubscriptionCancellation = "SC";
        public const string ManageDividendinstruction = "MD";
    }

    public static class SPV_Order_Status
    {
        public const string Pending = "PENDING DETAILS";
        public const string PTCFailed = "PTC FAILED";
        public const string Delete = "AUTO DELETE";
        public const string Complete = "COMPLETE";
    }


    public static class PTCActivityOutcome
    {

        public const string Passed = "Passed";
        public const string Failed = "Failed";
        public const string NotApplicable = "Not Applicable";
        public const string Faulted = "Faulted";
    }

    public static class SPV_Payment_Type
    {

        public const string SB_CPF_OA = "PS_CPF_OA";
        public const string SB_CPF_SA = "PS_CPF_SA";
        public const string SB_Cash = "PS_CASH";
        public const string SB_SRS = "PS_SRS";
        public const string SB_UTLF1 = "PS_UTLF1";
        public const string SB_UTLF2 = "PS_UTLF2";
        public const string SB_PF = "PS_PF";


        public const string RIS_CPF_OA = "RIS_CPFOA";
        public const string RIS_CPF_SA = "RIS_CPFSA";
        public const string RIS_CASH = "RIS_CASH";
        public const string RIS_SRS = "RIS_SRS";
        public const string RIS_CARD = "RIS_CARD";

        public const string RIS_UTLF1 = "RIS_UTLF1";



    }

}
