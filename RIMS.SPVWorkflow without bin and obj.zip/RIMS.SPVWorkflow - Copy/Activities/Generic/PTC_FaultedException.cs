﻿using System;

namespace RIMS.SPVWorkflow.Activities.Generic
{
    public class PTC_FaultedException : Exception
    {
        public PTC_FaultedException(string errorMessage)
        {

        }
    }
}