﻿using System;

namespace RIMS.SPVWorkflow.Activities.Generic
{
    public class PTC_NotApplicationException : Exception
    {
        public PTC_NotApplicationException(string errorMessage)
        {

        }
    }
}