﻿using System;

namespace RIMS.SPVWorkflow.Activities.Generic
{
    public class PTC_ValidationFailedException : Exception
    {
        public PTC_ValidationFailedException(string errorMessage)
        {

        }
    }
}
