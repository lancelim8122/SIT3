﻿using RIMS.SPV.DataAccess;
using RIMS.SPVWorkflow.SPVWorkflow.Models.Product;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.Generic
{
    public class WorkFlowPTCRequest : Request
    {
        public PTCRequestHeader RequestHeader { get; set; }
        public SPVRequestOrder RequestDetails { get; set; }
    }
    public class PTCRequestHeader : RequestHeader
    {
        public PTCRequestRequesterContext RequesterContext { get; set; }
    }

    public class PTCRequestRequesterContext : RequesterContext
    {
        public WMS_SSO_Request SsoRequest { get; set; }

        public DraftOrderAPI DraftOrderRequest { get; set; }
        public MWPStatus MwpStatusRequest { get; set; }

        public CUS_API_Request CusApiRequest { get; set; }

        public string CorrelationId { get; set; }
        public string EntityNo { get; set; }

        public WMS_Screen_Request WmsScreen { get; set; }

    }



    public class WMS_SSO_Request : RequesterContext
    {
        public string EntityNo { get; set; }
        public string JourneyType { get; set; }
        public string SalesPersonOfficerCodeOrTeam { get; set; }
        public string UTSalesPersonCOde { get; set; }
        public string SalesPersonEmployeeID { get; set; }
        public string SalesPersonName { get; set; }
        public string BranchCode { get; set; }
        public string BranchName { get; set; }


    }

    public class WMS_API_Request
    {
        public string EntityNo { get; set; }
        public string MWPID { get; set; }
        public string MWPStatus { get; set; }
        public DateTime UpdatedOn { get; set; }
        public DateTime MWPValidityEndDate { get; set; }
    }
    public class DraftOrderAPI : WMS_API_Request
    {
        public DateTime MWPSignedDate { get; set; }

        public List<RequestCIF> CIFList { get; set; }

        public int CustomerRiskScore { get; set; }
        public DateTime RiskReviewDateTime { get; set; }
        public int RiskScore { get; set; }


    }

    public class RequestCIF
    {
        public string CIFNumber { get; set; }
        public string CustomerName { get; set; }
        public string NorminatedPartyInd { get; set; }
        public string PartyPresentIndicator { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }

    }

    public class MWPStatus : WMS_API_Request
    {

    }

    public class CUS_API_Request
    {
        public string CountryOfCitizenship { get; set; }
        public string CountryOfTIN { get; set; }
        public string FATCAStatus { get; set; }

        public string FatcaClassification { get; set; }

        public string USPersonDelaration { get; set; }
        public string EEADelaration { get; set; }

        public string CountryOfResidential { get; set; }
        public string CountryOfMailingAddress { get; set; }
    }


    public class WMS_Screen_Request
    {
        public decimal OrderAmount { get; set; }
        public bool SAQ_declaration { get; set; }
        public DateTime DraftOrderDateTime { get; set; }
        public string PaymentType { get; set; }



    }


}
