﻿using System;
using System.Globalization;
using System.Text.Json;
using Elsa;
using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using RIMS.SPVWorkflow.SPVWorkflow.Models.Product;

namespace RIMS.SPVWorkflow.Activities
{
    [Action(
Category = "MWPCreation",
DisplayName = "GetAllCASAAccounts",
Description = "GetAllCASAAccounts",
Outcomes = new[] { OutcomeNames.Done, "Faulted" }
)]
    public class GetAllCASAAccounts : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {
            IFormatProvider culture = new CultureInfo("en-GB", true);
            try
            {
                Order order = JsonSerializer.Deserialize<Order>(context.Input.ToString());
                SPVWorkflow.Entities.SPVRequestOrder spvRequestOrder = new SPVWorkflow.Entities.SPVRequestOrder();
                using (var dbContext = new SPVContext())
                {
                    //Entities.SPVRequestOrder sPVRequestOrderData = dbContext.SPVRequestOrder.AsQueryable()
                    //                            .Where(x => x.Id == order.Id).FirstOrDefault();
                    //if (order != null)
                    //{
                    //    spvRequestOrder.SPVOrderStatus = "Completed";
                    //    dbContext.SPVRequestOrder.Update(spvRequestOrder);
                    //    dbContext.SaveChanges();
                    //}
                    return Done();
                }
            }
            catch (Exception ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new MWPCreationException(OrderCreationError.PS00200.GetEnumDescription()) + " : " + ex.Message;
                return Outcome("Faulted", context.WorkflowExecutionContext.WorkflowContext);
            }
        }
    }
}
