﻿using System;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using Elsa;
using Elsa.Activities.Http.Models;
using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using SPVRequest = RIMS.SPVWorkflow.SPVWorkflow.Models.Product.SPVRequest;

namespace RIMS.SPVWorkflow.Activities
{
    [Action(
Category = "Order Creation",
DisplayName = "GetMWPRequestByMWPId",
Description = "Check MWP Request exist",
Outcomes = new[] { OutcomeNames.Done, "Not Found" }
)]
    public class GetMWPRequestByMWPId : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {
            IFormatProvider culture = new CultureInfo("en-GB", true);
            try
            {
                HttpRequestModel ReqModel = JsonSerializer.Deserialize<HttpRequestModel>(JsonSerializer.Serialize(context.Input));
                SPVRequest.SPVCreationBasicDetailRequest Request = System.Text.Json.JsonSerializer.Deserialize<SPVRequest.SPVCreationBasicDetailRequest>(ReqModel.Body.ToString());
                using (var dbContext = new SPVContext())
                {
                    SPVWorkflow.Entities.MWPRequest MWPRequestDB = dbContext.MWPRequest.AsQueryable().Where(x =>
                        x.MWPId == Request.RequestDetails.MWPSessionId
                    ).FirstOrDefault();

                    if (MWPRequestDB != null)
                    {
                        var NewSPVRequest = new SPVWorkflow.Entities.SPVRequest()
                        {
                            MWPSessionId = MWPRequestDB.MWPId,
                            MWPMinor = MWPRequestDB.MWPMinor,
                            MWPGen = MWPRequestDB.MWPGen,
                            EntityNo = MWPRequestDB.EntityNo,
                            ValidityEndDate = MWPRequestDB.ValidityEndDate,
                            Status = MWPRequestDB.Status,
                            StatusDesc = MWPRequestDB.StatusDesc,
                            StatusUpdateTime = MWPRequestDB.StatusUpdateTime,
                            CreatedBy = "tmp1rd",
                            CreatedTime = DateTime.Now,
                        };

                        dbContext.SPVRequest.Add(NewSPVRequest);
                        dbContext.SaveChanges();


                        HttpRequestModel OutputModel = new HttpRequestModel(ReqModel.Path, ReqModel.Method,
                                                                                ReqModel.QueryString, ReqModel.Headers,
                                                                                Request, JsonSerializer.Serialize(Request));
                        context.Output = OutputModel;


                    }
                    return Done();
                }
            }
            catch (Exception ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new MWPCreationException(OrderCreationError.PS00200.GetEnumDescription()) + " : " + ex.Message;
                return Outcome("Faulted", context.WorkflowExecutionContext.WorkflowContext);
            }
        }
    }
}
