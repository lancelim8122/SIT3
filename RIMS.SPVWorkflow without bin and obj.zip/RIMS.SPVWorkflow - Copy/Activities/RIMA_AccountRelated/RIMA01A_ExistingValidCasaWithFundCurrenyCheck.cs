﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.Common.MQ.Models;
using RIMS.Common.MQ.Models.CompositeEnquiry;
using RIMS.Common.MQ.Services;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RIMS.SPVWorkflow.Activities.RIMA_AccountRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_AccountRelated",
        Description = "Existing Valid Casa With Fund Curreny Check"

    )]
    //kok haw
    public class RIMA01A_ExistingValidCasaWithFundCurrenyCheck : Activity
    {
        public RIMA01A_ExistingValidCasaWithFundCurrenyCheck() { }
        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {
            try
            {
                //return Outcome(PTCActivityCommon.ActivityPassed);

                builder = new PTC_Builder(new SPVContext(), context);
                var dictionary = context.Input;

                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.Switch, SPV_Order_Type.RISSetup, SPV_Order_Type.Redemption,
                                         SPV_Order_Type.Cancellation, SPV_Order_Type.RISAmend, SPV_Order_Type.ManageDividendinstruction, SPV_Order_Type.SubscriptionCancellation},
                    new List<string>() { "RIM" }
                );

                var Order = builder.Order;
                var Product = builder.Product;

                //Retrieve the list of CASA accounts (including CSA & Mighty FX accounts) applicable for the input entity#
                var accountList = BWC1179GetCasaAccountList(builder.Request.RequestHeader.RequesterContext.EntityNo);
                BWCEnquiryService bwc = new BWCEnquiryService();
                //bwc.GetEntityActiveAccount()

                //Validate if there is any active CASA account for the input entity#
                var CasaAccountccy = accountList.Where(a => a.AcctStatus.Equals("1") || a.AcctStatus.Equals("4"));
                var PaymentType = builder.Order.PaymentType;
                var InvestmentType = builder.Order.InvestmentType;


                // validation 1 in 4.2.1.1
                if (CasaAccountccy.Count() == 0 && PaymentType == SPV_Payment_Type.SB_Cash && (InvestmentType == SPV_Order_Type.Subscription || InvestmentType == SPV_Order_Type.RISSetup))
                {
                    //throw error No valid CASA account retrieved in the fund currency
                    throw new PTC_ValidationFailedException(CASAAccountValidationError.PS00900.GetEnumDescription());
                }

                //validation 2 in 4.2.1.1
                if (CasaAccountccy.Count() == 1 && PaymentType == SPV_Payment_Type.SB_Cash && (InvestmentType == SPV_Order_Type.Subscription || InvestmentType == SPV_Order_Type.RISSetup))
                {
                    //proceed to step C
                    //This check will be validated using PTC Reference - RIMG07
                }

                // validation 3 in 4.2.1.1
                if (CasaAccountccy.Count() == 0 && PaymentType == SPV_Payment_Type.SB_Cash && (InvestmentType == SPV_Order_Type.Subscription || InvestmentType == SPV_Order_Type.RISSetup || InvestmentType == SPV_Order_Type.RISAmend || InvestmentType == SPV_Order_Type.ManageDividendinstruction))
                {
                    //throw error No valid CASA account retrieved in the fund currency
                    throw new PTC_ValidationFailedException(CASAAccountValidationError.PS00900.GetEnumDescription());
                }

                // validation 4 in 4.2.1.1
                if (CasaAccountccy.Count() == 1 && PaymentType == SPV_Payment_Type.SB_Cash && (InvestmentType == SPV_Order_Type.Subscription || InvestmentType == SPV_Order_Type.RISSetup || InvestmentType == SPV_Order_Type.RISAmend || InvestmentType == SPV_Order_Type.ManageDividendinstruction))
                {
                    //proceed to step D
                    //This check will be validated using PTC Reference - RIMA02.
                }

                // validation 5 in 4.2.1.1
                if (CasaAccountccy.Count() == 0 && PaymentType == SPV_Payment_Type.SB_PF && InvestmentType == SPV_Order_Type.Subscription)
                {
                    //throw error No valid CSA account retrieved in the fund currency
                    throw new PTC_ValidationFailedException(CASAAccountValidationError.PS00900.GetEnumDescription());
                }

                // validation 6 in 4.2.1.1
                if (CasaAccountccy.Count() == 1 && PaymentType == SPV_Payment_Type.SB_PF && InvestmentType == SPV_Order_Type.Subscription)
                {
                    //Outcome: Proceed to Step-C
                    //This check will be validated using PTC Reference - RIMG07
                }

                // validation 7 in 4.2.1.1
                if (CasaAccountccy.Count() == 0 && PaymentType == SPV_Payment_Type.SB_Cash && InvestmentType == SPV_Order_Type.Subscription)
                {
                    // This scenario is not applicable as dormant account will be filtered out as part of step-b
                    //return Outcome("Not Applicable");
                    throw new PTC_NotApplicationException(CASAAccountValidationError.PS00900.GetEnumDescription());
                }

                // validation 8 in 4.2.1.1
                if (CasaAccountccy.Count() == 0 && PaymentType == "Credit card" && InvestmentType == SPV_Order_Type.SubscriptionCancellation)
                {
                    //error throw No valid CASA account retrieved in the fund currency” 
                    throw new PTC_ValidationFailedException(CASAAccountValidationError.PS00900.GetEnumDescription());
                }

                //context.Output = 

                #region TestSampleData
                //to do - retrieve customer data from enquiry service
                /*
                //sample data
                DataTable table = new DataTable("Customers");
                //table.Columns.Add(new DataColumn("AccountNumber", typeof(string)));
                //table.Columns.Add(new DataColumn("AccountType", typeof(string)));
                //table.Columns.Add(new DataColumn("ProductType", typeof(string)));
                //table.Columns.Add(new DataColumn("AcctCur", typeof(int)));
                //table.Columns.Add(new DataColumn("AccountStatus", typeof(int)));
                //table.Columns.Add(new DataColumn("PaymentType", typeof(string)));
                //table.Columns.Add(new DataColumn("ApplicationType", typeof(string)));

                //table.Rows.Add("86194746", "SAV", "PE", 1, 1, "CASH", "SB"); // valid and active casa account
              //table.Rows.Add("86194746", "SAV", "PE", 2, 2, "CASH", "RS"); // valid and inactive casa account

                if (table.Rows.Count > 0)
                {
                    foreach (DataRow row in table.Rows)
                    {
                        string AccountNumber = row["AccountNumber"].ToString();
                        string AccountType = row["AccountType"].ToString();
                        string ProductType = row["ProductType"].ToString();
                        int AcctCur = int.Parse(row["AcctCur"].ToString());
                        int AccountStatus = int.Parse(row["AccountStatus"].ToString());

                        string CasaAccountccy = row["CasaAccountccy"].ToString();
                        string PaymentType = row["PaymentType"].ToString();
                        string ApplicationType = row["ApplicationType"].ToString();

                        // validation 1 in 4.2.1.1
                        if (CasaAccountccy == "F" && PaymentType == "CASH" && (ApplicationType == "SB" || ApplicationType == "RS"))
                        {
                            //throw error No valid CASA account retrieved in the fund currency
                            throw new RIMTValidationFailedException(CASAAccountValidationError.PS00800.GetEnumDescription());
                        }

                        //validation 2 in 4.2.1.1
                        if (CasaAccountccy == "T" && PaymentType == "CASH" && (ApplicationType == "SB" || ApplicationType == "RS"))
                        {
                            //proceed to step C
                            //This check will be validated using PTC Reference - RIMG07
                        }

                        // validation 3 in 4.2.1.1
                        if (CasaAccountccy == "F" && PaymentType == "CASH" && (ApplicationType == "SB" || ApplicationType == "RS" || ApplicationType == "RA" || ApplicationType == "MD"))
                        {
                            //throw error No valid CASA account retrieved in the fund currency
                            throw new RIMTValidationFailedException(CASAAccountValidationError.PS00800.GetEnumDescription());
                        }

                        // validation 4 in 4.2.1.1
                        if (CasaAccountccy == "T" && PaymentType == "CASH" && (ApplicationType == "SB" || ApplicationType == "RS" || ApplicationType == "RA" || ApplicationType == "MD"))
                        {
                            //proceed to step D
                            //This check will be validated using PTC Reference - RIMA02.
                        }

                        // validation 5 in 4.2.1.1
                        if (CasaAccountccy == "F" && PaymentType == "PF" && ApplicationType == "SB")
                        {
                            //throw error No valid CSA account retrieved in the fund currency
                            throw new RIMTValidationFailedException(CASAAccountValidationError.PS00800.GetEnumDescription());
                        }

                        // validation 6 in 4.2.1.1
                        if (CasaAccountccy == "T" && PaymentType == "PF" && ApplicationType == "SB")
                        {
                            //Outcome: Proceed to Step-C
                            //This check will be validated using PTC Reference - RIMG07
                        }

                        // validation 7 in 4.2.1.1
                        if (CasaAccountccy == "T" && PaymentType == "CASH" && ApplicationType == "SB")
                        {
                            // This scenario is not applicable as dormant account will be filtered out as part of step-b
                            //return Outcome("Not Applicable");
                            throw new RIMTValidationNotApplicableException(CASAAccountValidationError.PS00800.GetEnumDescription());
                        }

                        // validation 8 in 4.2.1.1
                        if (CasaAccountccy == "F" && PaymentType == "Credit card" && ApplicationType == "SC")
                        {
                            //error throw No valid CASA account retrieved in the fund currency” 
                            throw new RIMTValidationFailedException(CASAAccountValidationError.PS00800.GetEnumDescription());
                        }
                    }
                }
                else
                {
                    throw new RIMTValidationFailedException(CASAAccountValidationError.PS00802.GetEnumDescription());
                }
                */
                #endregion

                return Done();
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(CASAAccountValidationError.PS00900.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(CASAAccountValidationError.PS00900.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (Exception ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(CASAAccountValidationError.PS00900.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }
        }


        private List<EntityAcctSummInfo> BWC1179GetCasaAccountList(string entityNo)
        {
            var service = new RBKEnquiryService();
            var SvcCode = "CX_INQ_X";
            var SubSvcSeq = "BA_SUMM_INQ_N";
            EntityActiveAccSummaryInqReq detailReq = new EntityActiveAccSummaryInqReq();
            detailReq.SvcRq = new BaseEAIRequestSvcReq()
            {
                SvcCode = SvcCode,
                ChannelId = "RIMSG",
                Timestamp = new Timestamp(),

            };
            detailReq.SubSvcRq = new EntityActiveAccSummaryInqReq_SubSvcRq()
            {
                SubSvc = new EntityActiveAccSummaryInqReq_SubSvc()
                {
                    SubSvcRqHeader = new EntityActiveAccSummaryInqReq_SubSvcRqHeader()
                    {
                        SubSvcSeq = SubSvcSeq
                    },
                    SubSvcRqDetail = new EntityActiveAccSummaryInqReq_SubSvcRqDetail()
                    {

                        EntityNo = entityNo,
                        MoreRecIndicator = "N"  //Set to "N" in first inquiry
                    }
                }
            };

            try
            {
                EntityActiveAccSummaryInqRes response = service.GetEntityActiveAccountSummaryComposite(detailReq);

                if (response.SubSvcRs.SubSvc.SubSvcRsDetail.ListOfEntityAcctSummInfo.Count == 0)
                    throw new NullReferenceException("List of Entity Account is empty");


                var EntityAccountList = response.SubSvcRs.SubSvc.SubSvcRsDetail.ListOfEntityAcctSummInfo.ToList();
                var activeAccount = EntityAccountList.SelectMany(e => e.EntityAcctSummInfo).ToList();
                return activeAccount.Where(a =>
                   a.AcctType.Contains("SAV") && a.AcctType.Contains("CUR") &&
                    a.ProdType.Contains("PE") && a.ProdType.Contains("PF")
                ).ToList();

            }
            catch (Exception e)
            {
                throw new NullReferenceException("Failed to retrieve entity account from RBKEnquiryService");
            }

        }

    }
}