﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.Common.MQ.Models;
using RIMS.Common.MQ.Models.CompositeEnquiry;
using RIMS.Common.MQ.Services;
using RIMS.SPV.DataAccess.Entities;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RIMS.SPVWorkflow.Activities.RIMA_AccountRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_AccountRelated",
        Description = "Existing CASA without fund currency check"

    )]
    public class RIMA01B_ExistingValidCasa : Activity
    {
        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                builder = new PTC_Builder(new SPVContext(), context);
                var dictionary = context.Input;

                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.RISSetup, SPV_Order_Type.Switch },
                    new List<string>() { "RIM" }
                );

                var Order = builder.Order;
                var Product = builder.Product;


                #region BusinessLogic

                //Retrieve the list of CASA accounts (including CSA & Mighty FX accounts) applicable for the input entity#
                var accountList = BWC1179GetCasaAccountList(
                    builder.Request.RequestHeader.RequesterContext.EntityNo
                    , new List<string>() { "SAV", "CUR" }
                    , new List<string>() { "PE", "PF" }
                    );

                //Validate if there is any active CASA account for the input entity#
                var activeCasaAccount = accountList.FirstOrDefault(a =>
                    a.AcctStatus.Contains("1,4")
                );

                var paymentType = builder.Order.PaymentType;


                //Scenario 1 : No CASA Account found
                if (activeCasaAccount == null && paymentType.Contains("CASH,UTLF1,UTLF2,CPFOA,CPFSA,SRS,PF,Credit Card"))
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMA01BER01.GetEnumDescription());
                }



                return Outcome(PTCActivityOutcome.NotApplicable, new PTC_ActivityOutputResult() { Builder = builder });

                #endregion
            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00802.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00802.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00802.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }


        }

        private List<AccountRelationship> BWCGetCustomerList(string entityNo)
        {


            return new List<AccountRelationship>();
        }


        //Functional Requirement EAI UOBS RIMS 2.0 : 16.2.1 Entity Active Account Summary Inquiry
        // TC Code 1179
        public static List<EntityAcctSummInfo> BWC1179GetCasaAccountList(string entityNo
        , List<string> AccTypeFilter
        , List<string> ProdTypeFilter
        )
        {
            var service = new RBKEnquiryService();
            var SvcCode = "CX_INQ_X";
            var SubSvcSeq = "BA_SUMM_INQ_N";
            EntityActiveAccSummaryInqReq detailReq = new EntityActiveAccSummaryInqReq();
            detailReq.SvcRq = new BaseEAIRequestSvcReq()
            {
                SvcCode = SvcCode,
                ChannelId = "RIMSG",
                Timestamp = new Timestamp(),

            };
            detailReq.SubSvcRq = new EntityActiveAccSummaryInqReq_SubSvcRq()
            {
                SubSvc = new EntityActiveAccSummaryInqReq_SubSvc()
                {
                    SubSvcRqHeader = new EntityActiveAccSummaryInqReq_SubSvcRqHeader()
                    {
                        SubSvcSeq = SubSvcSeq
                    },
                    SubSvcRqDetail = new EntityActiveAccSummaryInqReq_SubSvcRqDetail()
                    {

                        EntityNo = entityNo,
                        MoreRecIndicator = "N"  //Set to "N" in first inquiry
                    }
                }
            };

            try
            {
                EntityActiveAccSummaryInqRes response = service.GetEntityActiveAccountSummaryComposite(detailReq);

                if (response.SubSvcRs.SubSvc.SubSvcRsDetail.ListOfEntityAcctSummInfo.Count == 0)
                    throw new NullReferenceException("List of Entity Account is empty");


                var EntityAccountList = response.SubSvcRs.SubSvc.SubSvcRsDetail.ListOfEntityAcctSummInfo.ToList();
                var activeAccount = EntityAccountList.SelectMany(e => e.EntityAcctSummInfo).ToList();
                if (AccTypeFilter.Count > 0)
                {
                    activeAccount = activeAccount.Where(a =>
                        AccTypeFilter.Contains(a.AcctType)
                    ).ToList();
                }
                if (ProdTypeFilter.Count > 0)
                {
                    activeAccount = activeAccount.Where(a =>
                         ProdTypeFilter.Contains(a.ProdType)
                    ).ToList();
                }
                return activeAccount;

            }
            catch (Exception e)
            {
                throw new NullReferenceException("Failed to retrieve entity account from RBKEnquiryService");
            }

        }

    }
}
