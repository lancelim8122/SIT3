﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.Common.MQ.Models;
using RIMS.Common.MQ.Models.CompositeEnquiry;
using RIMS.Common.MQ.Services;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMA_AccountRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_AccountRelated",
        Description = "Mailing address check"

    )]
    public class RIMA02_MailingAddressCheck : Activity
    {
        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                builder = new PTC_Builder(new SPVContext(), context);
                var dictionary = context.Input;

                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.Switch, SPV_Order_Type.Redemption, SPV_Order_Type.RISSetup, SPV_Order_Type.ManageDividendinstruction, SPV_Order_Type.RISAmend },
                    new List<string>() { "RIM", "MBK" }
                );


                #region BusinessLogic

                var AcctId = builder.ActiveAccountByEntityNo.AccountNumber;
                var AcctType = builder.ActiveAccountByEntityNo.AccountType;
                var address = BWC1008GetMailingAddress(AcctId, AcctType);
                if (address.VerifyAddrInd == "N" || address == null)
                {
                    return Outcome(PTCActivityOutcome.Passed);
                }
                else if (address.VerifyAddrInd == "Y")
                {
                    //Scenario 2.1
                    if (AcctType.Contains("CUR,SAV,CCP"))
                    {
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMA02ER01.GetEnumDescription());
                    }
                    //Scenario 2.2
                    else if (AcctType == "UTR")
                    {
                        //Account address is undeliverable
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMA02ER02.GetEnumDescription());
                    }
                }

                return Outcome(PTCActivityOutcome.NotApplicable, new PTC_ActivityOutputResult() { Builder = builder });

                #endregion

            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00802.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00802.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00802.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }


        }

        private RetrieveAcctToAddrRelationInqRes_AddrInfo BWC1008GetMailingAddress(string AcctId, string AcctType)
        {
            var service = new RBKEnquiryService();
            var SvcCode = "CX_INQ_X";
            var SubSvcSeq = "BA_ACCT_ADDR_N";
            RetrieveAcctToAddrRelationInqReq detailReq = new RetrieveAcctToAddrRelationInqReq();
            detailReq.SvcRq = new BaseEAIRequestSvcReq()
            {
                SvcCode = SvcCode,
                ChannelId = "RIMSG",
                Timestamp = new Timestamp(),

            };
            detailReq.SubSvcRq = new RetrieveAcctToAddrRelationInqReq_SubSvcRq()
            {

                SubSvc = new RetrieveAcctToAddrRelationInqReq_SubSvc()
                {
                    SubSvcRqHeader = new RetrieveAcctToAddrRelationInqReq_SubSvcRqHeader()
                    {
                        SubSvcSeq = SubSvcSeq
                    },
                    SubSvcRqDetail = new RetrieveAcctToAddrRelationInqReq_SubSvcRqDetail()
                    {

                        BankAcctReq = new RetrieveAcctToAddrRelationInqReq_BankAcctReq()
                        {
                            AcctType = AcctType,
                            AcctId = AcctId

                        }

                    }
                }
            };

            try
            {
                RetrieveAcctToAddrRelationInqRes response = service.GetAcctToAddrRelationComposite(detailReq);


                var address = response.SubSvcRs.SubSvc.SubSvcRsDetail.AddrInfo;
                return address;

            }
            catch (Exception e)
            {
                throw new NullReferenceException("Failed to retrieve entity account from RBKEnquiryService");
            }
        }
    }
}
