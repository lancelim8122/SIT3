﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMA_AccountRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_AccountRelated",
        Description = "Residency Restriction Check"

    )]
    public class RIMA03_UTAccountValidity : Activity
    {
        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                builder = new PTC_Builder(new SPVContext(), context);
                var dictionary = context.Input;

                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.Switch, SPV_Order_Type.RISSetup },
                    new List<string>() { "RIM" }
                );



                #region BusinessLogic

                var payload = builder.Request.RequestHeader.RequesterContext.CusApiRequest;

                //Scenario 1
                if (payload.CountryOfCitizenship == "US" || payload.CountryOfTIN == "US")
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMC01ER01.GetEnumDescription());
                }

                //Scenario 2
                if (
                    (payload.FATCAStatus == "Complete" && payload.FatcaClassification == "US ACC")
                    ||
                    (payload.FATCAStatus == "Pending")
                    )
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMC01ER01.GetEnumDescription());

                }

                //Scenario 3 
                if (payload.USPersonDelaration == "US Citizen")
                {
                    //Unknown the document said that US person declaration will be done
                    //as part of RIM as part of RIMC08
                    //So that mean we need to do RIMC8 or not?
                    return Outcome(PTCActivityOutcome.Passed);
                }

                //Scenario 4 & 5
                if (
                    payload.CountryOfCitizenship != "US" &&
                    payload.CountryOfTIN != "US" &&
                    payload.FATCAStatus == "Complete" &&
                    payload.FatcaClassification.Contains("Non US ACC,NA")

                    )
                {

                    //4
                    if (payload.USPersonDelaration == "Not a US Person" || payload.EEADelaration == "Not EEA investor")
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }
                    //5
                    if (payload.USPersonDelaration == "US Person" || payload.EEADelaration == "EEA investor")
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }

                }




                return Outcome(PTCActivityOutcome.NotApplicable, new PTC_ActivityOutputResult() { Builder = builder });

                #endregion
            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00802.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00802.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00802.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }


        }
    }
}
