﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.Common.MQ.Models.CompositeEnquiry;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RIMS.SPVWorkflow.Activities.RIMA_AccountRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_AccountRelated",
        Description = "Residency Restriction Check"

    )]
    public class RIMA06_ValidCreditCardCheck : Activity
    {
        PTC_Builder builder;
        private List<EntityAcctSummInfo> accountList;
        private EntityAcctSummInfo correctCreditCard;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                builder = new PTC_Builder(new SPVContext(), context);
                var dictionary = context.Input;

                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.RISSetup },
                    new List<string>() { "RIM" }
                );



                #region BusinessLogic

                var order = builder.Order;
                var product = builder.Product;

                var validationType = getValidationType();

                //RIMA06A RIS Setup validation
                if (builder.Request.RequestHeader.RequesterContext.TargetSystem == "RIM")
                {
                    //Step A , Step B , Step c
                    if (stepA() == false)
                        throw new PTC_ValidationFailedException("validated failed on RIMT19");

                    stepB();

                    stepC();


                }

                if (builder.Request.RequestHeader.RequesterContext.TargetSystem is "MBK" or "RIM")
                {
                    stepD();
                }



                return Outcome(PTCActivityOutcome.NotApplicable);

                #endregion
            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00802.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00802.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00802.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }


        }

        private void stepD()
        {
            DateTime currentDate = DateTime.Now;

            // need to identify how to get credit card 
            var creditCardExpDate = Convert.ToDateTime(correctCreditCard.AcctOpenDate);

            //Scenario 1
            if (creditCardExpDate.Date <= currentDate.Date)
            {
                //failed
                throw new PTC_ValidationFailedException(PTCValidationError.RIMA06ER02.GetEnumDescription());
            }

            var creditCardLimit = 0;
            var RISamount = builder.Request.RequestHeader.RequesterContext.WmsScreen.OrderAmount;
            //Scenario 2
            if (creditCardLimit <= RISamount)
            {
                //failed
                throw new PTC_ValidationFailedException(PTCValidationError.RIMA06ER03.GetEnumDescription());
            }


            //Scenario 3
            var blockCode = new List<string>() { "BLOCKA", "BLOCKB" };
            if (blockCode.Contains(correctCreditCard.AcctStatus))
            {
                //failed
                throw new PTC_ValidationFailedException(PTCValidationError.RIMA06ER04.GetEnumDescription());
            }

            //Scenario 4 : all Passed
            stepE();
        }

        private EntityAcctSummInfo? stepC()
        {
            var productCreditCardCode = builder.Product.OrderCustAccNo;


            correctCreditCard = accountList.FirstOrDefault(c =>
               c.AcctNo.Substring(0, 9) == productCreditCardCode
                );

            if (correctCreditCard == null)
            {
                throw new PTC_ValidationFailedException(PTCValidationError.RIMA06ER01.GetEnumDescription());
            }

            return correctCreditCard;


        }

        private string getValidationType()
        {
            return "RIS Setup";
        }


        public bool stepA()
        {
            return true;
            //Assume that RIMT19 included on same workflow
        }
        public void stepB()
        {
            accountList = RIMA01B_ExistingValidCasa.BWC1179GetCasaAccountList(
                builder.Request.RequestHeader.RequesterContext.EntityNo
                , new List<string>() { "CCP" }
                , null
                );
            //Assume that RIMT19 included on same workflow
        }
        public bool stepE()
        {
            return true;
            //Assume that RIMA02 included on same workflow
        }
    }
}
