﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.Common.MQ.Models;
using RIMS.Common.MQ.Models.CompositeEnquiry;
using RIMS.Common.MQ.Services;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMC_CustomerRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_CustomerRelated",
        Description = "Staff Check"

    )]
    public class RIMC06_StaffCheck : Activity
    {
        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                builder = new PTC_Builder(new SPVContext(), context);
                var dictionary = context.Input;

                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.RISSetup },
                    new List<string>() { "RIM" }
                );

                var Order = builder.Order;
                var Product = builder.Product;


                #region BusinessLogic

                var CustBasicInfoRs = BWC1066RetreiveCustomerBasicInfo("");
                if (CustBasicInfoRs.CustBasicInfo.InsiderCode is "M" or "S")
                {

                }

                return Outcome(PTCActivityOutcome.NotApplicable, new PTC_ActivityOutputResult() { Builder = builder });

                #endregion
            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00803.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00803.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00803.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }


        }



        //Functional Requirement EAI UOBS RIMS 2.0 : 16.2.1 Entity Active Account Summary Inquiry
        // TC Code 1179
        public static CustBasicInfoRs BWC1066RetreiveCustomerBasicInfo(string entityNo)
        {
            var service = new RBKEnquiryService();
            var SvcCode = "CX_INQ_X";
            var SubSvcSeq = "BA_CUST_INFO_N";
            RetrieveCustomerBasicDataInqReq detailReq = new RetrieveCustomerBasicDataInqReq();
            detailReq.SvcRq = new BaseEAIRequestSvcReq()
            {
                SvcCode = SvcCode,
                ChannelId = "RIMSG",
                Timestamp = new Timestamp(),

            };
            detailReq.SubSvcRq = new RetrieveCustomerBasicDataInqReqSubSvcRq()
            {
                SubSvc = new RetrieveCustomerBasicDataInqReqSubSvc()
                {
                    SubSvcRqHeader = new RetrieveCustomerBasicDataInqReq_SubSvcRqHeader()
                    {
                        SubSvcSeq = SubSvcSeq
                    },
                    SubSvcRqDetail = new RetrieveCustomerBasicDataInqReq_SubSvcRqDetail()
                    {

                        CIFNo = "",
                        IDNo = "",
                        IDType = "",
                        IDCountry = "",
                        ViewType = "",
                        AddressSeqNo = ""
                    }
                }
            };

            try
            {
                RetrieveCustomerBasicDataInqRes response = service.GetCustomerBasicInfoComposite(detailReq);

                if (response.SubSvcRs.SubSvc.SubSvcRsDetail.CustBasicInfoRs == null)
                    throw new NullReferenceException("List of Entity Account is empty");


                return response.SubSvcRs.SubSvc.SubSvcRsDetail.CustBasicInfoRs;

            }
            catch (Exception e)
            {
                throw new NullReferenceException("Failed to retrieve entity account from RBKEnquiryService");
            }

        }
    }
}
