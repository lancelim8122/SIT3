﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.Common.MQ.Models;
using RIMS.Common.MQ.Models.CompositeEnquiry;
using RIMS.Common.MQ.Services;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.Activities.RIMA_AccountRelated;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RIMS.SPVWorkflow.Activities.RIMG_Generic
{
    [Action(
        Outcomes = new[] { "Continuous", "Returning" },
        Category = "PTC_Generic",
        Description = "Parties Present check against CASA Account"

    )]
    public class RIMG07_PartiesPresentCheck : Activity
    {
        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                builder = new PTC_Builder(new SPVContext(), context);
                var dictionary = context.Input;

                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.RISSetup },
                    new List<string>() { "RIM" }
                );

                var Order = builder.Order;
                var Product = builder.Product;


                #region BusinessLogic

                var accountList = RIMA01B_ExistingValidCasa.BWC1179GetCasaAccountList(
                    builder.Request.RequestHeader.RequesterContext.EntityNo
                    , new List<string>() { "SAV", "CUR" }
                    , new List<string>() { "PE", "PF" }
                    );

                var Entity = builder.ActiveAccountByEntityNo.AccountRelationshipCode;
                var PartyPresent = builder.Customer.PartyPresent;

                //Scenario 1
                if (Entity == "Single" && PartyPresent == "Present")
                {
                    return Outcome(PTCActivityOutcome.Passed, accountList);
                }

                var JointAccountOnly = accountList.Where(j => j.AcctClassification == "JOINT-OR").ToList();

                //Scenario 2
                if (Entity == "Joint" && JointAccountOnly.Count > 0)
                {
                    return Outcome(PTCActivityOutcome.Passed, JointAccountOnly);
                }


                //Scenario 3
                if (Entity == "Joint" && JointAccountOnly.Count > 0)
                {
                    return Outcome(PTCActivityOutcome.Passed, JointAccountOnly);
                }


                return Outcome(PTCActivityOutcome.NotApplicable);

                #endregion
            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00804.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00804.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00804.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }


        }

        private List<SPVRequestCustomer> getCASAAccountsByEntityNo(string requesterContextEntityNo)
        {
            return new List<SPVRequestCustomer>();
        }

        private List<EntityAcctSummInfo> BWC1148GetCasaAccountList(string entityNo)
        {
            var service = new RBKEnquiryService();
            var SvcCode = "CX_INQ_X";
            var SubSvcSeq = "BA_SUMM_INQ_N";
            EntityActiveAccSummaryInqReq detailReq = new EntityActiveAccSummaryInqReq();
            detailReq.SvcRq = new BaseEAIRequestSvcReq()
            {
                SvcCode = SvcCode,
                ChannelId = "RIMSG",
                Timestamp = new Timestamp(),

            };
            detailReq.SubSvcRq = new EntityActiveAccSummaryInqReq_SubSvcRq()
            {
                SubSvc = new EntityActiveAccSummaryInqReq_SubSvc()
                {
                    SubSvcRqHeader = new EntityActiveAccSummaryInqReq_SubSvcRqHeader()
                    {
                        SubSvcSeq = SubSvcSeq
                    },
                    SubSvcRqDetail = new EntityActiveAccSummaryInqReq_SubSvcRqDetail()
                    {

                        EntityNo = entityNo,
                        MoreRecIndicator = "N"  //Set to "N" in first inquiry
                    }
                }
            };

            try
            {
                EntityActiveAccSummaryInqRes response = service.GetEntityActiveAccountSummaryComposite(detailReq);

                if (response.SubSvcRs.SubSvc.SubSvcRsDetail.ListOfEntityAcctSummInfo.Count == 0)
                    throw new NullReferenceException("List of Entity Account is empty");


                var EntityAccountList = response.SubSvcRs.SubSvc.SubSvcRsDetail.ListOfEntityAcctSummInfo.ToList();
                var activeAccount = EntityAccountList.SelectMany(e => e.EntityAcctSummInfo).ToList();
                return activeAccount.Where(a =>
                    a.AcctType.Contains("SAV,CUR") &&
                    a.ProdType.Contains("PE,PF")
                ).ToList();

            }
            catch (Exception e)
            {
                throw new NullReferenceException("Failed to retrieve entity account from RBKEnquiryService");
            }

        }

    }


}
