﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RIMS.SPVWorkflow.Activities.RIMG_Generic
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_Generic",
        Description = "UT Salesperson code check"

    )]
    public class RIMG09_UTSalespersonCodeCheck : Activity
    {
        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                builder = new PTC_Builder(new SPVContext(), context);
                var dictionary = context.Input;

                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.RISSetup, SPV_Order_Type.RISAmend },
                    new List<string>() { "RIM", "MBK" }
                );

                var UTSalesPersonCode = builder.Request.RequestHeader.RequesterContext.SsoRequest.UTSalesPersonCOde;

                var MWPID = builder.spvRequest.MWPSessionId;

                #region BusinessLogic

                if (string.IsNullOrEmpty(UTSalesPersonCode))
                {

                    #region User Click On Add/Edit details or Submit orders

                    if (clickedAddorEditDetailorSubmitOrder())
                    {
                        var OrderByMWPIDList = new SPVContext().SPVRequestOrder.AsQueryable().Where(s =>
                                s.RequestID == builder.spvRequest.RequestID
                                && s.Id != builder.Order.Id //do not include self!!
                        ).ToList();

                        //1.a
                        var SBSWRISList = OrderByMWPIDList.Where(o =>
                            new string[3] { SPV_Order_Type.Subscription, SPV_Order_Type.Switch, "RIS" }.Contains(o.OrderType)
                        ).ToList();
                        if (SBSWRISList.Count > 0)
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMG09ER01.GetEnumDescription());

                        //1.b
                        var SBOnlyList = OrderByMWPIDList.Where(o =>
                            o.OrderType == SPV_Order_Type.Subscription
                        ).ToList();
                        if (SBOnlyList.Count > 0)
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMG09ER01.GetEnumDescription());


                        //1.c
                        var SWOnlyList = OrderByMWPIDList.Where(o =>
                            o.OrderType == SPV_Order_Type.Switch
                        ).ToList();
                        if (SWOnlyList.Count > 0)
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMG09ER01.GetEnumDescription());

                        //1.d
                        var RSList = OrderByMWPIDList.Where(o =>
                            o.OrderType == SPV_Order_Type.RISSetup
                        );
                        if (RSList.Where(r => r.PaymentType == "CASH").ToList().Count > 0)
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMG09ER01.GetEnumDescription());

                        if (RSList.Where(r => r.PaymentType != "CASH").ToList().Count > 0)
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMG09ER01.GetEnumDescription());


                    }



                    #endregion

                    //2
                    if (clickedSell())
                    {
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMG09ER01.GetEnumDescription());
                    }

                    if (clickedRISAmend())
                    {
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMG09ER01.GetEnumDescription());
                    }
                    if (clickedRISTerminate())
                    {
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMG09ER01.GetEnumDescription());
                    }

                    if (clickedManageDicidendInstruction())
                    {
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMG09ER01.GetEnumDescription());
                    }


                    //3
                    if (clickedDownloadOrCancel())
                    {
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMG09ER01.GetEnumDescription());
                    }


                }

                return Outcome(PTCActivityOutcome.NotApplicable, new PTC_ActivityOutputResult() { Builder = builder });

                #endregion
            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00804.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00804.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00804.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }


        }

        private bool clickedManageDicidendInstruction()
        {
            return true;
        }

        private bool clickedDownloadOrCancel()
        {
            return true;
        }

        private bool clickedRISTerminate()
        {
            return true;
        }

        private bool clickedRISAmend()
        {
            return true;
        }

        private bool clickedSell()
        {
            return false;
        }

        private bool clickedAddorEditDetailorSubmitOrder()
        {
            //Need to determine user got performed 
            return true;
        }
    }


}
