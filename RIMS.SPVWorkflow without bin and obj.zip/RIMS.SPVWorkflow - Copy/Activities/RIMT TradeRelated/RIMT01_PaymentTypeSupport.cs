﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{


    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Payment type supported"

    )]
    public class RIMT01_PaymentTypeSupport : Activity
    {
        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {

                //context.WorkflowExecutionContext.WorkflowContext
                //Testing Consolidate

                //List<PTC_Response> listoferror = (List<PTC_Response>)context.GetVariable("ListOfError");


                #region SetVariable method

                //var testing = context.GetVariable("ListOfError");


                //var listoferror = JsonSerializer
                //    .Deserialize<PTC_Response>(JsonSerializer.Serialize(context.GetVariable("ListOfError")));

                ////listoferror.Add(PTCActivityOutcome.Passed);
                //var json_string = JsonSerializer.Serialize(listoferror);
                //context.SetVariable("ListOfError", json_string);



                #endregion


                #region Workflow context method

                //builder = new PTC_Builder(new SPVContext(), context);

                //List<PTC_Response_WorkContext> WorkflowExecutionContext = (List<PTC_Response_WorkContext>)context.WorkflowExecutionContext.WorkflowContext;
                //if (WorkflowExecutionContext == null)
                //{
                //    WorkflowExecutionContext = new List<PTC_Response_WorkContext>();
                //}
                //WorkflowExecutionContext.Add(new PTC_Response_WorkContext()
                //{
                //    Message = PTCActivityOutcome.Passed
                //});



                //context.WorkflowExecutionContext.WorkflowContext = WorkflowExecutionContext;

                //HttpRequestModel OutputModel = new HttpRequestModel(builder.ReqModel.Path, builder.ReqModel.Method,
                //    builder.ReqModel.QueryString, builder.ReqModel.Headers,
                //    builder.Request, JsonSerializer.Serialize(builder.Request));

                //context.Output = OutputModel;
                //return Outcome(PTCActivityOutcome.Passed);
                #endregion



                builder = new PTC_Builder(new SPVContext(), context);


                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Redemption, SPV_Order_Type.RISAmend },
                    new List<string>() { "RIM", "MBK" }
                );

                var Order = builder.Order;
                var Product = builder.Product;


                #region BusinessLogic

                var paymentMode = Product.PaymentMode;
                var RISPaymentMode = Product.RISPaymentMode;
                var modeOfSettlement = Order.PaymentType;

                //Note 1: Validation only applicable for RIS Execution
                if (Order.OrderType != SPV_Order_Type.RISExecution)
                    throw new PTC_NotApplicationException(PTCValidationError.RIMT01NA01.GetEnumDescription());


                if (Order.OrderType == SPV_Order_Type.Subscription)
                {
                    if (modeOfSettlement == SPV_Payment_Type.SB_CPF_OA)
                    {
                        if (paymentMode == "Cash")
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMT01ERROR01.GetEnumDescription());

                        if (paymentMode.Contains("Cash,UTLF1,UTLF2"))
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMT01ERROR01.GetEnumDescription());

                        if (paymentMode.Contains("Cash, SRS"))
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMT01ERROR01.GetEnumDescription());
                    }
                    else if (modeOfSettlement == SPV_Payment_Type.SB_Cash)
                    {

                        if (paymentMode.Contains("UTLF1,UTLF2,SRS,PF"))
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMT01ERROR01.GetEnumDescription());

                        if (paymentMode.Contains("Cash,UTLF1,UTLF2"))
                            return Outcome(PTCActivityOutcome.Passed);
                    }


                }
                else if (Order.OrderType == SPV_Order_Type.RISSetup)
                {
                    if (RISPaymentMode.Contains("Cash, SRS"))
                    {
                        if (modeOfSettlement == SPV_Payment_Type.RIS_CPF_OA)
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMT01ERROR01.GetEnumDescription());

                        if (modeOfSettlement == SPV_Payment_Type.RIS_UTLF1)
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMT01ERROR01.GetEnumDescription());
                    }

                    if (modeOfSettlement == SPV_Payment_Type.RIS_CARD)
                    {
                        if (RISPaymentMode.Contains("Cash,SRS,CPFOA,CPFSA"))
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMT01ERROR01.GetEnumDescription());

                        if (RISPaymentMode.Contains("Cash,SRS,CPFOA,CPFSA,Card"))
                            return Outcome(PTCActivityOutcome.Passed);
                    }

                }


                return Outcome(PTCActivityOutcome.NotApplicable);

                #endregion
            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }


        }

    }


    public class PTC_Response
    {

        public List<string> MessageList { get; set; }

        public PTC_Response()
        {
            MessageList = new List<string>();
        }

    }

    public class PTC_Response_WorkContext
    {

        public string Message { get; set; }

        public PTC_Response_WorkContext()
        {
            Message = "";
        }

    }

}
