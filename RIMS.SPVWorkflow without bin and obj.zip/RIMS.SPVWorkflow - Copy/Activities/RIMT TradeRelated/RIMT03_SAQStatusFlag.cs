﻿using Elsa.Activities.Http.Models;
using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "SAQ flag check"

    )]
    public class RIMT03_SAQStatusFlag : Activity
    {

        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {


            try
            {
                //Testing Consolidate
                builder = new PTC_Builder(new SPVContext(), context);
                List<PTC_Response_WorkContext> WorkflowExecutionContext = (List<PTC_Response_WorkContext>)context.WorkflowExecutionContext.WorkflowContext;

                if (WorkflowExecutionContext == null)
                {
                    WorkflowExecutionContext = new List<PTC_Response_WorkContext>();
                }

                WorkflowExecutionContext.Add(new PTC_Response_WorkContext()
                {
                    Message = PTCActivityOutcome.Failed
                });


                context.WorkflowExecutionContext.WorkflowContext = WorkflowExecutionContext;

                HttpRequestModel OutputModel = new HttpRequestModel(builder.ReqModel.Path, builder.ReqModel.Method,
                    builder.ReqModel.QueryString, builder.ReqModel.Headers,
                    builder.Request, JsonSerializer.Serialize(builder.Request));

                context.Output = OutputModel;

                return Outcome(PTCActivityOutcome.Failed);
                //throw new PTC_ValidationFailedException(PTCValidationError.RIMT03ERROR01.GetEnumDescription());

                builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.RISSetup },
                    new List<string>() { "RIM" }
                );

                var spvRequestOrder = builder.Order;
                var utFundProduct = builder.Product;


                #region BusinessLogic


                //Note 1: This validation is not applicable for RIS execution
                if (spvRequestOrder.OrderType == SPV_Order_Type.RISExecution)
                    throw new PTC_NotApplicationException(PTCValidationError.RIMT03NA01.GetEnumDescription());
                //return Outcome("This validation is not applicable for RIS execution");

                //Note 2: If there are multiple orders under a MWP ID using mode of settlement as “CPFSA”
                //and RM performs the enrichment for all the orders in the same sitting,
                //this declaration will be done only once.
                var MWPID = "";
                List<SPVRequestOrder> spvOrdersByMwpIdAndSettlementMode = getOrdersByMwpIdAndSettlementMode(MWPID, spvRequestOrder.InvestmentType);



                bool CPFSADeclaration = builder.Request.RequestHeader.RequesterContext.WmsScreen.SAQ_declaration;
                string ModeOfSettlement = spvRequestOrder.PaymentType;

                //This validation is applicable only for trades whose payment method is “CPFSA”
                if (new string[2] { "PS_CPF_SA", "RIS_CPFSA" }.Contains(ModeOfSettlement))
                {
                    if (CPFSADeclaration == false)
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMT03ERROR01.GetEnumDescription());
                    return Outcome(PTCActivityOutcome.Passed);
                }



                #endregion

                return Outcome(PTCActivityOutcome.NotApplicable, new PTC_ActivityOutputResult() { Builder = builder });


            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }



        }

        private List<SPVRequestOrder> getOrdersByMwpIdAndSettlementMode(string Mwpid, string investmentType)
        {
            using (var context = new SPVContext())
            {
                var orders = context.SPVRequestOrder.AsQueryable().Where(s =>
                    s.InvestmentType == investmentType
                //Missing for search filter MWPID
                );
                return orders.ToList();

            }


        }
    }
}
