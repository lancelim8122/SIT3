﻿using Elsa.Activities.Http.Models;
using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.Text.Json;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Change of order amount/units"

    )]
    public class RIMT04_ChangeOfOrderAmountOrUnits : Activity
    {

        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {
            try
            {

                //Testing Consolidate
                //var testing = context.GetVariable("ListOfError");


                //PTC_Response listoferror = JsonSerializer
                //    .Deserialize<PTC_Response>(JsonSerializer.Serialize(context.GetVariable("ListOfError")));

                //listoferror.MessageList.Add(PTCActivityOutcome.Faulted);
                //var json_string = JsonSerializer.Serialize(listoferror);
                //context.SetVariable("ListOfError", json_string);


                builder = new PTC_Builder(new SPVContext(), context);

                List<PTC_Response_WorkContext> WorkflowExecutionContext = (List<PTC_Response_WorkContext>)context.WorkflowExecutionContext.WorkflowContext;

                if (WorkflowExecutionContext == null)
                {
                    WorkflowExecutionContext = new List<PTC_Response_WorkContext>();
                }

                WorkflowExecutionContext.Add(new PTC_Response_WorkContext()
                {
                    Message = PTCActivityOutcome.Faulted
                });


                context.WorkflowExecutionContext.WorkflowContext = WorkflowExecutionContext;

                HttpRequestModel OutputModel = new HttpRequestModel(builder.ReqModel.Path, builder.ReqModel.Method,
                    builder.ReqModel.QueryString, builder.ReqModel.Headers,
                    builder.Request, JsonSerializer.Serialize(builder.Request));

                context.Output = OutputModel;


                return Outcome(PTCActivityOutcome.Faulted);

                builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.Switch, SPV_Order_Type.RISSetup },
                    new List<string>() { "RIM" }
                );

                var Order = builder.Order;
                var Product = builder.Product;


                #region Business Logic

                var orderAmountSPV = Order.InvestmentAmount;

                //Need to discuss with Minal whatever can get from requestpayload or not?
                var orderAmountWMSAdvisoryScreen = builder.Request.RequestHeader.RequesterContext.WmsScreen.OrderAmount;
                bool isBuyOrder = DetermineBuyOrder(builder.Order);

                var switchUnitsSPV = Order.SwitchIndicativeAmount;
                var switchUnitWMSAdvisoryScreen = 0;

                //Note 1.This validation is not applicable for RIS execution
                if (Order.OrderType == SPV_Order_Type.RISExecution)
                {
                    throw new PTC_NotApplicationException(PTCValidationError.RIMT04NA01.GetEnumDescription());

                }

                //For Subscription or RIS Setup
                if (Order.OrderType is SPV_Order_Type.Subscription or SPV_Order_Type.RISSetup)
                {
                    //scenario 1
                    if (isBuyOrder && orderAmountSPV > orderAmountWMSAdvisoryScreen)
                    {
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMT04ERROR01.GetEnumDescription());
                    }

                    //Scenario 2
                    if (orderAmountSPV < orderAmountWMSAdvisoryScreen)
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }

                    //Scenario 3 : no change
                    if (orderAmountSPV == orderAmountWMSAdvisoryScreen)
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }

                }
                else if (Order.OrderType == SPV_Order_Type.Switch)
                {

                    //Scenario 4 : switch Unit compare
                    if (switchUnitsSPV > switchUnitWMSAdvisoryScreen)
                    {
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMT04ERROR01.GetEnumDescription());
                    }
                    else
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }
                }


                //Undo

                //2.	For switch transactions, this refers to the switch-in fund code.

                #endregion




                return Outcome(PTCActivityOutcome.NotApplicable, new PTC_ActivityOutputResult() { Builder = builder });

            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }

        }

        private bool DetermineBuyOrder(SPVRequestOrder Order)
        {

            return (Order.OrderType is
                SPV_Order_Type.Subscription or
                SPV_Order_Type.RISSetup or
                SPV_Order_Type.Switch);
        }
    }
}
