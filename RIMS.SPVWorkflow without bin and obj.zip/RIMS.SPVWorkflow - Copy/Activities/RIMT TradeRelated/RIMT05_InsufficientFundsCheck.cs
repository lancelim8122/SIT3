﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.Common.MQ.Models;
using RIMS.Common.MQ.Models.CompositeEnquiry;
using RIMS.Common.MQ.Services;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Insufficient Fund"

    )]
    public class RIMT05_InsufficientFundsCheck : Activity
    {
        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {

                var builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.RISSetup },
                    new List<string>() { "RIM" }
                    );

                var Order = builder.Order;
                //var Order = context.WorkflowExecutionContext.;
                var Product = builder.Product;


                #region Business Logic


                //Note 1

                var orderAmountSPV = Order.InvestmentAmount;

                //For RBK account
                var availableFundRBK = getAccountBalanceByRBK(
                    builder.UTRAccount.AccountNumber.ToString(),
                    builder.UTRAccount.AccountType
                ); ;

                //For credit card
                var creditCardLimit = getCreditLimitByVSA(builder.UTRAccount.AccountNumber); ;

                var paymentType = Order.PaymentType;


                //1.	This validation is not applicable for orders using
                //CPFOA, CPFSA, SRS or financing type (UTLF1, UTLF2 or PF) as payment methods.
                var notApplicablePaymentMethod = new List<String>()
                {
                    "CPFOA", "CPFSA", "SRS"
                    , "UTLF1", "UTLF2", "PF"
                };
                if (notApplicablePaymentMethod.Contains(Product.PaymentMode))
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT05NA03.GetEnumDescription());
                }

                //3.	This validation is not applicable for RIS execution
                if (Order.OrderType == SPV_Order_Type.RISExecution)
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT05NA01.GetEnumDescription());
                }

                //4.	For RIS setup, this validation is applicable only for credit card payment type.
                if (Order.OrderType == SPV_Order_Type.RISSetup && Order.PaymentType != "Credit Card")
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT05NA04.GetEnumDescription());

                }

                //Undo part
                //2.	This validation does not check if the RBK has hold code or not.




                switch (paymentType)
                {
                    case SPV_Payment_Type.SB_Cash or SPV_Payment_Type.RIS_CASH:
                        if (orderAmountSPV > availableFundRBK)
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMT05ERROR01
                                .GetEnumDescription());


                        return Outcome(PTCActivityOutcome.Passed);

                    case SPV_Payment_Type.RIS_CARD:
                        if (orderAmountSPV > creditCardLimit)
                            throw new PTC_ValidationFailedException(PTCValidationError.RIMT05ERROR02
                                .GetEnumDescription());


                        return Outcome(PTCActivityOutcome.Passed);
                    default:
                        return Outcome(PTCActivityOutcome.NotApplicable, new PTC_ActivityOutputResult() { Builder = builder });

                }


                #endregion


            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }

        }

        public decimal getCreditLimitByVSA(string creditCardNumber)
        {
            var service = new RBKEnquiryService();
            var SvcCode = "CC_CC_INFO_N";
            var SubSvcSeq = "CC_CC_INFO_N";
            CreditCardInfoInqReq detailReq = new CreditCardInfoInqReq();
            detailReq.SvcRq = new BaseEAIRequestSvcReq()
            {
                SvcCode = SvcCode,
                ChannelId = "RIMSG",
                Timestamp = new Timestamp(),

            };
            detailReq.SubSvcRq = new CreditCardInfoInqReqSubSvcRq()
            {
                SubSvc = new CreditCardInfoInqReqSubSvc()
                {
                    SubSvcRqHeader = new CreditCardInfoInqReq_SubSvcRqHeader()
                    {
                        SubSvcSeq = SubSvcSeq
                    },
                    SubSvcRqDetail = new CreditCardInfoInqReq_SubSvcRqDetail()
                    {
                        CardNum = creditCardNumber
                    }
                }
            };

            try
            {
                CreditCardInfoInqRes response = service.GetCreditCardInfoComposite(detailReq);

                return Convert.ToDecimal(response.SubSvcRs.SubSvc.SubSvcRsDetail.CreditLimit);

            }
            catch (Exception e)
            {
                throw new NullReferenceException("Failed to retrieve balance from VSAEnquiryService");
            }
        }

        private decimal getAccountBalanceByRBK(string AcctNo, string AcctType)
        {
            var service = new RBKEnquiryService();
            var SvcCode = (AcctType.Contains("SAV,CUR")) ? "CX_INQ_X" : (AcctType == "CCP") ? "CC_CC_INFO_N" : "";
            var SubSvcSeq = (AcctType.Contains("SAV,CUR")) ? "AC_BAL_INQ_N" : (AcctType == "CCP") ? "CC_CC_INFO_N" : "";
            RetriveLstOfAccInfoDetailReq detailReq = new RetriveLstOfAccInfoDetailReq();
            detailReq.SvcRq = new BaseEAIRequestSvcReq()
            {
                SvcCode = SvcCode,
                ChannelId = "RIMSG",
                Timestamp = new Timestamp(),

            };
            detailReq.SubSvcRq = new RetriveLstOfAccInfoDetailReq_SubSvcRq()
            {
                SubSvc = new RetriveLstOfAccInfoDetailReq_SubSvc()
                {
                    SubSvcRqHeader = new RetriveLstOfAccInfoDetailReq_SubSvcRqHeader()
                    {
                        SubSvcSeq = SubSvcSeq
                    },
                    SubSvcRqDetail = new RetriveLstOfAccInfoDetailReq_SubSvcRqDetail()
                    {
                        AcctNo = AcctNo,
                        AcctType = AcctType
                    }
                }
            };

            try
            {
                RetriveLstOfAccInfoDetailRes response = service.GetAcctInfoComposite(detailReq);
                if (AcctType.Contains("SAV,CUR"))
                {

                    return Convert.ToDecimal(response.SubSvcRs.SubSvc.SubSvcRsDetail.AcctBal);
                }
                else if (AcctType == "CCP")
                {
                    //Suppose to 
                    return Convert.ToDecimal(response.SubSvcRs.SubSvc.SubSvcRsDetail.AcctBal);
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception e)
            {
                throw new NullReferenceException("Failed to retrieve balance from RBKEnquiryService");
            }

        }
    }
}
