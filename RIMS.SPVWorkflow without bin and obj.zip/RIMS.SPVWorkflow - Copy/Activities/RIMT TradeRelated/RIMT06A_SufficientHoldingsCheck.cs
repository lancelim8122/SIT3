﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Sufficient holding"

    )]
    public class RIMT06A_SufficientHoldingsCheck : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                var builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Redemption, SPV_Order_Type.Switch },
                    new List<string>() { "RIM", "MBK" }
                );

                var Order = builder.Order;
                var Product = builder.Product;


                #region Business Logic



                //Note 1. This validation will be performed only for partial sell (redemption or switch-out).
                if (Order.OrderType is not SPV_Order_Type.Redemption or SPV_Order_Type.Switch)
                {
                    throw new PTC_NotApplicationException(PTCValidationError.RIMT06ANA01
                        .GetEnumDescription());
                }

                int CustomerHoldingUnit = GetHoldingUnit();

                //Undo part
                int HoldingAvailableUnit = 0;
                int OrderUnit;

                var OrderRedeemUnits = Order.SwitchFromUnits;
                var OrderSwitchUnits = Order.SwitchFromUnits;

                if (OrderRedeemUnits < CustomerHoldingUnit || OrderSwitchUnits < CustomerHoldingUnit)
                {
                    return Outcome(PTCActivityOutcome.Passed);
                }
                else if (OrderRedeemUnits > CustomerHoldingUnit || OrderSwitchUnits > CustomerHoldingUnit)
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT06AERROR01.GetEnumDescription());

                }
                else if (HoldingAvailableUnit == 0)
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT06AERROR01.GetEnumDescription());

                }


                return Done();
                #endregion




            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }

        }

        private int GetHoldingUnit()
        {

            return 0;

        }

        private bool ApplicableForSellTransaction()
        {
            return true;
        }

        private bool ApplicableForCashHolding()
        {
            return true;
        }

        private bool ApplicableForunpledgedCashHoldings()
        {
            return true;
        }
    }
}
