﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Balance Unit Check"

    )]
    public class RIMT06B_BalanceUnitCheck : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                var builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Redemption, SPV_Order_Type.Switch },
                    new List<string>() { "RIM", "MBK" }
                );

                var Order = builder.Order;
                var Product = builder.Product;


                #region BusinessLogic

                //General Checking ===Begin

                if (ApplicableForSellTransaction() == false)
                    throw new PTC_NotApplicationException(
                        PTCValidationError.RIMT06NA01.GetEnumDescription());


                if (ApplicableForCashHolding() == false)
                    throw new PTC_NotApplicationException(
                        PTCValidationError.RIMT06NA02.GetEnumDescription());



                //General Checking ===End


                if (performedforPartialSellOrders() == false)
                    return Outcome("Skipped");

                int HoldingsUnit = 0;
                int remainingBalanceHoldingsUnit = 0;
                string minimumHoldingsType = "units"; //or amount
                int ProductMinimumHoldingsUnit = 0;
                int NAV = 1;

                if (minimumHoldingsType == "units") //Scenario 1
                {
                    int TakenUnits = 0;
                    remainingBalanceHoldingsUnit = HoldingsUnit - TakenUnits;
                    ProductMinimumHoldingsUnit *= NAV;
                    if (remainingBalanceHoldingsUnit >= ProductMinimumHoldingsUnit)
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }
                    else
                    {
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMT06BERROR01
                            .GetEnumDescription());

                    }
                }
                else if (minimumHoldingsType == "amount") // Scenario 3 and 4
                {
                    int TakenAmount = 0;    // Order.Indicative redemption amount or order.indicative switch amount
                    int HoldingsAmount = 0;
                    int ProductMinimumHoldingsAmount = 0;

                    TakenAmount *= NAV;
                    HoldingsAmount *= NAV;

                    var remainingBalanceHoldingsAmount = HoldingsAmount - TakenAmount;
                    if (remainingBalanceHoldingsAmount >= ProductMinimumHoldingsAmount)
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }
                    else
                    {
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMT06BERROR01
                            .GetEnumDescription());

                    }





                    //Scenario 3

                }




                #endregion

                return Done();


            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }
        }


        private bool ApplicableForSellTransaction()
        {
            return true;
        }

        private bool ApplicableForCashHolding()
        {
            return true;
        }

        private bool ApplicableForunpledgedCashHoldings()
        {
            return true;
        }

        //In this check RIM will compare the remaining balance holdings
        //[inclusive of the current sell order] against the minimum holdings
        //maintained at the fund level. 
        private bool performedforPartialSellOrders()
        {
            return true;
        }
    }
}
