﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Dividend Instruction"

    )]
    public class RIMT08_ProductSetupLastUpdate : Activity
    {


        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                var builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.Switch, SPV_Order_Type.RISSetup },
                    new List<string>() { "RIM" }
                );

                var Order = builder.Order;
                var ActivatedProduct = (builder.Product.Status == "Activated") ? builder.Product : null;


                #region BusinessLogic

                var ProductLastUpdated = ActivatedProduct.ModifiedDateTime;

                //Date when WMS pass MWP ID to RIM
                var dateTimeFromWMS = builder.Request.RequestHeader.RequesterContext.DraftOrderRequest.UpdatedOn;

                //Risk rating
                var riskRating = builder.Request.RequestHeader.RequesterContext.DraftOrderRequest.RiskScore;

                //Order enrichment @ SPV
                var datetimeOrderEnrichment = DateTime.Now; //Demo Value

                var FundALastUpdatedDate = DateTime.Now; //Demo Value
                var FundBLastUpdatedDate = DateTime.Now; //Demo Value

                var FundARIMLastUpdatedDate = DateTime.Now; //Demo Value
                var FundBRIMLastUpdatedDate = DateTime.Now; //Demo Value


                //Scenario 1
                if (
                    //dateTimeFromWMS< datetimeOrderEnrichment&& 
                    FundALastUpdatedDate.Date < FundARIMLastUpdatedDate.Date
                    && FundBLastUpdatedDate.Date < FundBRIMLastUpdatedDate.Date
                    )
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT08ER01.GetEnumDescription());
                }

                //Scenario 2
                if (
                    //dateTimeFromWMS< datetimeOrderEnrichment&& 
                    FundALastUpdatedDate.Date >= FundARIMLastUpdatedDate.Date
                    && FundBLastUpdatedDate.Date >= FundBRIMLastUpdatedDate.Date
                )
                {
                    return Outcome(PTCActivityOutcome.Passed);
                }

                //Scenario 3
                //if (
                //    //dateTimeFromWMS< datetimeOrderEnrichment&& 
                //    FundALastUpdatedDate.Date >= FundARIMLastUpdatedDate.Date
                //    && FundBLastUpdatedDate.Date >= FundBRIMLastUpdatedDate.Date
                //)
                //{
                //    return Outcome(PTCActivityOutcome.Passed);
                //}


                #endregion

                return Done();


            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }

        }

    }


}
