﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Min. Amount/Unit"

    )]
    public class RIMT10_MinimumAmountOrUnitsCheck : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                var builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.RISSetup, SPV_Order_Type.RISAmend },
                    new List<string>() { "RIM" }
                );

                var Order = builder.Order;
                var Product = builder.Product;


                #region BusinessLogic

                var applicableOrderType = new string[6]
                {
                    SPV_Order_Type.Subscription,   //Subscription
                    SPV_Order_Type.Redemption,   //Redemption
                    SPV_Order_Type.Switch,   //Switch
                    SPV_Order_Type.RISSetup,   //RIS Setup
                    SPV_Order_Type.RISAmend,   //RIS Amendment
                    SPV_Order_Type.RISExecution    //RIS Execution
                };
                if (!applicableOrderType.Contains(Order.OrderType))
                    throw new PTC_NotApplicationException(PTCValidationError.RIMT10NA01.GetEnumDescription());


                var ProductTransactionSize = 1;

                var minimumAmount = getMinimumSubscriptionAmount(builder);



                var OrderPurchaseAmount = Order.InvestmentAmount;
                bool isFirstSubscription = isFirstTimeSubscription(builder.UTRAccount.AccountNumber, Order.FundCode);
                int holdingTotalUnits = 0;


                //Scenario 1 and 2
                if (builder.Order.OrderType == SPV_Order_Type.Subscription && builder.Order.InvestmentType == "Cash"
                    && isFirstSubscription


                )

                {
                    //Scenario 1
                    if (minimumAmount < OrderPurchaseAmount)
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT10ERROR01.GetEnumDescription());
                    }
                    //Scenario 2
                    return Outcome(PTCActivityOutcome.Passed);

                }

                var switchInFundCode = Order.SwitchFromFundCode;

                //Scenario 3 and 4
                if (builder.Order.OrderType == SPV_Order_Type.Switch && hasHoldings(switchInFundCode) == false)
                {
                    var NAV = Order.IndicativeNAV;
                    var indicativeSwitchAmount = Order.SwitchIndicativeAmount * NAV;
                    if (indicativeSwitchAmount < minimumAmount)
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT10ERROR02.GetEnumDescription());
                    }

                    return Outcome(PTCActivityOutcome.Passed);
                }

                //Scenario 5 and 6
                if (Order.OrderType == SPV_Order_Type.Subscription && Order.InvestmentType == "Cash"
                    && isFirstSubscription == false
                    && hasHoldings(Order.FundCode, builder.UTRAccount.AccountNumber)
                    )
                {
                    if (OrderPurchaseAmount < minimumAmount)
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT10ERROR03.GetEnumDescription());
                    }
                    else if (OrderPurchaseAmount == minimumAmount)
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }

                }


                //Scenario 7
                var switchOutFundCode = "FundA";
                switchInFundCode = "FundB";

                var holdingsCountForSwitchIn = 0;

                var holdingsCountForSwitchOut = 0;
                var holdingsUnitsForSwitchOut = 0;

                if (
                    switchInFundCode != switchOutFundCode
                    && Order.OrderType == SPV_Order_Type.Switch && Order.InvestmentType == "Cash"
                    && holdingsCountForSwitchIn > 0
                    && holdingsUnitsForSwitchOut > 0 && holdingsUnitsForSwitchOut >= 1000

                )
                {
                    var orderIndicativeSwitchInAmount = 0;
                    if (orderIndicativeSwitchInAmount == minimumAmount)
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }
                }

                //Scenario 8 and 9
                if (Order.OrderType == SPV_Order_Type.RISAmend && Order.InvestmentType == "Cash")
                {
                    var orderRISAmount = 0;
                    if (orderRISAmount < minimumAmount)
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT10ERROR04.GetEnumDescription());
                    }
                    else
                    {
                        return Outcome(PTCActivityOutcome.Passed);

                    }
                }

                //Scenario 10 
                if (Order.OrderType == SPV_Order_Type.Switch)
                {
                    var MinimumRedemptionUnits = 0;
                    var MinimumRedemptionAmount = 0;

                    var IndicativeNAVforSwitchOutFund = 1;


                    var OrderSwitchUnits = 500;
                    var OrderIndicativeSwitchAmount = OrderSwitchUnits * IndicativeNAVforSwitchOutFund;

                    if (OrderSwitchUnits < MinimumRedemptionUnits)
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT10ERROR05.GetEnumDescription());
                    }
                    else if (OrderIndicativeSwitchAmount < MinimumRedemptionAmount) //Scenario 11
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT10ERROR06.GetEnumDescription());

                    }




                }





                #endregion

                return Done();


            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }

        }

        private bool hasHoldings(string fundcode, string accountNumber = null)
        {

            return (fundcode != null);

        }

        private bool isFirstTimeSubscription(string AcctNo, string fundCode)
        {
            using (var context = new SPVContext())
            {
                var subscription = context.SPVRequestOrder
                    .AsQueryable()
                    .Join(context.SPVRequest
                        , sro => sro.RequestID, sr => sr.RequestID
                        , (sro, sr) => new
                        {
                            RequestID = sro.RequestID,
                            EntityNo = sr.EntityNo,
                            FundCode = sro.FundCode
                        })
                    .Join(context.AccountRelationship
                        , r => r.EntityNo, a => a.EntityNumber
                        , (r, a) => new
                        {
                            AccountNumber = a.AccountNumber,
                            AccountType = a.AccountType,
                            AccountStatusCode = a.AccountStatusCode,
                            FundCode = r.FundCode
                        })
                    .FirstOrDefault(t =>
                        t.AccountNumber == AcctNo
                        && t.FundCode == fundCode
                    );
                return (subscription == null);
            }
        }

        private decimal getMinimumSubscriptionAmount(PTC_Builder builder)
        {
            decimal minimumAmount = 0;
            bool isFirstSB = isFirstTimeSubscription(builder.UTRAccount.AccountNumber, builder.Order.FundCode); //Need to know how to determine first or subsequent Subscription
            string switchType = getSwitchInOrOut(builder.Order); // Switch In or Switch Out transaction type
            string redemptionMinimumAmountType = "amount"; // Units or Amount

            //-	‘TransactionCode.Minimum Subscription Amount(Lump Sum / Switch-In)’
            //for the first subscription and switch-in to the fundcode
            if (new string[2] { SPV_Order_Type.Switch, "LS" }.Contains(builder.Order.OrderType) && switchType == "in")
            {
                if (isFirstSB)  //for the first subscription and switch-in to the fundcode
                {
                    minimumAmount = Convert.ToDecimal(builder.Product.WMSSBAmountMin);
                }
                else
                {
                    minimumAmount = Convert.ToDecimal(builder.Product.WMSSBSubseqAmountMin);
                }
            }
            else if (new string[3] { SPV_Order_Type.RISSetup, SPV_Order_Type.RISAmend, SPV_Order_Type.RISExecution }.Contains(builder.Order.OrderType))
            {
                minimumAmount = Convert.ToDecimal(builder.Product.WMSRISAmountMin);
            }
            else if (new string[2] { SPV_Order_Type.Switch, "LS" }.Contains(builder.Order.OrderType) && switchType == "out")
            {
                if (redemptionMinimumAmountType == "amount")
                {
                    minimumAmount = Convert.ToDecimal(builder.Product.WMSRDAmountMin);
                }
                else if (redemptionMinimumAmountType == "unit")
                {
                    minimumAmount = Convert.ToDecimal(builder.Product.WMSRDUnitsMin);
                }

            }


            return minimumAmount;
        }

        private string getSwitchInOrOut(SPVRequestOrder myOrder)
        {
            using (var context = new SPVContext())
            {
                var switchOutOrder = context.SPVRequestOrder
                    .AsQueryable()
                    .FirstOrDefault(s =>
                        s.SwitchFromFundCode == myOrder.FundCode
                    );
                return "in";
            }
        }
    }
}
