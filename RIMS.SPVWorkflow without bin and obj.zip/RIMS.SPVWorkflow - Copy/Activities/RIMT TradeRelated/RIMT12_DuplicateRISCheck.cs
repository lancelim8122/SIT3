﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPV.DataAccess.Entities;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Duplicate RIS"

    )]
    public class RIMT12_DuplicateRISCheck : Activity
    {
        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.RISSetup },
                    new List<string>() { "RIM", "MBK" }
                );


                #region Business Logic

                var activeRISInstruction = getActiveRISInstruction(builder.Product.FundCode, builder.Customer.CIFNo);
                var pseudoAccount = getPseudoAccount(builder.Request.RequestHeader.RequesterContext.EntityNo);

                var channelType = builder.Request.RequestHeader.RequesterContext.TargetSystem;

                var RIS2 = new SPVRequestOrder() { SPVOrderStatus = "Active" };
                var ProductRIS2 = new UTFundProduct() { RISPaymentMode = "SRS" };
                //var RIS2 = getActiveRISInstruction();


                bool ExistingtoUT = getLstUTOrder(builder.UTRAccount.AccountNumber, builder.Order.FundCode, builder.Order.InvestmentType);
                bool havePseudoAccount = (pseudoAccount == null);
                bool forRIM = (channelType == "RIM");

                //Scenario 1 and 2 and 3
                if (ExistingtoUT)
                {
                    // 1
                    if (
                        Equals(activeRISInstruction.FundCode, RIS2.FundCode) &&
                        activeRISInstruction.InvestmentType == "Cash(CASA)" &&
                        RIS2.InvestmentType == "Cash (Credit card)"

                        )
                    {

                        throw new PTC_ValidationFailedException(PTCValidationError.RIMT12ERROR01.GetEnumDescription());
                    }
                    // 2
                    else if (
                        Equals(activeRISInstruction.FundCode, RIS2.FundCode) &&
                        activeRISInstruction.InvestmentType == "Cash (SRS)" &&
                        RIS2.InvestmentType == "SRS"
                        )
                    {
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMT12ERROR01.GetEnumDescription());
                    }
                    // 3
                    else
                    {
                        //Need to clarification 
                        return Outcome(PTCActivityOutcome.Passed);
                    }

                }
                //Scenario  4 and 5
                else if (ExistingtoUT == false && havePseudoAccount)
                {
                    if (ProductRIS2.RISPaymentMode == SPV_Payment_Type.RIS_SRS)
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }
                    else if (ProductRIS2.RISPaymentMode == SPV_Payment_Type.RIS_CARD)
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT12ERROR01.GetEnumDescription());
                    }
                }
                //Scenario 6 and 7
                else if (ExistingtoUT == false && channelType == "MBK")
                {

                }
                //Scenario 8
                else if (forRIM)
                {


                    //Scenario 9
                    if (ExistingtoUT == false)
                    {

                    }
                }




                #endregion

                return Done();


            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }

        }

        private bool getLstUTOrder(string UTRAccount, string fundCode, string investmentType)
        {

            return (UTRAccount != null);
        }

        private AccountRelationship getPseudoAccount(string EntityNo)
        {
            using (var context = new SPVContext())
            {
                var account = context.AccountRelationship.AsQueryable()
                    .FirstOrDefault(a =>
                        a.AccountType == "PSC"
                        && a.EntityNumber == EntityNo
                    );
                return account;
            }
        }

        private SPVRequestOrder getActiveRISInstruction(string productFundCode, string CIFNo)
        {
            using (var context = new SPVContext())
            {
                var ris = context.SPVRequestOrder.AsQueryable().FirstOrDefault(o =>
                        o.FundCode == productFundCode
                        && o.OrderType == SPV_Order_Type.RISSetup
                        && (o.SPVOrderStatus == SPV_Order_Status.Pending)
                        && o.Id != builder.Order.Id //Not include self
                    );

                return ris;
            }
        }
    }


}
