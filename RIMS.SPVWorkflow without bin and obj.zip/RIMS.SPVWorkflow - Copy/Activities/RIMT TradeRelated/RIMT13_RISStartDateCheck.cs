﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPV.DataAccess.Entities;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "RIS Start date"

    )]
    public class RIMT13_RISStartDateCheck : Activity
    {
        private SPVRequestOrder _order;
        private UTFundProduct _product;

        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                var builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.RISSetup, SPV_Order_Type.RISAmend },
                    new List<string>() { "RIM" }
                );

                _order = builder.Order;
                _product = builder.Product;


                #region BusinessLogic
                var risStartDate = _order.RISStartDate;
                var risEndDate = _order.RISEndDate;

                DateTime risStartDateDateTime = Convert.ToDateTime(risStartDate);
                DateTime risEndDateDateTime = Convert.ToDateTime(risEndDate);
                DateTime currentDateTime = DateTime.Now;


                if (risEndDate == "")
                {
                    //Scenario 1 and 2 
                    if (risStartDateDateTime.Date <= currentDateTime.Date)
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT13ERROR01.GetEnumDescription());
                    }

                    //Scenario 3 and 4
                    if (risStartDateDateTime.Date > currentDateTime.Date)
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }
                }
                else
                {
                    //Scenario 5
                    if (currentDateTime.Date >= risStartDateDateTime.Date
                        && currentDateTime.Date <= risEndDateDateTime.Date)
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT13ERROR01.GetEnumDescription());
                    }

                    return Outcome(PTCActivityOutcome.Passed);


                }

                #endregion

                return Done();


            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }



        }
    }
}
