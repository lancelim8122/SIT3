﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPV.DataAccess.Entities;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Switch Rules"

    )]
    public class RIMT14_SwitchRules : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                var builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Switch },
                    new List<string>() { "RIM", "MBK" }
                );

                var utFundProduct = builder.Product;


                #region BusinessLogic

                var switchOutProduct = new UTFundProduct();
                var switchInProduct = new UTFundProduct();

                var switchOutProductFundHouse = switchOutProduct.FundType;
                var switchInProductFundHouse = switchInProduct.FundType;

                //Scenario 1
                if (switchInProduct.FundCcy != switchOutProduct.FundCcy)
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT14ER01.GetEnumDescription());
                }

                //Scenario 2
                if (switchOutProduct.FundUmbrella != switchInProduct.FundUmbrella)
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT14ER02.GetEnumDescription());
                }



                //Scenario 3
                if (
                    (switchOutProduct.PaymentMode is "CPFOA" or "CPFSA") &&
                    switchOutProduct.PaymentMode != switchInProduct.PaymentMode)
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT14ER03.GetEnumDescription());
                }


                //Scenario 4 and 5

                if ((switchOutProduct.PaymentMode == "CASH"))
                {
                    //Scenario 4 
                    if (
                        switchOutProduct.FundCcy == switchInProduct.FundCcy &&
                        switchOutProduct.FundUmbrella == switchInProduct.FundUmbrella &&
                        switchOutProduct.PaymentMode == switchInProduct.PaymentMode &&
                        (
                            switchOutProduct.DealingFrequency == switchInProduct.DealingFrequency &&
                            switchOutProduct.DealingFrequency == "Weekly"
                        ) &&
                        switchOutProductFundHouse == switchInProductFundHouse
                    )
                    {
                        return Outcome(PTCActivityOutcome.Passed);

                    }

                    //Scenario 5
                    if (switchOutProduct.DealingFrequency != switchInProduct.DealingFrequency)
                    {
                        throw new PTC_ValidationFailedException(PTCValidationError.RIMT14ER04.GetEnumDescription());
                    }


                }


                //Scenario 6
                if (switchInProduct.Status == "Inactive" && switchOutProduct.Status != switchInProduct.Status)
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT14ER05.GetEnumDescription());
                }

                //Scenario 7
                if (
                    switchOutProduct.FundCcy == switchInProduct.FundCcy &&
                    switchOutProduct.FundUmbrella == switchInProduct.FundUmbrella &&
                    switchOutProduct.PaymentMode == switchInProduct.PaymentMode &&
                    (
                        switchOutProduct.DealingFrequency == switchInProduct.DealingFrequency &&
                        switchOutProduct.DealingFrequency == "Weekly"
                    ) &&
                    (
                        switchOutProduct.Status == switchInProduct.Status
                        && switchInProduct.Status == "Active"
                    ) &&
                    switchOutProductFundHouse == switchInProductFundHouse
                )
                {
                    return Outcome(PTCActivityOutcome.Passed);

                }


                //Scenario 8
                if (switchOutProductFundHouse != switchInProductFundHouse)
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT14ER06.GetEnumDescription());
                }

                //Scenario 9
                if (
                    switchOutProductFundHouse != switchInProductFundHouse &&
                    switchOutProduct.FundUmbrella != switchInProduct.FundUmbrella
                    )
                {
                    var errorMessage =
                        PTCValidationError.RIMT14ER06.GetEnumDescription() + " " +
                        PTCValidationError.RIMT14ER06.GetEnumDescription();
                    throw new PTC_ValidationFailedException(errorMessage);
                }



                return Outcome(PTCActivityOutcome.NotApplicable);



                #endregion


            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }

        }
    }
}
