﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Switch cooling cancel period"

    )]
    public class RIMT15_SwitchCoolingCancellationPeriodCheck : Activity
    {

        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                var builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Switch },
                    new List<string>() { "RIM", "MBK" }
                );

                var spvRequestOrder = builder.Order;
                var utFundProduct = builder.Product;


                #region BusinessLogic

                //This validation is applicable for all the switch transactions
                //whose investment type is “Cash”. 
                if (spvRequestOrder.InvestmentType != "Cash")
                    throw new PTC_NotApplicationException(
                        PTCValidationError.RIMT15NA01.GetEnumDescription());

                //This validation is applicable only for unpledged cash holdings.

                var cancelPeriod = utFundProduct.CancelPeriod;
                if (checkForUnpledgedCashHoldings() == false)
                {
                    throw new PTC_NotApplicationException(
                        PTCValidationError.RIMT15NA02.GetEnumDescription());
                }


                //fetch all the confirmed subscription orders placed
                //for the UTR account + fund code within the cancellation period
                var confirmedSubscriptionOrders = getConfirmedSubscriptionOrders(builder.UTRAccount.AccountNumber);

                int switchOutUnit = 0;


                int latestSubscribedUnits = 0;

                int holdingAvailableUnitForFundOnDay1 = 0;
                DateTime fundCreatedDateTime = new DateTime(2022, 5, 2);
                int eligibleUnitToSwitch = holdingAvailableUnitForFundOnDay1;
                int holdingAvailableUnit = 0;


                foreach (var order in confirmedSubscriptionOrders)
                {
                    if (UsedByTransientOrder(order) == false)
                    {
                        holdingAvailableUnit += Convert.ToInt32(order.SwitchFromUnits);
                    }
                }

                var intSwitchUnits = getSwitchingUnits();


                //Scenario 1 or 2 or 3
                if (CheckSwitchingWithinCancellationPeriod(fundCreatedDateTime, cancelPeriod))
                {
                    //Scenario 1
                    if (intSwitchUnits > eligibleUnitToSwitch)
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT15ERROR01.GetEnumDescription());
                    }

                    //Scenario 2
                    if (eligibleUnitToSwitch == 0)
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT15ERROR01.GetEnumDescription());
                    }


                    //Scenario 3
                    if (intSwitchUnits == eligibleUnitToSwitch)
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }

                    //How about intSwitchUnits < eligibleUnitToSwitch
                }
                else
                {
                    //Scenario 4
                    if (intSwitchUnits < eligibleUnitToSwitch)
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }
                }



                #endregion

                return Done();


            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }

        }

        private bool checkForUnpledgedCashHoldings()
        {
            return false;
        }

        private bool CheckSwitchingWithinCancellationPeriod(DateTime startDateTime, short period)
        {

            var LastDay = startDateTime.AddDays(period);

            return (DateTime.Now.Date <= LastDay.Date);
        }

        private int getSwitchingUnits()
        {
            return 0;
        }

        private bool UsedByTransientOrder(SPVRequestOrder order)
        {
            return true;
        }

        private List<SPVRequestOrder> getConfirmedSubscriptionOrders(string accountNumber)
        {
            using (var context = new SPVContext())
            {
                //var confirmOrders = context.SPVRequestOrder.AsQueryable()
                //    .Join(context.SPVRequest
                //        , sro => sro.RequestID, sr => sr.RequestID
                //        , (sro, sr) => new
                //        {
                //            RequestID = sro.RequestID,
                //            EntityNo = sr.EntityNo,
                //            OrderType = sro.OrderType


                //        })
                //    .Join(context.AccountRelationship
                //        , r => r.EntityNo, a => a.EntityNumber
                //        , (r, a) => new
                //        {
                //            AccountNumber = a.AccountNumber,
                //            OrderType = r.OrderType
                //        })
                //    .Where(r2 =>
                //        r2.AccountNumber == accountNumber
                //        && r2.OrderType == SPV_Order_Type.Subscription

                //).ToList();
                //var confirmOrders =
                //    from sro in context.SPVRequestOrder
                //    join sr in context.SPVRequest on sro.RequestID equals sr.RequestID
                //    select new { sro,sr };
                //return confirmOrders;
                return new List<SPVRequestOrder>();
            }


        }
    }
}
