﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Cap Fee"

    )]
    public class RIMT17_CapFeeValidation : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                var builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.RISSetup, SPV_Order_Type.RISAmend },
                    new List<string>() { "RIM" }
                );

                var spvRequestOrder = builder.Order;


                #region BusinessLogic

                var SalesCharge = spvRequestOrder.SalesCharge;
                var switchingFee = 0;

                string CustomerUICCode = "";

                decimal orderAmount = 0;


                decimal capFee = 0;


                var IsUOBStaff = RIMC06_StaffCheck(builder.Customer);

                var FeePercentage = RetrieveFeePercentage(builder, IsUOBStaff);


                //Scenario 1
                if (spvRequestOrder.OrderType == SPV_Order_Type.Subscription && spvRequestOrder.InvestmentType == "Cash")
                {
                    if (SalesCharge > capFee)
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT17ERROR01.GetEnumDescription());
                    }
                    else //Scenario 2
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }
                }
                else if (spvRequestOrder.OrderType == SPV_Order_Type.Switch) //Scenario 3
                {
                    if (switchingFee > capFee)
                    {
                        throw new PTC_ValidationFailedException(
                            PTCValidationError.RIMT17ERROR02.GetEnumDescription());
                    }
                    else //Scenario 4
                    {
                        return Outcome(PTCActivityOutcome.Passed);
                    }

                }




                #endregion

                return Done();


            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }

        }

        private decimal RetrieveFeePercentage(PTC_Builder builder, bool isStaff)
        {
            var OrderNumberEntered = 0;
            var percentage = 0;
            var channelName = ""; //   RMAst / Online / All
            using (var context = new SPVContext())
            {
                var result = context.UTFundFeeMatrix.AsQueryable()
                    .Where(u =>
                    (OrderNumberEntered >= u.TransactAmountMin
                     && OrderNumberEntered <= u.TransactAmountMax)

                ).ToList();

                var validInvestmentType = new string[2] { "Cash", "SRS" };

                if (result.Count > 0)
                {
                    foreach (var matrix in result)
                    {
                        if (builder.Order.OrderType == SPV_Order_Type.Subscription)
                        {
                            if (isStaff)
                            {
                                if (channelName == "RMAst")
                                {
                                    //CashSRS
                                    if (validInvestmentType.Contains(builder.Order.InvestmentType))
                                    {
                                        return (decimal)matrix.SB_StaffRMAst_CshSRS_PCT;
                                    }
                                }
                                else if (channelName == "Online")
                                {
                                    //CashSRS
                                    if (validInvestmentType.Contains(builder.Order.InvestmentType))
                                    {
                                        if (matrix.SB_Staff_OnlineCshSRS_PCT != null)
                                            return (decimal)matrix.SB_Staff_OnlineCshSRS_PCT;
                                    }
                                }

                            }
                            else
                            {
                                if (channelName == "RMAst")
                                {
                                    //CashSRS
                                    if (validInvestmentType.Contains(builder.Order.InvestmentType))
                                    {
                                        return (decimal)matrix.SB_NonStaffRMAst_CshSRS_PCTMin;
                                    }
                                }
                                else if (channelName == "Online")
                                {
                                    //CashSRS
                                    if (validInvestmentType.Contains(builder.Order.InvestmentType))
                                    {
                                        return (decimal)matrix.SB_NonStaff_OnlineCshSRS_PCT;
                                    }
                                }
                            }
                            if (builder.Order.InvestmentType == "CPFOA")
                            {
                                return (decimal)matrix.SBSW_AllCust_OnlineCPFOA_PCT;
                            }

                        }
                        else if (builder.Order.OrderType == SPV_Order_Type.Switch)
                        {
                            if (isStaff)
                            {
                                if (channelName == "RMAst")
                                {
                                    //CashSRS
                                    if (validInvestmentType.Contains(builder.Order.InvestmentType))
                                    {
                                        return (decimal)matrix.SW_StaffRMAst_CshSRS_PCT;
                                    }
                                }
                                else if (channelName == "Online")
                                {
                                    //CashSRS
                                    if (validInvestmentType.Contains(builder.Order.InvestmentType))
                                    {
                                        return (decimal)matrix.SW_Staff_OnlineCshSRS_PCT;
                                    }
                                }
                            }
                            else
                            {
                                if (channelName == "RMAst")
                                {
                                    //CashSRS
                                    if (validInvestmentType.Contains(builder.Order.InvestmentType))
                                    {
                                        return (decimal)matrix.SW_NonStaffRMAst_CshSRS_PCTMin;
                                    }
                                }
                                else if (channelName == "Online")
                                {
                                    //CashSRS
                                    if (validInvestmentType.Contains(builder.Order.InvestmentType))
                                    {
                                        return (decimal)matrix.SW_NonStaff_OnlineCshSRS_PCT;
                                    }
                                }
                            }

                        }

                    }
                }

            }
            return 0;
        }

        private bool RIMC06_StaffCheck(SPVRequestCustomer customer)
        {
            var result = false;
            List<String> eligibleInsiderCode = new List<string>() { "M", "S" };
            string CustomerInsiderCode = "";

            if (eligibleInsiderCode.Contains(CustomerInsiderCode))
            {
                result = true;
            }

            return result;
        }
    }
}
