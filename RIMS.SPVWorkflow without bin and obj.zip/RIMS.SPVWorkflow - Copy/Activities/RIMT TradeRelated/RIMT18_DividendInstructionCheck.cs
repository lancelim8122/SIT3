﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Dividend Instruction"

    )]
    public class RIMT18_DividendInstructionCheck : Activity
    {


        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                var builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.RISSetup, SPV_Order_Type.Switch, SPV_Order_Type.ManageDividendinstruction, SPV_Order_Type.RISAmend },
                    new List<string>() { "RIM" }
                );

                var Order = builder.Order;
                var Product = builder.Product;


                #region BusinessLogic



                var ProductDividendInstruction = Product.DivReinvestMode;
                var PaymentType = Order.PaymentType;
                var InvestmentType = Order.InvestmentType;

                if (ProductDividendInstruction == "Cash")
                {
                    //Scenario 1.1
                    if (InvestmentType == "Cash" && PaymentType == "Cash")
                    {
                        MakeDividendCreditingAccountSameAsDebitAccount();
                        return Outcome(PTCActivityOutcome.Passed, PTC_RIMT18Scenario1Response.R01.GetEnumDescription());
                    }

                    //Scenario 1.2
                    if (InvestmentType == "Cash" && PaymentType == "Credit card" && Order.OrderType == SPV_Order_Type.RISSetup)
                    {
                        RIMA01A_ExistingValidCASA();
                        return Outcome(PTCActivityOutcome.Passed, PTC_RIMT18Scenario1Response.R02.GetEnumDescription());
                    }

                    //Scenario 1.3
                    if (InvestmentType == "Cash"
                        &&
                        (PaymentType == "UTLF1" || PaymentType == "UTLF2")
                       )
                    {
                        RIMA01A_ExistingValidCASA();
                    }

                    //Scenario 1.4
                    if (InvestmentType == "Cash" && PaymentType == "PF")
                    {
                        //MakeDividendCreditingAccountSameAsDebitAccount();
                        return Outcome(PTCActivityOutcome.Passed, PTC_RIMT18Scenario1Response.R01.GetEnumDescription());
                    }

                    //Scenario 1.5
                    if (InvestmentType == "Cash" && PaymentType == "CPFOA/CPFSA")
                    {
                        //MakeDividendCreditingAccountSameAsDebitAccount();
                        return Outcome(PTCActivityOutcome.Passed, PTC_RIMT18Scenario1Response.R01.GetEnumDescription());
                    }


                    //Scenario 1.6
                    if (InvestmentType == "SRS" && PaymentType == "SRS")
                    {
                        //MakeDividendCreditingAccountSameAsDebitAccount();
                        return Outcome(PTCActivityOutcome.Passed, PTC_RIMT18Scenario1Response.R01.GetEnumDescription());
                    }
                }
                else if (ProductDividendInstruction == "Reinvest")
                {
                    //DividendCreditingAccountField();
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT18ER02.GetEnumDescription());
                }
                else if (ProductDividendInstruction == "Both")
                {
                    //RetrieveTheDividendCreditingAccount();
                    return Outcome(PTCActivityOutcome.Passed);
                }
                else if (ProductDividendInstruction == "None")
                {
                    //HideBulletButton(new string[2] { "Reinvest", "Get a cash payout" });
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT18ER04.GetEnumDescription());
                }




                #endregion

                return Done();


            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }

        }

        private void HideBulletButton(string[] BulletButtonList)
        {

        }

        private void RetrieveTheDividendCreditingAccount()
        {

        }

        private void DividendCreditingAccountField()
        {

        }

        private void RIMA01A_ExistingValidCASA()
        {
            //throw new NotImplementedException();
        }

        private void MakeDividendCreditingAccountSameAsDebitAccount()
        {

        }
    }

    public enum PTC_RIMT18Scenario1Response
    {

        //RIMT - Payment type supported
        [Description("Default the dividend crediting account to be same as the debit account")]
        R01,

        [Description("List all the existing valid CASA accounts for the customer (RIMA01A)")]
        R02,

    }
}
