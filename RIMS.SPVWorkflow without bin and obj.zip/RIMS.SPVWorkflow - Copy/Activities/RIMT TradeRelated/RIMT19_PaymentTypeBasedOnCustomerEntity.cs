﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.Common.MQ.Models;
using RIMS.Common.MQ.Models.CompositeEnquiry;
using RIMS.Common.MQ.Services;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_AccountRelated",
        Description = "Existing Valid Casa With Fund Curreny Check"

    )]
    //kok haw
    public class RIMT19_PaymentTypeBasedOnCustomerEntity : Activity
    {
        public RIMT19_PaymentTypeBasedOnCustomerEntity() { }
        PTC_Builder builder;
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {
            try
            {
                builder = new PTC_Builder(new SPVContext(), context);
                var dictionary = context.Input;

                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.RISSetup },
                    new List<string>() { "RIM" }
                );

                var Order = builder.Order;
                var Product = builder.Product;

                //Retrieve the list of CASA accounts (including CSA & Mighty FX accounts) applicable for the input entity#
                var accountList = BWC1179GetCasaAccountList(builder.Request.RequestHeader.RequesterContext.EntityNo);

                //Validate if there is any active CASA account for the input entity#
                var userAcc = accountList.Where(a => a.AcctStatus.Equals("1") || a.AcctStatus.Equals("4")).FirstOrDefault();

                //switch (userAcc.EntityType) Kok Haw
                switch (userAcc.AcctClassification)
                {
                    case "Joint":
                        //scenario 1
                        if (Order.OrgPaymentType == SPV_Payment_Type.SB_Cash || (Order.PaymentType == SPV_Payment_Type.RIS_UTLF1 || Order.PaymentType == SPV_Payment_Type.SB_UTLF2))
                        {
                            //add RIS_UTLF1 + SB_UTLF2 into list
                            return Outcome(PTCActivityOutcome.Passed, new PTC_ActivityOutputResult() { Builder = builder });
                        }
                        //scenario 2
                        if ((Order.OrgPaymentType == SPV_Payment_Type.SB_Cash) || Order.PaymentType == SPV_Payment_Type.SB_PF)
                        {
                            return Outcome(PTCActivityOutcome.Passed, new PTC_ActivityOutputResult() { Builder = builder });
                        }

                        //scenario 3
                        if (Order.OrgPaymentType == SPV_Payment_Type.SB_Cash || (Order.PaymentType == SPV_Payment_Type.SB_CPF_OA || Order.PaymentType == SPV_Payment_Type.SB_CPF_SA || Order.PaymentType == SPV_Payment_Type.SB_SRS))
                        {
                            return Outcome(PTCActivityOutcome.Faulted, new PTC_ActivityOutputResult() { Builder = builder });
                            throw new PTC_ValidationFailedException(PaymentTypeBasedOnCustomerEntityError.PS01100.GetEnumDescription());
                        }

                        //scenario 5
                        if (Order.OrgPaymentType == SPV_Payment_Type.SB_Cash || Order.PaymentType == SPV_Payment_Type.RIS_CARD)
                        {
                            return Outcome(PTCActivityOutcome.Faulted, new PTC_ActivityOutputResult() { Builder = builder });
                            throw new PTC_ValidationFailedException(PaymentTypeBasedOnCustomerEntityError.PS01101.GetEnumDescription());
                        }

                        return Outcome(PTCActivityOutcome.Passed);

                    case "Single":
                        //scenario 4
                        if (Order.OrgPaymentType == SPV_Payment_Type.SB_Cash || (Order.PaymentType == SPV_Payment_Type.SB_CPF_OA || Order.PaymentType == SPV_Payment_Type.SB_CPF_SA || Order.PaymentType == SPV_Payment_Type.SB_SRS))
                        {
                            return Outcome(PTCActivityOutcome.Passed, new PTC_ActivityOutputResult() { Builder = builder });
                        }

                        //scenario 6
                        if (Order.OrgPaymentType == SPV_Payment_Type.SB_Cash && Order.PaymentType == SPV_Payment_Type.RIS_CARD && Product.FundCcy != "SGD")
                        {
                            return Outcome(PTCActivityOutcome.Faulted, new PTC_ActivityOutputResult() { Builder = builder });
                            throw new PTC_ValidationFailedException(PaymentTypeBasedOnCustomerEntityError.PS01102.GetEnumDescription());
                        }

                        //scenario 7
                        if (Order.OrgPaymentType == SPV_Payment_Type.SB_Cash && Order.PaymentType == SPV_Payment_Type.RIS_CARD && Product.FundCcy == "SGD")
                        {
                            return Outcome(PTCActivityOutcome.Passed, new PTC_ActivityOutputResult() { Builder = builder });
                            throw new PTC_ValidationFailedException(PaymentTypeBasedOnCustomerEntityError.PS01103.GetEnumDescription());
                        }

                        return Outcome(PTCActivityOutcome.Passed);

                }


                return Done();

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private List<EntityAcctSummInfo> BWC1179GetCasaAccountList(string entityNo)
        {
            var service = new RBKEnquiryService();
            var SvcCode = "CX_INQ_X";
            var SubSvcSeq = "BA_SUMM_INQ_N";
            EntityActiveAccSummaryInqReq detailReq = new EntityActiveAccSummaryInqReq();
            detailReq.SvcRq = new BaseEAIRequestSvcReq()
            {
                SvcCode = SvcCode,
                ChannelId = "RIMSG",
                Timestamp = new Timestamp(),

            };
            detailReq.SubSvcRq = new EntityActiveAccSummaryInqReq_SubSvcRq()
            {
                SubSvc = new EntityActiveAccSummaryInqReq_SubSvc()
                {
                    SubSvcRqHeader = new EntityActiveAccSummaryInqReq_SubSvcRqHeader()
                    {
                        SubSvcSeq = SubSvcSeq
                    },
                    SubSvcRqDetail = new EntityActiveAccSummaryInqReq_SubSvcRqDetail()
                    {

                        EntityNo = entityNo,
                        MoreRecIndicator = "N"  //Set to "N" in first inquiry
                    }
                }
            };

            try
            {
                EntityActiveAccSummaryInqRes response = service.GetEntityActiveAccountSummaryComposite(detailReq);

                if (response.SubSvcRs.SubSvc.SubSvcRsDetail.ListOfEntityAcctSummInfo.Count == 0)
                    throw new NullReferenceException("List of Entity Account is empty");


                var EntityAccountList = response.SubSvcRs.SubSvc.SubSvcRsDetail.ListOfEntityAcctSummInfo.ToList();
                var activeAccount = EntityAccountList.SelectMany(e => e.EntityAcctSummInfo).ToList();
                return activeAccount.Where(a =>
                   a.AcctType.Contains("SAV") && a.AcctType.Contains("CUR") &&
                    a.ProdType.Contains("PE") && a.ProdType.Contains("PF")
                ).ToList();

            }
            catch (Exception e)
            {
                throw new NullReferenceException("Failed to retrieve entity account from RBKEnquiryService");
            }

        }
    }
}
