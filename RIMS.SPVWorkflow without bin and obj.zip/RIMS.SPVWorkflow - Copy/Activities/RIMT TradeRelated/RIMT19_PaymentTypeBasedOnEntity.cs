﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.OrderManagementWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
        Outcomes = new[]
        {
            PTCActivityOutcome.Passed,
            PTCActivityOutcome.Failed,
            PTCActivityOutcome.NotApplicable,
            PTCActivityOutcome.Faulted
        },
        Category = "PTC_TradeRelated",
        Description = "Lump sum check"

    )]
    public class RIMT19_PaymentTypeBasedOnEntity : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {

            try
            {
                var builder = new PTC_Builder(new SPVContext(), context);
                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.RISSetup },
                    new List<string>() { "RIM" }
                );

                var utFundProduct = builder.Product;


                #region BusinessLogic

                var entityType = builder.ActiveAccountByEntityNo.AccountRelationshipCode;
                var paymentTypeAdvisory = builder.Order.PaymentType;
                var targetPaymentType = builder.Request.RequestHeader.RequesterContext.WmsScreen.PaymentType;

                //Scenario 1
                if (
                        entityType == "Joint"
                        && paymentTypeAdvisory == "Cash"
                        &&
                        (
                            (builder.Order.OrderType == SPV_Order_Type.Subscription && targetPaymentType is SPV_Payment_Type.SB_UTLF1 or SPV_Payment_Type.SB_UTLF2)
                            ||
                            (builder.Order.OrderType == SPV_Order_Type.RISSetup && targetPaymentType is SPV_Payment_Type.RIS_UTLF1)
                        )
                    )
                {
                    //Assume that RIMT01 and RIMA01A activity will be included on the workflow
                    return Outcome(PTCActivityOutcome.Passed);
                }

                //Scenario 2
                if (
                    entityType == "Joint"
                    && paymentTypeAdvisory == "Cash"
                    &&
                    (
                        (builder.Order.OrderType == SPV_Order_Type.Subscription
                         && targetPaymentType is SPV_Payment_Type.SB_PF
                         )


                    )
                )
                {
                    //Assume that RIMT01 and RIMA01A activity will be included on the workflow
                    return Outcome(PTCActivityOutcome.Passed);
                }


                //Scenario 3
                if (
                    entityType == "Joint"
                    && paymentTypeAdvisory == "Cash"
                    &&
                    (
                        (builder.Order.OrderType == SPV_Order_Type.Subscription
                         && targetPaymentType is SPV_Payment_Type.SB_CPF_OA or SPV_Payment_Type.SB_CPF_SA
                         )

                        ||
                        (builder.Order.OrderType == SPV_Order_Type.RISSetup
                         && targetPaymentType is SPV_Payment_Type.RIS_CPF_OA or SPV_Payment_Type.RIS_CPF_SA
                         )


                    )
                )
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT19ER01.GetEnumDescription());

                    //Return error
                }
                //Scenario 4
                if (
                    entityType == "Single"
                    && paymentTypeAdvisory == "Cash"
                    &&
                    (
                        (builder.Order.OrderType == SPV_Order_Type.Subscription
                         && targetPaymentType is SPV_Payment_Type.SB_CPF_OA or SPV_Payment_Type.SB_CPF_SA or SPV_Payment_Type.SB_SRS
                         )

                        ||
                        (builder.Order.OrderType == SPV_Order_Type.RISSetup
                         && targetPaymentType is SPV_Payment_Type.RIS_CPF_OA or SPV_Payment_Type.RIS_CPF_SA or SPV_Payment_Type.RIS_SRS
                         )


                    )
                )
                {
                    //Assume that RIMT01 activity will be included on the workflow
                    return Outcome(PTCActivityOutcome.Passed);
                }

                //Scenario 5
                if (
                    entityType == "Single"
                    && paymentTypeAdvisory == "Cash"
                    &&
                    (
                        (builder.Order.OrderType == SPV_Order_Type.Subscription
                         && targetPaymentType is "Card"
                         )

                        ||
                        (builder.Order.OrderType == SPV_Order_Type.RISSetup
                         && targetPaymentType is SPV_Payment_Type.RIS_CARD
                         )


                    )
                )
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT19ER02.GetEnumDescription());
                }

                //Scenario 6
                if (
                    entityType == "Single"
                    && paymentTypeAdvisory == "Cash"
                    &&
                    (
                        (builder.Order.OrderType == SPV_Order_Type.Subscription
                         && targetPaymentType is "Card"
                         )

                        ||
                        (builder.Order.OrderType == SPV_Order_Type.RISSetup
                         && targetPaymentType is SPV_Payment_Type.RIS_CARD
                         )


                    )
                    &&
                    (builder.Product.FundCcy != "SGD")
                )
                {
                    throw new PTC_ValidationFailedException(PTCValidationError.RIMT19ER03.GetEnumDescription());
                }
                //Scenario 7
                if (
                    entityType == "Single"
                    && paymentTypeAdvisory == "Cash"
                    &&
                    (
                        (builder.Order.OrderType == SPV_Order_Type.Subscription
                         && targetPaymentType is "Card"
                         )

                        ||
                        (builder.Order.OrderType == SPV_Order_Type.RISSetup
                         && targetPaymentType is SPV_Payment_Type.RIS_CARD
                         )


                    )
                    &&
                    (builder.Product.FundCcy == "SGD")
                )
                {
                    return Outcome(PTCActivityOutcome.Passed);
                }


                return Done();

                #endregion


            }
            catch (PTC_NotApplicationException ex)
            {
                //Error PTC RIMT  : This validation is applicable for RIS execution
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.NotApplicable, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (PTC_ValidationFailedException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Failed, context.WorkflowExecutionContext.WorkflowContext);
            }
            catch (NullReferenceException ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new ParamSetupException(PTCActivityError.PS00801.GetEnumDescription() + " : " + ex.Message);
                return Outcome(PTCActivityOutcome.Faulted, context.WorkflowExecutionContext.WorkflowContext);
            }

        }
    }
}
