﻿using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.Activities.Generic;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.Activities.RIMT_TradeRelated
{
    [Action(
      Outcomes = new[]
      {
          PTCActivityOutcome.Passed,
          PTCActivityOutcome.Failed,
          PTCActivityOutcome.NotApplicable,
          PTCActivityOutcome.Faulted
      },
      Category = "PTC_AccountRelated",
      Description = "Existing Valid Casa With Fund Curreny Check"

  )]
    //kok haw
    public class RIMT20_ReferenceCASACheck : Activity
    {
        public RIMT20_ReferenceCASACheck() { }
        PTC_Builder builder;

        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {
            try
            {
                //return Outcome(PTCActivityCommon.ActivityPassed);

                builder = new PTC_Builder(new SPVContext(), context);
                var dictionary = context.Input;

                builder.setUpInitialValidation(
                    new List<string>() { SPV_Order_Type.Subscription, SPV_Order_Type.RISSetup },
                    new List<string>() { "RIM" }
                );

                var Order = builder.Order;
                var Product = builder.Product;




                return Done();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
