﻿using System;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using Elsa.Activities.Http.Models;
using Elsa.ActivityResults;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using RIMS.SPVWorkflow.SPVWorkflow.Models.Product;
using RIMS.SPVWorkflow.SPVWorkflow.Utilities;

namespace RIMS.SPVWorkflow.Activities
{
    public class SaveCRSDeclaration : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {
            IFormatProvider culture = new CultureInfo("en-GB", true);
            try
            {
                HttpRequestModel ReqModel = JsonSerializer.Deserialize<HttpRequestModel>(JsonSerializer.Serialize(context.Input));
                CRSDecRequest crsRequest = JsonSerializer.Deserialize<CRSDecRequest>(context.Input.ToString());
                using (var dbContext = new SPVContext())
                {
                    SPVWorkflow.Entities.SPVCRSDeclaration crsDeclaration = dbContext.SPVCRSDeclaration.AsQueryable()
                                                .Where(x => x.SessionId == crsRequest.RequestDetails.SessionId).FirstOrDefault();
                    if (crsDeclaration == null)
                    {
                        crsDeclaration.SessionId = crsRequest.RequestDetails.SessionId;
                        crsDeclaration.TaxDeclaration = crsRequest.RequestDetails.TaxDeclaration;
                        crsDeclaration.CIFNo = crsRequest.RequestDetails.TaxResidency;
                        crsDeclaration.TaxResidency = crsRequest.RequestDetails.TaxResidency;
                        crsDeclaration.Tin = crsRequest.RequestDetails.TaxDeclaration;
                        dbContext.SPVCRSDeclaration.Add(crsDeclaration);
                        dbContext.SaveChanges();
                        HttpRequestModel OutputModel = new HttpRequestModel(ReqModel.Path, ReqModel.Method,
                                                                                ReqModel.QueryString, ReqModel.Headers,
                                                                                crsRequest, JsonSerializer.Serialize(crsRequest));
                        context.Output = OutputModel;
                    }
                    return Done();
                }
            }
            catch (Exception ex)
            {
                AuditLogger.Info("CRSDeclarationError" + ex.Message);
                context.WorkflowExecutionContext.WorkflowContext = new MWPCreationException(CRSDeclarationError.PS00300.GetEnumDescription()) + " : " + ex.Message;
                return Outcome("Faulted", context.WorkflowExecutionContext.WorkflowContext);
            }
        }
    }
}
