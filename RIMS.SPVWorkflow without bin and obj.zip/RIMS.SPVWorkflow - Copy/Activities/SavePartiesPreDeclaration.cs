﻿using System;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using Elsa.Activities.Http.Models;
using Elsa.ActivityResults;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using RIMS.SPVWorkflow.SPVWorkflow.Models.Product;
using RIMS.SPVWorkflow.SPVWorkflow.Utilities;

namespace RIMS.SPVWorkflow.Activities
{
    public class SavePartiesPreDeclaration : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {
            IFormatProvider culture = new CultureInfo("en-GB", true);
            try
            {
                HttpRequestModel ReqModel = JsonSerializer.Deserialize<HttpRequestModel>(JsonSerializer.Serialize(context.Input));
                PartiesDecRequest partiesRequest = JsonSerializer.Deserialize<PartiesDecRequest>(context.Input.ToString());
                using (var dbContext = new SPVContext())
                {
                    SPVWorkflow.Entities.SPVPartiesPresentDeclaration partiesDeclaration = dbContext.SPVPartiesPresentDeclaration.AsQueryable()
                                                .Where(x => x.SessionId == partiesRequest.RequestDetails.SessionId).FirstOrDefault();
                    if (partiesDeclaration == null)
                    {
                        partiesDeclaration.SessionId = partiesRequest.RequestDetails.SessionId;
                        partiesDeclaration.CIFNo = partiesRequest.RequestDetails.CIFNo;
                        partiesDeclaration.PresentIndicator = partiesRequest.RequestDetails.PresentIndicator;
                        dbContext.SPVPartiesPresentDeclaration.Add(partiesDeclaration);
                        dbContext.SaveChanges();
                        HttpRequestModel OutputModel = new HttpRequestModel(ReqModel.Path, ReqModel.Method,
                                                                                ReqModel.QueryString, ReqModel.Headers,
                                                                                partiesRequest, JsonSerializer.Serialize(partiesRequest));
                        context.Output = OutputModel;
                    }
                    return Done();
                }
            }
            catch (Exception ex)
            {
                AuditLogger.Info("PartiesDeclarationError" + ex.Message);
                context.WorkflowExecutionContext.WorkflowContext = new MWPCreationException(PartiesDeclarationError.PS00305.GetEnumDescription()) + " : " + ex.Message;
                return Outcome("Faulted", context.WorkflowExecutionContext.WorkflowContext);
            }
        }
    }
}
