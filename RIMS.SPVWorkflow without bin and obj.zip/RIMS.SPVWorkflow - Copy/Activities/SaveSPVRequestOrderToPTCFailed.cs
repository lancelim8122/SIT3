﻿using System;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using Elsa;
using Elsa.Activities.Http.Models;
using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using RIMS.SPVWorkflow.SPVWorkflow.Models.Product;

namespace RIMS.SPVWorkflow.Activities
{
    [Action(
Category = "MWPCreation",
DisplayName = "SaveSPVRequestOrderToPTCFailed",
Description = "SaveSPVRequestOrderToPTCFailed",
Outcomes = new[] { OutcomeNames.Done, "Faulted" }
)]
    public class SaveSPVRequestOrderToPTCFailed : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {
            IFormatProvider culture = new CultureInfo("en-GB", true);
            try
            {
                HttpRequestModel ReqModel = JsonSerializer.Deserialize<HttpRequestModel>(JsonSerializer.Serialize(context.Input));
                OrderRequest Request = System.Text.Json.JsonSerializer.Deserialize<OrderRequest>(ReqModel.Body.ToString());
                SPVWorkflow.Entities.SPVRequestOrder spvRequestOrder = new SPVWorkflow.Entities.SPVRequestOrder();
                using (var dbContext = new SPVContext())
                {
                    SPVWorkflow.Entities.SPVRequestOrder orderData = dbContext.SPVRequestOrder.AsQueryable()
                                                .Where(x => x.Id == Request.RequestDetails.Id).FirstOrDefault();
                    if (orderData != null)
                    {

                        spvRequestOrder.SPVOrderStatus = "PTCFAILED";
                        spvRequestOrder.ChannelRefId = Request.RequestDetails.RefId;
                        spvRequestOrder.OrderType = Request.RequestDetails.OrderType;
                        spvRequestOrder.FundCode = Request.RequestDetails.FundCode;
                        spvRequestOrder.FundCcy = Request.RequestDetails.FundCcy;
                        spvRequestOrder.OrgPaymentType = Request.RequestDetails.OrgPaymentType;
                        spvRequestOrder.PaymentType = Request.RequestDetails.PaymentType;
                        spvRequestOrder.InvestmentType = Request.RequestDetails.InvestmentType;
                        spvRequestOrder.OrgInvestmentAmount = Request.RequestDetails.OrgInvestmentAmount;
                        spvRequestOrder.InvestmentAmount = Convert.ToDecimal(Request.RequestDetails.InvestmentAmount);
                        spvRequestOrder.RISFrequency = Request.RequestDetails.RISFrequency;
                        spvRequestOrder.SwitchFromUnits = Request.RequestDetails.SwitchFromUnits;
                        spvRequestOrder.SwitchFromFundCode = Request.RequestDetails.SwitchFromFundCode;
                        spvRequestOrder.CreatedBy = Request.RequestDetails.CreatedBy;
                        //TO DO date need to add from request
                        spvRequestOrder.CreatedTime = Convert.ToDateTime("2019-01-06T17:16:40");
                        spvRequestOrder.UpdatedBy = Request.RequestDetails.UpdatedBy;
                        spvRequestOrder.UpdatedTime = Convert.ToDateTime("2019-01-06T17:16:40");
                        spvRequestOrder.WorkflowInd = Request.RequestDetails.WorkflowInd;
                        spvRequestOrder.BinIndicator = Request.RequestDetails.BinIndicator;
                        spvRequestOrder.CashAccountNo = Request.RequestDetails.CashAccountNo;
                        spvRequestOrder.CashAccountType = Request.RequestDetails.CashAccountType;
                        spvRequestOrder.CashAccountCurrency = Request.RequestDetails.CashAccountCurrency;
                        spvRequestOrder.CashAccountSignCondition = Request.RequestDetails.CashAccountSignCondition;
                        spvRequestOrder.IndicativeNAV = Request.RequestDetails.IndicativeNAV;
                        //spvRequestOrder.IndicativeNAVDate = order.IndicativeNAVDate;
                        spvRequestOrder.CardNumber = Request.RequestDetails.CardNumber;
                        spvRequestOrder.CPFApprovedBank = Request.RequestDetails.CPFApprovedBank;
                        spvRequestOrder.CPFInvestmentAccount = Request.RequestDetails.CPFInvestmentAccount;
                        spvRequestOrder.CPFAccount = Request.RequestDetails.CPFAccount;
                        spvRequestOrder.DividendInstruction = Request.RequestDetails.DividendInstruction;
                        spvRequestOrder.DividendCreditingAcct = Request.RequestDetails.DividendCreditingAcct;
                        spvRequestOrder.SalesCharge = Request.RequestDetails.SalesCharge;
                        spvRequestOrder.Remarks = Request.RequestDetails.Remarks;
                        spvRequestOrder.SAQIndicator = Request.RequestDetails.SAQIndicator;
                        spvRequestOrder.SRSOperator = Request.RequestDetails.SRSOperator;
                        spvRequestOrder.SRSAccount = Request.RequestDetails.SRSAccount;
                        spvRequestOrder.CreditingAcct = Request.RequestDetails.CreditingAcct;
                        spvRequestOrder.RISRecurringPeriod = Request.RequestDetails.RISRecurringPeriod;
                        //spvRequestOrder.RISStartDate = order.RISStartDate;
                        //spvRequestOrder.RISEndDate = order.RISEndDate;
                        spvRequestOrder.RISDividendInstruction = Request.RequestDetails.RISDividendInstruction;
                        spvRequestOrder.SwitchIndicativeAmount = Request.RequestDetails.SwitchIndicativeAmount;
                        dbContext.SPVRequestOrder.Update(spvRequestOrder);
                        dbContext.SaveChanges();
                    }

                }
                HttpRequestModel OutputModel = new HttpRequestModel(ReqModel.Path, ReqModel.Method,
                                                                                ReqModel.QueryString, ReqModel.Headers,
                                                                                Request, JsonSerializer.Serialize(Request));
                context.Output = OutputModel;
                return Done();
            }
            catch (Exception ex)
            {
                context.WorkflowExecutionContext.WorkflowContext = new MWPCreationException(OrderCreationError.PS00200.GetEnumDescription()) + " : " + ex.Message;
                return Outcome("Faulted", context.WorkflowExecutionContext.WorkflowContext);
            }
        }
    }
}
