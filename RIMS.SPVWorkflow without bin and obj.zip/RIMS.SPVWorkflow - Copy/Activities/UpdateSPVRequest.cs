﻿using System;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using Elsa;
using Elsa.Activities.Http.Models;
using Elsa.ActivityResults;
using Elsa.Attributes;
using Elsa.Services;
using Elsa.Services.Models;
using RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using RIMS.SPVWorkflow.SPVWorkflow.Models.Product;
using RIMS.SPVWorkflow.SPVWorkflow.Utilities;
using SPVRequest = RIMS.SPVWorkflow.SPVWorkflow.Models.Product.SPVRequest;

namespace RIMS.SPVWorkflow.Activities
{
    [Action(
Category = "OrderCreation_SIT",
DisplayName = "SaveSPVRequest",
Description = "Save SPV Request",
Outcomes = new[] { OutcomeNames.Done, "Faulted" }
)]
    public class UpdateSPVRequest : Activity
    {
        protected override IActivityExecutionResult OnExecute(ActivityExecutionContext context)
        {
            IFormatProvider culture = new CultureInfo("en-GB", true);
            try
            {
                HttpRequestModel ReqModel = JsonSerializer.Deserialize<HttpRequestModel>(JsonSerializer.Serialize(context.Input));
                SPVRequest.SPVCreationBasicDetailRequest Request = System.Text.Json.JsonSerializer.Deserialize<SPVRequest.SPVCreationBasicDetailRequest>(ReqModel.Body.ToString());
                SPVWorkflow.Entities.SPVRequest spvRequest = new SPVWorkflow.Entities.SPVRequest();
                using (var dbContext = new SPVContext())
                {
                    SPVWorkflow.Entities.SPVRequest OrderData = dbContext.SPVRequest
                        .AsQueryable().FirstOrDefault(x => x.MWPSessionId == Request.RequestDetails.MWPSessionId &&
                                                           x.EntityNo == Request.RequestDetails.EntityNumber);
                    if (OrderData == null)
                        throw new Exception("SPVRequest not found");

                    OrderData.Status = Request.RequestDetails.Status;
                    OrderData.StatusDesc = Request.RequestDetails.StatusDesc;
                    OrderData.StatusUpdateTime = Request.RequestDetails.StatusUpdateTime;
                    dbContext.SPVRequest.Update(OrderData);
                    dbContext.SaveChanges();


                    foreach (var customerRequest in Request.RequestDetails.Customer)
                    {
                        var customer_db = dbContext.MWPCustomer
                            .AsQueryable().FirstOrDefault(x => x.CIFNo == customerRequest.CIFNo);
                        if (customer_db != null)
                        {
                            customer_db.CustomerName1 = customerRequest.CustomerName1;
                            customer_db.CustomerName2 = customerRequest.CustomerName2;
                            customer_db.Email = customerRequest.Email;
                            customer_db.ContactNumber = customerRequest.ContactNumber;
                            dbContext.MWPCustomer.Update(customer_db);
                            dbContext.SaveChanges();

                        }

                    }
                    HttpRequestModel OutputModel = new HttpRequestModel(ReqModel.Path, ReqModel.Method,
                                                                                    ReqModel.QueryString, ReqModel.Headers,
                                                                                    Request, JsonSerializer.Serialize(Request));
                    context.Output = OutputModel;
                    return Done();
                }
            }
            catch (Exception ex)
            {



                var errorMessage = "UpdateSPVRequest Activity: " + ex.Message;
                var output = new SSOResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ErrorCode = OrderCreationError.PS00200.GetEnumDescription(),
                        ErrorDesc = errorMessage,
                        ErrorHost = "MWPWorkFlow",
                        ResponseStatus = "Faulted"
                    },


                };

                AuditLogger.Info(errorMessage);
                //var output = JsonSerializer.Serialize(
                //    new MWPCreationException(MWPCreationError.PS00100.GetEnumDescription()) + " : " + ex.Message);
                context.SetWorkflowContext(JsonSerializer.Serialize(output));


                return Outcome("Faulted", context.WorkflowExecutionContext.WorkflowContext);
            }
        }
    }
}
