﻿using System.ComponentModel;

namespace RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions
{
    public class CustomErrorMessage
    {
    }
    public enum MWPCreationError
    {
        [Description("Error occured during MWP Creation.")]
        PS00100 = 1000,
        [Description("Error occured during MWP Creation -Duplicate MWP Id/Invalid MWP Validity End Date.")]
        PS00101 = 1001,
    }

    public enum OrderCreationError
    {
        [Description("Error occured during Order Creation.")]
        PS00200 = 2000,
    }
    public enum CRSDeclarationError
    {
        [Description("Error occured during CRS Declaration.")]
        PS00300 = 3000,
    }
    public enum USEEADeclarationError
    {
        [Description("Error occured during Order Declaration.")]
        PS00302 = 3000,
    }
    public enum PartiesDeclarationError
    {
        [Description("Error occured during Parties Present Declaration.")]
        PS00305 = 3000,
    }

    public enum ParamSetuprError
    {
        [Description("Error occured during Promotion Code Staging.")]
        PS00100 = 1000,
        [Description("Error occured during UTFund Staging.")]
        PS00101 = 1001,
        [Description("Error occured during Fund House Staging.")]
        PS00102 = 1002,
        [Description("Error occured during Fee Matrix Staging.")]
        PS00103 = 1003,
        [Description("Error occured during Transaction Limit Staging.")]
        PS00104 = 1004,
        [Description("Error occured during Restriction Code Staging.")]
        PS00105 = 1005,
        [Description("Error occured during Credit Card for RIS Staging.")]
        PS00106 = 1006,
        [Description("Error occured during Dividend Calendar Staging.")]
        PS00107 = 1007,
        [Description("Error occured during Holiday Calendar Staging.")]
        PS00108 = 1008,
        [Description("Error occured during Staging.")]
        PS00109 = 1009,
    }


    public enum PTCActivityError
    {
        [Description("Error PTC RIMT Activity")]
        PS00801 = 8001,
        [Description("Error PTC RIMA Activity.")]
        PS00802 = 8002,
        [Description("Error PTC RIMC Activity.")]
        PS00803 = 8003,
        [Description("Error PTC RIMG Activity.")]
        PS00804 = 8004,
    }
}
