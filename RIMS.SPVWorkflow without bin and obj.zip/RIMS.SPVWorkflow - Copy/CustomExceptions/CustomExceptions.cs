﻿using System;
using System.ComponentModel;

namespace RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions
{
    public abstract class CustomExceptionBase : Exception
    {

        public CustomExceptionBase()
            : base()
        {
        }

        public CustomExceptionBase(string message)
            : base(message)
        {
        }
        public CustomExceptionBase(string message, Exception innerEx)
            : base(message, innerEx)
        {
        }
        public abstract String ErrorCode { get; }
        public abstract String ErrorDesc { get; }
        public abstract String ErrorHost { get; set; }
        public abstract String GetErrorMessage();
    }
    public class MWPCreationException : CustomExceptionBase
    {
        private string extraInfo;
        public override String ErrorHost { get; set; } = "WorkFlow";
        public override String ErrorCode { get { return ((int)MWPCreationError.PS00100).ToString(); } }
        public override String ErrorDesc { get { return "EAI returned Error during Payment Processing."; } }


        public MWPCreationException(string message)
            : base(message)
        {
            this.extraInfo = message;
        }
        public MWPCreationException(string message, Exception innerEx)
            : base(message, innerEx)
        {
            this.extraInfo = message;
        }
        public override String GetErrorMessage()
        {
            return this.extraInfo;
        }
    }



    public static class EnumExtensionMethods
    {
        public static string GetEnumDescription(this Enum enumValue)
        {
            var fieldInfo = enumValue.GetType().GetField(enumValue.ToString());

            var descriptionAttributes = (DescriptionAttribute[])fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false);

            return descriptionAttributes.Length > 0 ? descriptionAttributes[0].Description : enumValue.ToString();
        }
    }

    public class ParamSetupException : CustomExceptionBase
    {
        private string extraInfo;
        public override String ErrorHost { get; set; } = "WorkFlow";
        public override String ErrorCode { get { return ((int)ParamSetuprError.PS00100).ToString(); } }
        public override String ErrorDesc { get { return "EAI returned Error during Payment Processing."; } }


        public ParamSetupException(string message)
            : base(message)
        {
            this.extraInfo = message;
        }
        public ParamSetupException(string message, Exception innerEx)
            : base(message, innerEx)
        {
            this.extraInfo = message;
        }
        public override String GetErrorMessage()
        {
            return this.extraInfo;
        }
    }
}
