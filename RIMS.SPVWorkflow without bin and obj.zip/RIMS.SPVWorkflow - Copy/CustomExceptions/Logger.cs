﻿//using NLog;
//using NLog.Extensions.Logging;
//using NLog.Web;

namespace RIMS.SPVWorkflow.SPVWorkflow.CustomExceptions
{
    public static class Logger
    {
        //private static NLog.Logger _loggerImpl;

        //public static void ConfigureLogger()
        //{
        //    var config = new ConfigurationBuilder()
        //                    .AddJsonFile("appsettings.Development.json", optional: true, reloadOnChange: true)
        //                    .Build();
        //    LogManager.Configuration = new NLogLoggingConfiguration(config.GetSection("NLog"));
        //    _loggerImpl = LogManager.Setup()
        //               .LoadConfigurationFromAppSettings()
        //               .GetCurrentClassLogger();
        //}
        //public static void Debug(string debug)
        //{
        //    _loggerImpl.Debug(debug);
        //}

        //public static void Error(string error)
        //{
        //    _loggerImpl.Error(error);
        //}

        ////public static void Info(string info)
        ////{
        ////    _loggerImpl.Info(info);
        ////}

        //public static void Warning(string warn)
        //{
        //    _loggerImpl.Warn(warn);
        //}
    }
}