﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RIMS.SPVWorkflow.Entities
{
    [Table("Promotion")]
    public class Promotion
    {
        [Key]
        public int Id { get; set; }
        public string PromoCode { get; set; }
        public decimal? NetCharge { get; set; }
        public DateTime? PromoStartDate { get; set; }
        public DateTime? PromoEndDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDateTime { get; set; }


    }


    [Table("UTFundProduct")]
    public class UTFundProduct
    {
        [Key]
        public int Id { get; set; }
        public string Segment { get; set; }
        public string FundManager { get; set; }
        public string FundMgrAddr1 { get; set; }
        public string FundMgrAddr2 { get; set; }
        public string FundMgrCity { get; set; }
        public string FundMgrState { get; set; }
        public string FundMgrCountry { get; set; }
        public string FundMgrZipCode { get; set; }
        public string FundMgrEntityBaseCcy { get; set; }
        public string FundMgrCompanyRegNo { get; set; }
        public string OrderCustAccNo { get; set; }
        public string OrderCustAccName { get; set; }
        public string OrderCustAccAddr { get; set; }
        public string InstitutePartyAccNo { get; set; }
        public string BeneficiaryCustAccNo { get; set; }
        public string BeneficiaryCustAccName { get; set; }
        public string BeneficiaryCustAccAddr { get; set; }
        public string RemitNInfoNarrative { get; set; }
        public string ChargesCode { get; set; }
        public string ISIN { get; set; }
        public string InvestorAlert { get; set; }
        public string LowbalCondition { get; set; }
        public string FundCode { get; set; }
        public string FundName { get; set; }
        public string FundCcy { get; set; }
        public string ProductGrp { get; set; }
        public string PreviousFundCode { get; set; }
        public string ShareClass { get; set; }
        public string BloombergTicker { get; set; }
        public string FundUmbrella { get; set; }
        public string FundType { get; set; }
        public string FundAdmin { get; set; }
        public string RegisteredCountry { get; set; }
        public string SGRegistration { get; set; }
        public DateTime? FinanceYrEndDate { get; set; }
        public DateTime? InceptionDate { get; set; }
        public string DivDeclareFrequency { get; set; }
        public string SemiAnnualRpt_URL { get; set; }
        public string AnnualRpt_URL { get; set; }
        public string FundfactSheet_URL { get; set; }
        public string Prospectus_URL { get; set; }
        public string ProductHighlight_URL { get; set; }
        public string MIDTemplate { get; set; }
        public string CTT { get; set; }
        public string CTTcore { get; set; }
        public string FocusIndicator { get; set; }
        public string MegatrendThemesNpriority { get; set; }
        public string Conviction { get; set; }
        public string FinancialNeeds { get; set; }
        public string ProductRiskClass { get; set; }
        public string SIPEIP { get; set; }
        public string AssetclassInternal { get; set; }
        public string AssetclassExternal { get; set; }
        public string Region { get; set; }
        public string Sector { get; set; }
        public string AllIndicator { get; set; }
        public string UOBclassification { get; set; }
        public string NationalityRestriction { get; set; }
        public string ResidencyRestriction { get; set; }
        public Int16 MinAgeEligible { get; set; }
        public string Status { get; set; }
        public DateTime? EffectiveStartDate { get; set; }
        public DateTime? EffectiveEndDate { get; set; }
        public string SegmentAllowed { get; set; }
        public string ChannelOfferBuy { get; set; }
        public string ChannelOfferSell { get; set; }
        public string ChannelOfferSW { get; set; }
        public string SwitchCurrencies { get; set; }
        public string PaymentMode { get; set; }
        public string RISFrequency { get; set; }
        public string RISPaymentMode { get; set; }
        public string RISSBFlag { get; set; }
        public string DivReinvestMode { get; set; }
        public string CancelIndicator { get; set; }
        public Int16 CancelPeriod { get; set; }
        public DateTime? MaturityDate { get; set; }
        public DateTime? IOPStartDate { get; set; }
        public DateTime? IOPEndDate { get; set; }
        public decimal? MBKSBAmountMin { get; set; }
        public decimal? MBKSBSubseqAmountMin { get; set; }
        public decimal? MBKRISAmountMin { get; set; }
        public decimal? MBKRISIncrementAmountMin { get; set; }
        public int? MBKRDUnitsMin { get; set; }
        public decimal? MBKRDAmountMin { get; set; }
        public int? MBKHoldingsUnitsMin { get; set; }
        public decimal? MBKHoldingsAmountMin { get; set; }
        public decimal? WMSSBAmountMin { get; set; }
        public decimal? WMSSBSubseqAmountMin { get; set; }
        public decimal? WMSRISAmountMin { get; set; }
        public decimal? WMSRISIncrementAmountMin { get; set; }
        public int? WMSRDUnitsMin { get; set; }
        public decimal? WMSRDAmountMin { get; set; }
        public int? WMSHoldingsUnitsMin { get; set; }
        public decimal? WMSHoldingsAmountMin { get; set; }
        public int? TransCutOffTime { get; set; }
        public string TransCutOffApplicable { get; set; }
        public string SettleHolidayRule { get; set; }
        public string DealingFrequency { get; set; }
        public string PriceBasis7DayCancel { get; set; }
        public string PriceDate { get; set; }
        public Int16 PriceAvailDays { get; set; }
        public string PriceDateHolidayRule { get; set; }
        public string PriceMethod { get; set; }
        public Int16 PriceDecPlace { get; set; }
        public string PriceRounding { get; set; }
        public Int16 UnitsDecPlace { get; set; }
        public string UnitsRounding { get; set; }
        public string PaymentCycle { get; set; }
        public string CareOf { get; set; }
        public string FeeCode_SB { get; set; }
        public string FeeCode_RD { get; set; }
        public decimal? AnnualMgntFee_PCT { get; set; }
        public decimal? TrailerFee_PCTMin { get; set; }
        public decimal? TrailerFee_PCTMax { get; set; }
        public string TrailerFeeCcy { get; set; }
        public decimal? SBFee_PCTMax { get; set; }
        public decimal? SWFee_PCTMax { get; set; }
        public string CPFSAProductCode { get; set; }
        public string CPFOAProductCode { get; set; }
        public string CPFBCompanyCode { get; set; }
        public string BankCode { get; set; }
        public string Register { get; set; }
        public string Trustee { get; set; }
        public string Custodian { get; set; }
        public string SettlementAccSB { get; set; }
        public string SettlementAccRD { get; set; }
        public string SettlementAccDivd { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDateTime { get; set; }


    }

    [Table("UTFundFeeMatrix")]
    public class UTFundFeeMatrix
    {
        [Key]
        // public int Id { get; set; }
        public string FeeCode { get; set; }
        public string Segment { get; set; }
        public Int16 SrNo { get; set; }
        public decimal? TransactAmountMin { get; set; }
        public decimal? TransactAmountMax { get; set; }
        public decimal? SB_NonStaffRMAst_CshSRS_PCTMin { get; set; }
        public decimal? SW_NonStaffRMAst_CshSRS_PCTMin { get; set; }
        public decimal? SB_StaffRMAst_CshSRS_PCT { get; set; }
        public decimal? SW_StaffRMAst_CshSRS_PCT { get; set; }
        public decimal? SB_Staff_OnlineCshSRS_PCT { get; set; }
        public decimal? SW_Staff_OnlineCshSRS_PCT { get; set; }
        public decimal? SB_NonStaff_OnlineCshSRS_PCT { get; set; }
        public decimal? SW_NonStaff_OnlineCshSRS_PCT { get; set; }
        public decimal? SBSW_AllCust_OnlineCPFOA_PCT { get; set; }
        public decimal? SBSW_AllCust_OnlineCPFSA_PCT { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDateTime { get; set; }

    }

    [Table("ListofValue")]
    public class ListofValue
    {
        [Key]
        public int Id { get; set; }
        public string Type { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string Value1 { get; set; }
        public string Value2 { get; set; }

    }

    [Table("CONFIG_PARAM")]
    public partial class CONFIG_PARAM
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedTime { get; set; }
        public string UpdatedBy { get; set; }
        public Nullable<System.DateTime> UpdatedTime { get; set; }
    }
}
