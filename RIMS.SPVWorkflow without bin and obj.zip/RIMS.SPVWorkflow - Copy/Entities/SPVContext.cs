﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RIMS.SPV.DataAccess.Entities;
using RIMS.SPVWorkflow.Entities;
using System.IO;


namespace RIMS.SPVWorkflow.SPVWorkflow.Entities
{
    public class SPVContext : DbContext
    {
        public SPVContext() : base()
        {

        }

        public SPVContext(DbContextOptions<SPVContext> options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder()
                                                        .SetBasePath(Directory.GetCurrentDirectory())
                                                        .AddJsonFile("appsettings.json")
                                                        .Build();
                var connectionString = configuration.GetConnectionString("SPVContext");
                optionsBuilder.UseSqlServer(connectionString);
                optionsBuilder.EnableSensitiveDataLogging();
            }
        }


        public DbSet<SPVRequest> SPVRequest { get; set; }
        public DbSet<SPVRequestOrder> SPVRequestOrder { get; set; }
        public DbSet<SPVRequestCustomer> SPVRequestCustomer { get; set; }
        public DbSet<MWPRequest> MWPRequest { get; set; }
        public DbSet<MWPCustomer> MWPCustomer { get; set; }
        public DbSet<SPVSSOSession> SPVSSOSession { get; set; }
        public DbSet<SPVCRSDeclaration> SPVCRSDeclaration { get; set; }
        public DbSet<SPVPartiesPresentDeclaration> SPVPartiesPresentDeclaration { get; set; }
        public DbSet<SPVUSEEADeclaration> SPVUSEEADeclaration { get; set; }
        public DbSet<AccountRelationship> AccountRelationship { get; set; }
        public DbSet<UTFundFeeMatrix> UTFundFeeMatrix { get; set; }

    }
}
