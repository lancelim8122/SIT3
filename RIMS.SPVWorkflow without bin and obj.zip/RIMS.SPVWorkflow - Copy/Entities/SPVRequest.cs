﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace RIMS.SPVWorkflow.SPVWorkflow.Entities
{
    public class SPVRequest
    {
        [Key]
        public string RequestID { get; set; }
        public string RequestType { get; set; }
        public string MWPSessionId { get; set; }
        public string MWPMinor { get; set; }
        public string MWPGen { get; set; }
        public string EntityNo { get; set; }
        public DateTime SignDate { get; set; }
        public DateTime ValidityEndDate { get; set; }
        public string Status { get; set; }
        public string StatusDesc { get; set; }
        public Nullable<System.DateTime> StatusUpdateTime { get; set; }
        public string OrderStatus { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedTime { get; set; }
        public string UpdatedBy { get; set; }
        public Nullable<System.DateTime> UpdatedTime { get; set; }
        public string WorkflowInd { get; set; }
        public string UTAccountNo { get; set; }
        public Char SigningCondition { get; set; }
        public string FormId { get; set; }
        public string OptInIndicator { get; set; }
        public string USEAADeclarationDate { get; set; }
        public string SignFormMode { get; set; }
        public string DropCIFIndicator { get; set; }
        //public string SSOReferenceNumber { get; set; }
    }
    public class SPVRequestOrder
    {
        public Guid Id { get; set; }
        public string RequestID { get; set; }
        public string ChannelRefId { get; set; }
        public string OrderTransactionRefNo { get; set; }
        public string SPVOrderStatus { get; set; }
        public string OrderType { get; set; }
        public string FundCode { get; set; }
        public string FundCcy { get; set; }
        public string OrgPaymentType { get; set; }
        public string PaymentType { get; set; }
        public string InvestmentType { get; set; }
        public decimal OrgInvestmentAmount { get; set; }
        public decimal InvestmentAmount { get; set; }
        public string RISFrequency { get; set; }
        public decimal SwitchFromUnits { get; set; }
        public string SwitchFromFundCode { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedTime { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedTime { get; set; }
        public string WorkflowInd { get; set; }
        public string BinIndicator { get; set; }
        public string CashAccountNo { get; set; }
        public string CashAccountType { get; set; }
        public string CashAccountCurrency { get; set; }
        public string CashAccountSignCondition { get; set; }
        public decimal IndicativeNAV { get; set; }
        public string IndicativeNAVDate { get; set; }
        public string CardNumber { get; set; }
        public string CPFApprovedBank { get; set; }
        public string CPFInvestmentAccount { get; set; }
        public string CPFAccount { get; set; }
        public string DividendInstruction { get; set; }
        public string DividendCreditingAcct { get; set; }
        public decimal SalesCharge { get; set; }
        public string Remarks { get; set; }
        public string SAQIndicator { get; set; }
        public string SRSOperator { get; set; }
        public string SRSAccount { get; set; }
        public string CreditingAcct { get; set; }
        public int RISRecurringPeriod { get; set; }
        public string RISStartDate { get; set; }
        public string RISEndDate { get; set; }
        public string RISDividendInstruction { get; set; }
        public decimal SwitchIndicativeAmount { get; set; }
    }
    public class MWPCustomer
    {
        [Key]
        public Guid Id { get; set; }
        [AllowNull]
        public string MWPId { get; set; }
        public string MWPMinor { get; set; }
        public string MWPGen { get; set; }
        public string EntityNo { get; set; }
        public string CIFNo { get; set; }
        public string CustomerName1 { get; set; }
        public string CustomerName2 { get; set; }
        public string NominatedParty { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedTime { get; set; }

    }
    public class MWPRequest
    {
        public Guid Id { get; set; }
        public string MWPId { get; set; }
        public string MWPMinor { get; set; }
        public string MWPGen { get; set; }
        public string EntityNo { get; set; }

        public DateTime ValidityEndDate { get; set; }
        public string Status { get; set; }
        public string StatusDesc { get; set; }
        public Nullable<System.DateTime> StatusUpdateTime { get; set; }

        public string CreatedBy { get; set; }
        public DateTime CreatedTime { get; set; }

    }
    public class SPVRequestCustomer
    {
        public Guid Id { get; set; }
        public string RequestID { get; set; }
        public string CIFNo { get; set; }
        public string CustomerName1 { get; set; }
        public string CustomerName2 { get; set; }
        public string NominatedParty { get; set; }
        public string PartyPresent { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        public string RiskScore { get; set; }
        public DateTime? RiskReviewDate { get; set; }
        public string RiskSource { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedTime { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedTime { get; set; }
        public string TIN1 { get; set; }
        public string Country1 { get; set; }
        public string Reason1 { get; set; }
        public string TIN2 { get; set; }
        public string Country2 { get; set; }
        public string Reason2 { get; set; }
        public string TIN3 { get; set; }
        public string Country3 { get; set; }
        public string Reason3 { get; set; }
        public string TIN4 { get; set; }
        public string Country4 { get; set; }
        public string Reason4 { get; set; }

    }

    public class SPVSSOSession
    {
        public string Id { get; set; }
        public string EntityNumber { get; set; }
        public string JourneyType { get; set; }
        public string SalespersonOfficerCodeTeam { get; set; }
        public string UTSalespersonCode { get; set; }
        public string SalespersonEmployeeID { get; set; }
        public string DomicileBranchCode { get; set; }
        public string BranchName { get; set; }
        public string SalespersonName1LastName { get; set; }
        public string SalespersonName2MidName { get; set; }
        public string UserId { get; set; }
    }

    public class SPVCRSDeclaration
    {
        public Guid Id { get; set; }
        public string SessionId { get; set; }
        public string CIFNo { get; set; }
        public string TaxResidency { get; set; }
        public string TaxDeclaration { get; set; }
        public string Tin { get; set; }

    }
    public class SPVUSEEADeclaration
    {
        public Guid Id { get; set; }
        public string SessionId { get; set; }
        public string USEEA { get; set; }

    }
    public class SPVPartiesPresentDeclaration
    {
        public Guid Id { get; set; }
        public string SessionId { get; set; }
        public string CIFNo { get; set; }
        public bool PresentIndicator { get; set; }

    }
}


