﻿using System;

namespace RIMS.SPVWorkflow.SPVWorkflow.Models.Product
{
    public class CRSDeclaration
    {
        public Guid Id { get; set; }
        public string SessionId { get; set; }
        public string CIFNo { get; set; }
        public string TaxResidency { get; set; }
        public string TaxDeclaration { get; set; }
        public string Tin { get; set; }
    }
}
