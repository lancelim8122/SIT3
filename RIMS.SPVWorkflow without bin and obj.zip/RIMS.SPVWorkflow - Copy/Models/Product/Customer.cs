﻿namespace RIMS.SPVWorkflow.SPVWorkflow.Models.Product
{
    public class Customer
    {
        //public int Id { get; set; }
        //public string MWPId { get; set; }
        //public string MWPMinor { get; set; }
        //public string MWPGen { get; set; }
        //public string EntityNo { get; set; }
        public string CIFNumber { get; set; }
        public string CustomerName1 { get; set; }
        public string CustomerName2 { get; set; }
        public string NominatedParty { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        public string PartyPresent { get; set; }
        public string RiskScore { get; set; }
        public string RiskReviewDate { get; set; }
        public string RiskSource { get; set; }

    }
}
