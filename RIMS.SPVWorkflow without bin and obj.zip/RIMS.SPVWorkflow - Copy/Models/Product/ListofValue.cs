﻿using FileHelpers;
using System;
using System.ComponentModel.DataAnnotations;

namespace RIMS.SPVWorkflow.SPVWorkflow.Models.Product.ListofValue
{
    public class UTFundProductBasicDetailRequest : Request
    {
        public ListofValue RequestDetails { get; set; }
    }

    public class ListofValue
    {
        [Key]
        public string Code { get; set; }
        //public string Id { get; set; }
        public string Type { get; set; }

        public string Description { get; set; }
        public string Value1 { get; set; }
        public string Value2 { get; set; }
    }


    [DelimitedRecord("|")]
    public class ListOfValueModelHeader
    {
        public string RecordDescriptor;

        public string SystemID;

        public string ProcessingFileName;

        [FieldConverter(ConverterKind.Date, "yyyyMMdd")]
        public DateTime ProcessingDate;

        [FieldConverter(ConverterKind.Date, "hhmmss")]
        public DateTime ProcessingTime;
    }

    [DelimitedRecord("|")]
    public class ListOfValueModelDetail
    {
        public string RecordDescriptor;
        public string Event;
        public string Type;
        public string Code;
        public string Description;
        public string Value1;
        public string Value2;

    }

    [DelimitedRecord("|")]
    public class ListOfValueModelTrailer
    {
        public string RecordDescriptor;
        public int Count;
    }
}
