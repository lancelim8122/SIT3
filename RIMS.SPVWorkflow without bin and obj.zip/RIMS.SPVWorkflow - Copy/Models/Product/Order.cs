﻿using System;

namespace RIMS.SPVWorkflow.SPVWorkflow.Models.Product
{
    public class Order
    {
        public Guid Id { get; set; }
        public string RequestID { get; set; }
        public string RefId { get; set; }
        public string OrderTransactionRefNo { get; set; }
        public string SPVOrderStatus { get; set; }
        public string OrderType { get; set; }
        public string FundCode { get; set; }
        public string FundCcy { get; set; }
        public string OrgPaymentType { get; set; }
        public string PaymentType { get; set; }
        public string InvestmentType { get; set; }
        public decimal OrgInvestmentAmount { get; set; }
        public string InvestmentAmount { get; set; }
        public string RISFrequency { get; set; }
        public int RISAmount { get; set; }
        public decimal SwitchFromUnits { get; set; }
        public string SwitchFromFundCode { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedTime { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedTime { get; set; }
        public string WorkflowInd { get; set; }
        public string BinIndicator { get; set; }
        public string CashAccountNo { get; set; }
        public string CashAccountType { get; set; }
        public string CashAccountCurrency { get; set; }
        public string CashAccountSignCondition { get; set; }
        public decimal IndicativeNAV { get; set; }
        public DateTime IndicativeNAVDate { get; set; }
        public string CardNumber { get; set; }
        public string CPFApprovedBank { get; set; }
        public string CPFInvestmentAccount { get; set; }
        public string CPFAccount { get; set; }
        public string DividendInstruction { get; set; }
        public string DividendCreditingAcct { get; set; }
        public decimal SalesCharge { get; set; }
        public string Remarks { get; set; }
        public string SAQIndicator { get; set; }
        public string SRSOperator { get; set; }
        public string SRSAccount { get; set; }
        public string CreditingAcct { get; set; }
        public int RISRecurringPeriod { get; set; }
        public DateTime RISStartDate { get; set; }
        public DateTime RISEndDate { get; set; }
        public string RISDividendInstruction { get; set; }
        public decimal SwitchIndicativeAmount { get; set; }
        public string OrderStatusIndicator { get; set; }
    }
}
