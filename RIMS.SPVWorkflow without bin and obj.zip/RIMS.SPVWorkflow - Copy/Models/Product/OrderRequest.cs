﻿namespace RIMS.SPVWorkflow.SPVWorkflow.Models.Product
{
    public class OrderRequest : Request
    {
        public Order RequestDetails { get; set; }

    }
    public class PartiesDecRequest : Request
    {
        public PartiesPreDeclaration RequestDetails { get; set; }

    }
    public class USEEADecRequest : Request
    {
        public USEEADeclaration RequestDetails { get; set; }

    }
    public class CRSDecRequest : Request
    {
        public CRSDeclaration RequestDetails { get; set; }

    }
}
