﻿using System;

namespace RIMS.SPVWorkflow.SPVWorkflow.Models.Product
{
    public class PartiesPreDeclaration
    {
        public Guid Id { get; set; }
        public string SessionId { get; set; }
        public string CIFNo { get; set; }
        public bool PresentIndicator { get; set; }
    }
}
