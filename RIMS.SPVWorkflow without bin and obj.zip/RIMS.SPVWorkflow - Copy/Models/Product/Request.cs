﻿using System;

namespace RIMS.SPVWorkflow.SPVWorkflow.Models.Product
{
    public class Request
    {
        public RequestHeader RequestHeader { get; set; }
    }

    public class RequestHeader
    {
        public RequesterContext RequesterContext { get; set; }

    }
    public class RequesterContext
    {
        public string RegionCode { get; set; }
        public DateTime RequestAt { get; set; }
        public string SourceSystem { get; set; }
        public string TargetSystem { get; set; }
        public string RequestID { get; set; }
    }
}
