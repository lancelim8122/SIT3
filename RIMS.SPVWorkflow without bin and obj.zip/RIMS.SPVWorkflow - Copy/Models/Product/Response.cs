﻿using System;

namespace RIMS.SPVWorkflow.SPVWorkflow.Models.Product
{
    public class Response
    {
        public ResponseHeader ResponseHeader { get; set; }
        public Response()
        {
            this.ResponseHeader = new ResponseHeader();
        }
    }

    public class ResponseHeader
    {
        public string ResponseStatus { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorHost { get; set; }
        public string ErrorDesc { get; set; }
        public ResponseContext ResponseContext { get; set; }

        public ResponseHeader()
        {
            this.ResponseStatus = "SUCCESS";
            this.ErrorCode = "0000";
        }
    }
    public class ResponseContext
    {
        public string RegionCode { get; set; }
        public DateTime RequestAt { get; set; }
        public string SourceSystem { get; set; }
        public string TargetSystem { get; set; }
        public string RequestID { get; set; }
    }
}
