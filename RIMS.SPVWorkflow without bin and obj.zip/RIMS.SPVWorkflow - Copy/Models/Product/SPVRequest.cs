﻿using RIMS.SPVWorkflow.SPVWorkflow.Entities;
using System;
using System.Collections.Generic;

namespace RIMS.SPVWorkflow.SPVWorkflow.Models.Product
{
    public class SPVRequest
    {
        public class SPVCreationBasicDetailRequest : Request
        {
            public SPVRequest RequestDetails { get; set; }
        }
        public string RequestID { get; set; }
        public string RequestType { get; set; }
        public string MWPSessionId { get; set; }
        public string MWPMinor { get; set; }
        public string MWPGen { get; set; }
        public string EntityNumber { get; set; }
        public DateTime SignDate { get; set; }
        public DateTime ValidityEndDate { get; set; }
        public string Status { get; set; }
        public string StatusDesc { get; set; }
        public Nullable<System.DateTime> StatusUpdateTime { get; set; }
        public string OrderStatus { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedTime { get; set; }
        public string UpdatedBy { get; set; }
        public Nullable<System.DateTime> UpdatedTime { get; set; }
        public string WorkflowInd { get; set; }
        public string UTAccountNo { get; set; }
        public Char SigningCondition { get; set; }
        public string FormId { get; set; }
        public string OptInIndicator { get; set; }
        public string USEAADeclarationDate { get; set; }
        public string SignFormMode { get; set; }
        public string DropCIFIndicator { get; set; }
        public string SSOReferenceNumber { get; set; }
        public List<SPVRequestCustomer> Customer { get; set; }
        public List<SPVRequestOrder> Order { get; set; }
    }

}
