using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RIMS.SPVWorkflow.SPVWorkflow.Pages
{
    public class _HostModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
