using Elsa;
using Elsa.Persistence.EntityFramework.Core.Extensions;
using Elsa.Persistence.EntityFramework.SqlServer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RIMS.SPVWorkflow.Activities;
using RIMS.SPVWorkflow.Activities.RIMA_AccountRelated;
using RIMS.SPVWorkflow.Activities.RIMC_CustomerRelated;
using RIMS.SPVWorkflow.Activities.RIMG_Generic;
using RIMS.SPVWorkflow.Activities.RIMT_TradeRelated;
using RIMS.SPVWorkflow.SPVWorkflow.Entities;

namespace RIMS.SPVWorkflow.SPVWorkflow
{
    public class Startup
    {
        public Startup(IWebHostEnvironment environment, IConfiguration configuration)
        {
            Configuration = configuration;
            Environment = environment;
        }

        public IConfiguration Configuration { get; }
        private IWebHostEnvironment Environment { get; }

        // This method gets called by the runtime. Use this method to add services to the container.

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();

            var elsaSection = Configuration.GetSection("Elsa");
            services
                .AddElsa(elsa => elsa
                    .UseEntityFrameworkPersistence(ef => ef.UseSqlServer(Configuration.GetConnectionString("SPVContext")))
                    .AddConsoleActivities()
                    .AddHttpActivities(elsaSection.GetSection("Server").Bind)
                    .AddEmailActivities(elsaSection.GetSection("Smtp").Bind)
                    .AddQuartzTemporalActivities()
                    .AddActivity<Create_Mwp>()
                    .AddActivity<Create_Order>()
                    .AddActivity<SaveSPVRequestOrderToComplete>()
                    .AddActivity<SaveSPVRequestOrderToPTCFailed>()
                    .AddActivity<GetOrderByMWPId>()
                    .AddActivity<GetAllCASAAccounts>()
                    .AddActivity<UpdateSPVRequest>()
                    .AddActivity<GetMWPRequestByMWPId>()


                    //RIMT TradeRelated
                    .AddActivity<RIMT01_PaymentTypeSupport>()
                    .AddActivity<RIMT03_SAQStatusFlag>()
                    .AddActivity<RIMT04_ChangeOfOrderAmountOrUnits>()
                    .AddActivity<RIMT05_InsufficientFundsCheck>()
                    .AddActivity<RIMT06A_SufficientHoldingsCheck>()
                    .AddActivity<RIMT06B_BalanceUnitCheck>()
                    .AddActivity<RIMT10_MinimumAmountOrUnitsCheck>()
                    .AddActivity<RIMT12_DuplicateRISCheck>()
                    .AddActivity<RIMT13_RISStartDateCheck>()
                    .AddActivity<RIMT15_SwitchCoolingCancellationPeriodCheck>()
                    .AddActivity<RIMT16_RISAllowedCheck>()
                    .AddActivity<RIMT17_CapFeeValidation>()
                    .AddActivity<RIMT18_DividendInstructionCheck>()
                    .AddActivity<RIMT19_PaymentTypeBasedOnEntity>()

                    //RIMA_AccountRelated
                    .AddActivity<RIMA01A_ExistingValidCasaWithFundCurrenyCheck>()
                    .AddActivity<RIMA01B_ExistingValidCasa>()
                    .AddActivity<RIMA02_MailingAddressCheck>()
                    .AddActivity<RIMA03_UTAccountValidity>()
                    .AddActivity<RIMA06_ValidCreditCardCheck>()

                    //RIMG_Generic
                    .AddActivity<RIMG01_DetermineCustomerJourney>()
                    .AddActivity<RIMG02_PartyPresentDeclaration>()
                    .AddActivity<RIMG07_PartiesPresentCheck>()
                    .AddActivity<RIMG09_UTSalespersonCodeCheck>()

                    //RIMC_CustomerRelated
                    .AddActivity<RIMC01_USPersonFATCACheck>()
                    .AddActivity<RIMC02_NationalityCheck>()
                    .AddActivity<RIMC03_ResidencyCheck>()
                    .AddActivity<RIMC06_StaffCheck>()

                    .AddWorkflowsFrom<Startup>()
                );

            services.AddElsaApiEndpoints();
            services.AddRazorPages();
            services.AddDbContext<SPVContext>(ef => ef.UseSqlServer(Configuration.GetConnectionString("SPVContext")));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            //app.UseEndpoints(endpoints =>
            //{
            //    endpoints.MapControllerRoute(
            //        name: "default",
            //      pattern: "{controller=Home}/{action=Index}/{id?}");
            //});
            app.UseStaticFiles() // For Dashboard.
                .UseHttpActivities()
                .UseRouting()
                .UseEndpoints(endpoints =>
                {
                    // Elsa API Endpoints are implemented as regular ASP.NET Core API controllers.
                    endpoints.MapControllers();

                    // For Dashboard.
                    endpoints.MapFallbackToPage("/_Host");
                });
        }
    }
}
