﻿using System;
using System.IO;
//using Rebus.Logging;

namespace RIMS.SPVWorkflow.SPVWorkflow.Utilities
{
    public static class AuditLogger
    {

        public static void Info(object msg)
        {

            string message = GetCleanedLog(msg);
            using (StreamWriter w = File.AppendText("errorLog.txt"))
            {
                Log(message, w);
            }
        }

        public static void Log(string logMessage, TextWriter w)
        {
            w.Write("\r\nLog Entry : ");
            w.WriteLine($"{DateTime.Now.ToLongTimeString()} {DateTime.Now.ToLongDateString()}");
            w.WriteLine("  :");
            w.WriteLine($"  :{logMessage}");
            w.WriteLine("-------------------------------");
        }
        private static string GetCleanedLog(object msg)
        {
            return msg.ToString().Replace("\r", string.Empty).Replace("\n", string.Empty);
        }
    }
}

