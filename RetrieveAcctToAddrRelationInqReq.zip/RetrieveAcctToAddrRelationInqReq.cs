﻿using System.Xml.Serialization;

namespace RIMS.Common.MQ.Models.CompositeEnquiry
{
    [XmlRoot(ElementName = "EAI")]
    public class RetrieveAcctToAddrRelationInqReq : BaseEAIRequest
    {
        public RetrieveAcctToAddrRelationInqReq_SubSvcRq SubSvcRq { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRq")]
    public class RetrieveAcctToAddrRelationInqReq_SubSvcRq
    {
        public RetrieveAcctToAddrRelationInqReq_SubSvc SubSvc { get; set; }
    }

    [XmlRoot(ElementName = "SubSvc")]
    public class RetrieveAcctToAddrRelationInqReq_SubSvc
    {
        public RetrieveAcctToAddrRelationInqReq_SubSvcRqHeader SubSvcRqHeader { get; set; }
        public RetrieveAcctToAddrRelationInqReq_SubSvcRqDetail SubSvcRqDetail { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRqHeader")]
    public class RetrieveAcctToAddrRelationInqReq_SubSvcRqHeader
    {
        public string SvcCode { get; set; }
        public string SubSvcSeq { get; set; }
        public string TxnRef { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRqDetail")]
    public class RetrieveAcctToAddrRelationInqReq_SubSvcRqDetail
    {
        public RetrieveAcctToAddrRelationInqReq_BankAcctReq BankAcctReq { get; set; }
    }
    [XmlRoot(ElementName = "BankAcct")]
    public class RetrieveAcctToAddrRelationInqReq_BankAcctReq
    {
        public string AcctId { get; set; }
        public string AcctType { get; set; }
    }

}
