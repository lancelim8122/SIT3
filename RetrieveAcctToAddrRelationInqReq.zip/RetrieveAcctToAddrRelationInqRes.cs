﻿using System.Xml.Serialization;

namespace RIMS.Common.MQ.Models.CompositeEnquiry
{
    [XmlRoot(ElementName = "EAI")]
    public class RetrieveAcctToAddrRelationInqRes : BaseEAIResponse
    {
        public RetrieveAcctToAddrRelationInqRes_SubSvcRs SubSvcRs { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRs")]
    public class RetrieveAcctToAddrRelationInqRes_SubSvcRs
    {
        public RetrieveAcctToAddrRelationInqRes_SubSvcRsSub SubSvc { get; set; }
    }
    [XmlRoot(ElementName = "SubSvc")]
    public class RetrieveAcctToAddrRelationInqRes_SubSvcRsSub
    {
        public RetrieveAcctToAddrRelationInqRes_SubSvcRsHeader SubSvcRsHeader { get; set; }
        public RetrieveAcctToAddrRelationInqRes_SubSvcRsDetail SubSvcRsDetail { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRsHeader")]
    public class RetrieveAcctToAddrRelationInqRes_SubSvcRsHeader
    {
        public string SvcCode { get; set; }
        public string SubSvcSeq { get; set; }
        public string TxnRef { get; set; }
        public string StatusCode { get; set; }
        public string ErrorHost { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorDesc { get; set; }
        public string EAIErrCode { get; set; }
        public string EAIErrDesc { get; set; }
        public string EAIErrInfo { get; set; }
    }
    [XmlRoot(ElementName = "SubSvcRsDetail")]
    public class RetrieveAcctToAddrRelationInqRes_SubSvcRsDetail
    {
        public string CIFNo { get; set; }
        public RetrieveAcctToAddrRelationInqRes_CustInfo CustInfo { get; set; }
        public RetrieveAcctToAddrRelationInqRes_AcctInfo AcctInfo { get; set; }
        public RetrieveAcctToAddrRelationInqRes_AddrInfo AddrInfo { get; set; }
        public RetrieveAcctToAddrRelationInqRes_PrimaryHolder PrimaryHolder { get; set; }
    }

    [XmlRoot(ElementName = "CustInfo")]
    public class RetrieveAcctToAddrRelationInqRes_CustInfo
    {
        public string Salutation { get; set; }
        public string CustName { get; set; }
        public string CustType { get; set; }
    }

    [XmlRoot(ElementName = "AcctInfo")]
    public class RetrieveAcctToAddrRelationInqRes_AcctInfo
    {
        public string CoName { get; set; }
        public string Name1 { get; set; }
        public string Name2 { get; set; }
        public string SignCond { get; set; }
        public string RelType { get; set; }
    }

    [XmlRoot(ElementName = "AddrInfo")]
    public class RetrieveAcctToAddrRelationInqRes_AddrInfo
    {
        public string SeqNo { get; set; }
        public string AddrType { get; set; }
        public string AddrFmt { get; set; }
        public string Addr1 { get; set; }
        public string Addr2 { get; set; }
        public string Addr3 { get; set; }
        public string Addr4 { get; set; }
        public string PreferredAddrInd { get; set; }
        public string VerifyAddrInd { get; set; }
        public RetrieveAcctToAddrRelationInqRes_FmtAddr FmtAddr { get; set; }
    }

    [XmlRoot(ElementName = "PrimaryHolder")]
    public class RetrieveAcctToAddrRelationInqRes_PrimaryHolder
    {
        public string IdNo { get; set; }
        public string IdType { get; set; }
        public string OwnerCountry { get; set; }
    }

    [XmlRoot(ElementName = "FmtAddr")]
    public class RetrieveAcctToAddrRelationInqRes_FmtAddr
    {
        public string BldgNo { get; set; }
        public string StoreyNo { get; set; }
        public string UnitNo { get; set; }
        public string POBox { get; set; }
        public string BldgName { get; set; }
        public string StreetName { get; set; }
        public string CityName { get; set; }
        public string PostalCode { get; set; }
        public string CountryCode { get; set; }
    }
}
